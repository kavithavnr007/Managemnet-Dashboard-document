/***LMS*****/

var lmsPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Course List')/items?&$top=5000"
var lsrPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Learner')/items?&$top=5000"
debugger;
var lmsData = [];
var lmsData1=[];
var lsrdata=[];
var results=[];
var populardata=[];
var filteredItems = [];
var loggedUserPath = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + _spPageContextInfo.userId + ")";
var loggedUserMail,myEmail,userName =[];

function lmsfunc() {

$.ajax({
    url: loggedUserPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        loggedUserMail = data.d.Email;
        userName = data.d.Title;
       /* if(myEmail.includes(loggedUserMail)==false){
            myEmail.push(loggedUserMail);
        }*/
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});


$.ajax({

url:lmsPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

lmsData = [...lmsData,...data.d.results]

if (data.d.__next) {

lmsPath = data.d.__next;

lmsfunc();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});



//get learner list

$.ajax({

url:lsrPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

lsrdata = [...lsrdata,...data.d.results]

// Filter and compare the lists
                  
for (var i = 0; i < lmsData.length; i++) {
            var list1Item = lmsData[i];

            // Compare with List2 items based on a matching field (e.g., "Title")
            var matchingItems = lsrdata.filter(function (list2Item) {
              return list2Item.Course === list1Item.Title && list2Item.Category === list1Item.Category&& list2Item.EmployeeEmail.toLocaleLowerCase() ===loggedUserMail.toLocaleLowerCase() && list2Item.CourseStatus==="InProgress";//&& list2Item.Section === list1Item.Section
            });

            var matchingfullItems = lsrdata.filter(function (list2Item) {
              return list2Item.Course === list1Item.Title && list2Item.Category === list1Item.Category&& list2Item.CourseStatus==="InProgress";//&& list2Item.Section === list1Item.Section
            });
            // Add matching items to the popular collection
            if (matchingfullItems.length > 0) {
              populardata.push(list1Item);
            }

            // Add matching items to the filtered collection
            if (matchingItems.length > 0) {
              filteredItems.push(list1Item);
            }
          }
          // Process the filtered items as desired
          console.log(filteredItems);


if (data.d.__next) {

lsrPath = data.d.__next;

lmsfunc();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});

}



function appendlms(){
  nrecord=$('.norecord');
nrecord.empty();
let lmsWrap = $('.career-wrap3');
var inputBox = document.getElementById("searchInput");
  inputBox.value = "";
   $('.clear-search').hide();
   const selectElement = document.getElementById("mySelect");
    selectElement.selectedIndex = 0;  
lmsWrap.empty()

// Sort the data based on the sort direction and column
 lmsData.sort((a, b) => {
  if (a.Title < b.Title) {
    return -1;
  }
  if (a.Title > b.Title) {
    return 1;
  }
  return 0;
});
//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")
document.getElementById('inprghead').innerHTML = 'In Progress ( ' + filteredItems.length +' )' ;

//grid view
if(filteredItems.length > 0){
  $('.scrollbar-wrap').show();
  $('.car-container3').show()

filteredItems.map(items => lmsWrap.append(`<div class="post" onclick=""><a title="Start Course" target="_blank" data-interception="off" href="${items.NavigateURL ? items.NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}"><img align="left" src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px;"/><img align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="border:none;border-radius:0%;width: 30px;height: 90px;padding-top: 20px;padding-bottom: 20px;"><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></a></div>`)) 
}
else{
//exchange
$('.scrollbar-wrap').hide();
  $('.car-container3').hide();
  $('.norecord').show();
lmsWrap.empty();
nrecord=$('.norecord');
nrecord.empty();
nrecord.append(`<p style="font-size: 120%; color:#3d8084;text-align: center;padding-top: 100px; width: 539px;">${"No Record found"}</p>
`)

}
}

//document.addEventListener("DOMContentLoaded", function() {
function testeva(){
    $('.tableviewtest').show();
     $('.clear-searchtesteval').hide();
    const takeInput = document.getElementById("TakeInput");
    takeInput.value="";
    lsrdata = lsrdata.filter(list => list.EmployeeEmail.toLocaleLowerCase() ===loggedUserMail.toLocaleLowerCase())
    // Sort the data based on the sort direction and column
 lsrdata.sort((a, b) => {
  if (a.Course < b.Course) {
    return -1;
  }
  if (a.Course > b.Course) {
    return 1;
  }
  return 0;
});
    if(lsrdata.length>0){
      document.getElementById('urself').innerHTML = 'Take a Test ( ' + lsrdata.length +' )' ;
      $('.clear-searchtesteval').hide(); 
      $('.norecordtest').hide();
var tableData = lsrdata.map(value => {
  return ( //<td>${value.ID}</td>
    `<tr>
       <td title="${value.Course}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3.5em;overflow: hidden;text-overflow: ellipsis;">${value.Course}</td>
       <td title="${value.Category}" style="max-height: 2em;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;">${value.Category}</td>
       <td title="${value.Section}" style="max-height: 2em;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;">${value.Section}</td>
       <td title="${value.AuthorName}" style="max-height: 2em;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;">${value.AuthorName}</td>
       <td title="${value.AboutAuthor}" style="max-height: 3.5em;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;">${value.AboutAuthor}</td>
       <td title="${'Take Test'}" ><button style="background: green;border: none;border-radius: 5px;"><a style="color:white;" target="_blank" data-interception="off" href="https://apps.powerapps.com/play/e/default-7bf109b7-39a2-49d4-911d-09736db83214/a/26f09119-3947-4579-bd7e-3cf90892c717?tenantId=7bf109b7-39a2-49d4-911d-09736db83214?CourseDetailID=${value.ID}">${'Take Test'}</a></button></td>
       <td title="${'Retake'}" ><button style="background: #006bc9;border: none;border-radius: 5px;"><a style="color: white;" target="_blank" data-interception="off" href="https://apps.powerapps.com/play/e/default-7bf109b7-39a2-49d4-911d-09736db83214/a/26f09119-3947-4579-bd7e-3cf90892c717?tenantId=7bf109b7-39a2-49d4-911d-09736db83214?CourseDetailID=${value.ID}">${'Retake'}</a></button</td>
    </tr>`
  );
}).join('');

const tableBody = document.querySelector("#tableBody");
tableBody.innerHTML = tableData;
    }
    else{
      $('.tableviewtest').hide();
      $('.norecordtest').show();
    }
}
//})
// Assuming 'sharepointData' is the array of SharePoint data
function searchData(inputValue) {
  const searchResults = filteredItems.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search
    return item.Title.toLowerCase().includes(inputValue.toLowerCase());
  });
   return searchResults;
}

// Get a reference to the input element
const searchInput = document.getElementById("searchInput");

// Add the onchange event handler to the input element
searchInput.onchange = function() {
  
  const inputValue = searchInput.value;
  if(inputValue.length >0){
     $('.clear-search').show()  
  }
  else{
    appendlms();
      $('.clear-search').hide()  
  };
  var results = searchData(inputValue);
  console.log(results);
  
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//filteredItems = filteredItems.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){
   $('.scrollbar-wrap').show();
  $('.car-container3').show()

results.map(items => lmsWrap.append(`<div class="post" onclick=""><a title="Start Course" target="_blank" data-interception="off" href="${items.NavigateURL ? items.NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}"><img align="left" src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px;"/><img align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="border:none;border-radius:0%;width: 30px;height: 90px;padding-top: 20px;padding-bottom: 20px;"><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></a></div>`)) 


  
}
sortfun();
   // This will log an array of items that match the search criteria
};



function sortfun() {
  debugger;
const selectElement = document.getElementById("mySelect");
    const selectedOptionValue = selectElement.value;
    console.log(selectedOptionValue);
    
  if (selectedOptionValue === "option1") {
  
  const inputValue = searchInput.value;
  var results = searchData(inputValue);
  console.log(results);
  
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//filteredItems = filteredItems.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){
  $('.scrollbar-wrap').show();
  $('.car-container3').show()

results.map(items => lmsWrap.append(`<div class="post" onclick=""><a title="Start Course" target="_blank" data-interception="off" href="${items.NavigateURL ? items.NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}"><img align="left" src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px;"/><img align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="border:none;border-radius:0%;width: 30px;height: 90px;padding-top: 20px;padding-bottom: 20px;"><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></a></div>`))
}


// Sort the data based on the sort direction and column
 if(results.length > 0){
 results.sort((a, b) => {
  if (a.Title < b.Title) {
    return -1;
  }
  if (a.Title > b.Title) {
    return 1;
  }
  return 0;
});
let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

if(results.length > 0){
  $('.scrollbar-wrap').show();
  $('.car-container3').show()

results.map(items => lmsWrap.append(`<div class="post" onclick=""><a title="Start Course" target="_blank" data-interception="off" href="${items.NavigateURL ? items.NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}"><img align="left" src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px;"/><img align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="border:none;border-radius:0%;width: 30px;height: 90px;padding-top: 20px;padding-bottom: 20px;"><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></a></div>`)) //<div class="vl"></div>
}
 }
 else{
  //exchange
$('.scrollbar-wrap').hide();
  $('.car-container3').hide();
  $('.norecord').show();
lmsWrap.empty();
nrecord=$('.norecord');
nrecord.empty();
nrecord.append(`<p style="font-size: 120%; color:#3d8084;text-align: center;padding-top: 100px; width: 539px;">${"No Record found"}</p>
`)
}
} 
else {
const inputValue = searchInput.value;
  var results = searchData(inputValue);
  console.log(results);
  
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//filteredItems = filteredItems.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){
  $('.scrollbar-wrap').show();
  $('.car-container3').show()

results.map(items => lmsWrap.append(`<div class="post" onclick=""><a title="Start Course" target="_blank" data-interception="off" href="${items.NavigateURL ? items.NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}"><img align="left" src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px;"/><img align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="border:none;border-radius:0%;width: 30px;height: 90px;padding-top: 20px;padding-bottom: 20px;"><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></a></div>`)) //<div class="vl"></div>

}

 if(results.length > 0){
   results.sort((a, b) => {
  if (a.Title < b.Title) {
    return 1;
  }
  if (a.Title > b.Title) {
    return -1;
  }
  return 0;
});
// Display the sorted data in your UI
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//results = results.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){
  $('.scrollbar-wrap').show();
  $('.car-container3').show()

results.map(items => lmsWrap.append(`<div class="post" onclick=""><a title="Start Course" target="_blank" data-interception="off" href="${items.NavigateURL ? items.NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}"><img align="left" src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px;"/><img align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="border:none;border-radius:0%;width: 30px;height: 90px;padding-top: 20px;padding-bottom: 20px;"><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></a></div>`)) //<div class="vl"></div>
}

 }
 else{

   //exchage
  $('.scrollbar-wrap').hide();
  $('.car-container3').hide();
  $('.norecord').show();
lmsWrap.empty();
nrecord=$('.norecord');
nrecord.empty();
nrecord.append(`<p style="font-size: 120%; color:#3d8084;text-align: center; padding-top: 100px; width: 539px;">${"No Record found"}</p>
`)

 }
 
  }
}







// search test evaluation section
function testfun(inputValue) {
  debugger
  lsrdata = lsrdata.filter(list => list.EmployeeEmail.toLocaleLowerCase() ===loggedUserMail.toLocaleLowerCase())
  const searchResults = lsrdata.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search   
    return item.Course.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Get a reference to the input element
//const takeInput = document.getElementById("TakeInput");

// Add the onchange event handler to the input element
//takeInput.onchange =

function takeinputchange() {
  const takeInput = document.getElementById("TakeInput");
  const inputValue = takeInput.value;
  if(inputValue.length >0){
     $('.clear-searchtesteval').show();  
     var results = testfun(inputValue);
  console.log(results);


if(results.length > 0){
  $('.clear-searchtesteval').show();
results.sort((a, b) => {
  if (a.Course < b.Course) {
    return -1;
  }
  if (a.Course > b.Course) {
    return 1;
  }
  return 0;
});
 $('.norecordtest').hide();
var tableData = results.map(value => {
  return ( 
    `<tr>
       <td title="${value.Course}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3.5em;overflow: hidden;text-overflow: ellipsis;">${value.Course}</td>
       <td title="${value.Category}" style="max-height: 2em;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;">${value.Category}</td>
       <td title="${value.Section}" style="max-height: 2em;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;">${value.Section}</td>
       <td title="${value.AuthorName}" style="max-height: 2em;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;">${value.AuthorName}</td>
       <td title="${value.AboutAuthor}" style="max-height: 3.5em;overflow: hidden; white-space: nowrap;text-overflow: ellipsis;">${value.AboutAuthor}</td>
       <td title="${'Take Test'}" ><button style="background: green;border: none;border-radius: 5px;"><a style="color:white;" target="_blank" data-interception="off" href="https://apps.powerapps.com/play/e/default-7bf109b7-39a2-49d4-911d-09736db83214/a/26f09119-3947-4579-bd7e-3cf90892c717?tenantId=7bf109b7-39a2-49d4-911d-09736db83214?CourseDetailID=${value.ID}">${'Take Test'}</a></button></td>
       <td title="${'Retake'}" ><button style="background: #006bc9;border: none;border-radius: 5px;"><a style="color: white;" target="_blank" data-interception="off" href="https://apps.powerapps.com/play/e/default-7bf109b7-39a2-49d4-911d-09736db83214/a/26f09119-3947-4579-bd7e-3cf90892c717?tenantId=7bf109b7-39a2-49d4-911d-09736db83214?CourseDetailID=${value.ID}">${'Retake'}</a></button</td>
    </tr>`
  );
}).join('');

const tableBody = document.querySelector("#tableBody");
tableBody.innerHTML = tableData;
}
else{
  $('.tableviewtest').hide();
  $('.clear-searchtesteval').show();
   $('.norecordtest').show();
}
}
else{
    testeva();
    const takeInput = document.getElementById("TakeInput");
    takeInput.value="";
      $('.clear-searchtesteval').hide();
  };
  
}


//end of test evaluation search




//Announcement Ticker
function displayAnnouncementOnHomePage() {
    debugger;
        var announceNote = [];

       
// Course counts
const courseCounts = {};

// Count the occurrences of each course
for (const learner of populardata) {
  const courses = Array.isArray(learner.Title) ? learner.Title : [learner.Title];
  for (const course of courses) {
    if (courseCounts[course]) {
      courseCounts[course]++;
    } else {
      courseCounts[course] = 1;
    }
  }
}

// Sort the courses by count in descending order
const sortedCourses = Object.keys(courseCounts).sort((a, b) => courseCounts[b] - courseCounts[a]);

// Output the popular courses in descending order
console.log('Popular courses (descending order):');
for (const course of sortedCourses) {
  announceNote.push(`${course}`);
  console.log(`${course}: ${courseCounts[course]} learners`);
}

var popularc =[];
for (var i = 0; i < announceNote.length; i++) {
            var list1Item = announceNote[i];

            const distinctData = Object.values(
  lmsData.reduce(function(acc, currentItem) {
    if (!acc[currentItem.Title]) {
      acc[currentItem.Title] = currentItem;
    }
    return acc;
  }, {})
);

            // Compare with List2 items based on a matching field (e.g., "Title")
            var matchingItems = distinctData.filter(function (list2Item) {
              return list2Item.Title === list1Item;//&& list2Item.Section === list1Item.Section
            });

            // Add matching items to the filtered collection
if (matchingItems.length > 0) {
  popularc = popularc.concat(matchingItems);
}
          }


        //announceNote = [...populardata]
        if (popularc.length > 10) {
  // Slice the array to remove extra elements
  popularc = popularc.slice(0, 10);
}

$(`#aList`).empty();
         
            for (i = 0; i < popularc.length; i++) {     
                    $('.announce-wrap').css("display", "flex");
                        $("#aList").append(`<li>${popularc[i].Title}</li> <div class="action-buttons"> <button title="${(favtdata.filter(list =>  list.EmployeeEmail === loggedUserMail && list.Course === `${popularc[i].Title}` ).length) >0 ? `Added to your favorite` : `Add to Favorite`}" onclick="${(favtdata.filter(list =>  list.EmployeeEmail === loggedUserMail && list.Course === `${popularc[i].Title}` ).length) >0 ? false: `openConfirmation('${popularc[i].Title.replace(/'/g, "\\'")}','${popularc[i].Category.replace(/'/g, "\\'")}','${popularc[i].Sections.replace(/'/g, "\\'")}','${popularc[i].NavigateURL.Url}','${popularc[i].ImageURL.Url}','${popularc[i].SectionOverview}','${popularc[i].Author0.replace(/'/g, "\\'")}','${popularc[i].AboutAuthor.replace(/'/g, "\\'")}')`}"><img src="${(favtdata.filter(list =>  list.EmployeeEmail === loggedUserMail && list.Course === `${popularc[i].Title}` ).length) >0 ? `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Favoriteicon.png` : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/favoriteadd-removebg-preview.png`}" width=20px height=20px/></button>   <button title="Start Course" onclick="openConfirmationIP('${popularc[i].Title}','${popularc[i].Category.replace(/'/g, "\\'")}','${popularc[i].Sections.replace(/'/g, "\\'")}','${popularc[i].NavigateURL.Url}','${popularc[i].Author0.replace(/'/g, "\\'")}','${popularc[i].AboutAuthor.replace(/'/g, "\\'")}')"><img src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/StartCourse.png" width=20px height=20px/></button> </div>`);

            }
}



function openConfirmation(course,category,section,navigateURL,imgurl,secover,author,authorinfo) {
  // Show the confirmation popup
  document.getElementById("confirmationPopupfav8").style.display = "flex";
debugger;
  // Pass the data to a global variable (or you can use other ways to pass the data)
  // Store the parameters in an object
  window.confirmationParams = {
    param1: course,
    param2: category,
    param3: section,
    param4: navigateURL,
    param5: imgurl,
    param6:secover,
    param7:author,
    param8:authorinfo
  };
}

function confirmAction() {
  // Get the stored data
  // Get the stored parameters
  debugger;
  var params = window.confirmationParams;

  // Access the parameters using the property names
  var param1 = params.param1;
  var param2 = params.param2;
  var param3 = params.param3;
  var param4 = params.param4;
  var param5 = params.param5;
  var param6 = params.param6;
  var param7 = params.param7;
  var param8 = params.param8;

  // Store the data
  addRecordTofavt(param1,param2,param3,param4,param5,param6,param7,param8);

  // Hide the confirmation popup
  document.getElementById("confirmationPopupfav8").style.display = "none";
}

function cancelAction() {
  // Hide the confirmation popup
  document.getElementById("confirmationPopupfav8").style.display = "none";
}

//

//open inprogress popup
function openConfirmationIP(course,category,section,navigateURL,authorname,aboutauthor) {
  // Show the confirmation popup
  document.getElementById("confirmationPopupIP").style.display = "flex";
debugger;
  // Pass the data to a global variable (or you can use other ways to pass the data)
  // Store the parameters in an object
  window.confirmationParams = {
    param1: course,
    param2: category,
    param3: section,
    param4: navigateURL,
    param5: authorname,
    param6:aboutauthor
  };
}

function confirmActionIP() {
  // Get the stored data
  // Get the stored parameters
  debugger;
  var params = window.confirmationParams;

  // Access the parameters using the property names
  var param1 = params.param1;
  var param2 = params.param2;
  var param3 = params.param3;
  var param4 = params.param4;
  var param5 = params.param5;
  var param6 = params.param6;

  // Store the data
  addRecordToList(param1,param2,param3,param4,param5,param6);

  // Hide the confirmation popup
  document.getElementById("confirmationPopupIP").style.display = "none";
}

function cancelActionIP() {
  // Hide the confirmation popup
  document.getElementById("confirmationPopupIP").style.display = "none";
}



//add to inprogress
function addRecordToList(course,category,section,navigateURL,authorname,aboutauthor){
  debugger;

var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
var listName = 'LMS Learner';
// Endpoint URL
var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/items";
var storevalue =[];
$.ajax({
    url: url,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
      storevalue = data.d.results;
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
storevalue = storevalue.filter(item => item.Course ===course &&item.Category ===category && item.EmployeeEmail.toLocaleLowerCase() ===loggedUserMail.toLocaleLowerCase())
if(storevalue.length == 0){
var Section = section; 
var numSections = parseInt(Section, 10);
var itemTitles = [];
for (var i = 1; i <= numSections; i++) {
  itemTitles.push("Topic " + i);
}
function createItem(title) {
var hyperlinkValuenav = {
    "__metadata": { "type": "SP.FieldUrlValue" },
    "Url": navigateURL,
    "Description": "nav link"
  };

  // Request payload for each item
  var payload = {
    '__metadata': { 'type': 'SP.Data.LMS_x0020_LearnerListItem' }, 
    'Title': userName,
    'Category': category,
    'Section': title,
    'Course' : course,
    'EmployeeEmail' :loggedUserMail,
    'AuthorName':authorname,
    'AboutAuthor':aboutauthor,
    'NavigateURL':hyperlinkValuenav,
    'CourseStatus' : 'InProgress'
  };

// Refresh the Request Digest value
$.ajax({
  url: siteUrl + "/_api/contextinfo",
  method: "POST",
  headers: { "Accept": "application/json;odata=verbose" },
  success: function(data) {
    var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

    // Make the AJAX POST request with the refreshed Request Digest value
    $.ajax({
      url: url,
      type: "POST",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": requestDigest
      },
      data: JSON.stringify(payload),
      success: function(data) {
        console.log("Item created successfully.");
        lmsData = [];
        lmsData1=[];
        lsrdata=[];
        results=[];
        filteredItems = [];
        lmsfunc();
        appendlms();
        // Handle success
      },
      error: function(error) {
        console.log("Error creating item: " + JSON.stringify(error));
        // Handle error
      }
    });
  },
  error: function(error) {
    console.log("Error refreshing Request Digest: " + JSON.stringify(error));
    // Handle error
  }
});
}


// Create items in a loop
for (var i = 0; i < itemTitles.length; i++) {
  createItem(itemTitles[i]);
}
}
}

