var rencataEmpApiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Kudos Repository')/items?&$filter=(Deleted eq 0)";
var rencataBadgeApiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Techathon User Badge')/items";
var notificationAPIPath = [] ;
var myJsonString, carouselJsonString, sliderTitle, sliderImg, sliderOrder, slideCatogey; //To store the data into JSON format
var todayDate = new Date();
var istTodayDate;
var todayBdayEmp = [];
var todayBdayEmps2 = [];
var todayBadgeEmp=[];
var todayAnnivarsary = [];
var todayjoinees = [];
var rencataEmpList = [];
var rencataBadgeList = [];
var notificationList = [];
var userEmail;
var userid = _spPageContextInfo.userId;
var requestUri = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";

if (todayDate.getTimezoneOffset() == 480) {

    istTodayDate = new Date(todayDate);

} else istTodayDate = todayDate;
var presentMonth = istTodayDate.getMonth() + 1;
var pastmonth=istTodayDate.getMonth();
var presentDate = istTodayDate.getDate();
//var last = new Date(todayDate.getTime() - (days * 24 * 60 * 60 * 1000));
var pastDate =new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) ;
var pastDate =pastDate.getDate();
//var pastDate = istTodayDate.getDate() - 7;
var presentYear = istTodayDate.getFullYear();

$.ajax({
    url: requestUri,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        userEmail = data.d.Email.toLowerCase();
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});




/***Carosel Management *****/

function GetRencataEmpList() {
    
    $.ajax({
        url: rencataEmpApiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            for (i = 0; i < data.d.results.length; i++) {
                rencataEmpList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                rencataEmpApiPath = data.d.__next;
                GetRencataEmpList();
                return;
            }



            var empBirthMonth;
            rencataEmpList;
            if (rencataEmpList.length > 0) {
                for (i = 0; i < rencataEmpList.length; i++) {
                    let empDOB = new Date(new Date(rencataEmpList[i].Created).toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
}));
                    empBirthMonth = empDOB.getFullYear();
                    empBirthDate = empDOB.getDate();


                    if (((presentDate == empBirthDate) || ( empBirthDate >= pastDate)) && (presentYear == empBirthMonth)) {
                        todayBdayEmp.push({ name: rencataEmpList[i].EmployeeName, mailId: rencataEmpList[i].EmployeeEmail, empPic:rencataEmpList[i].PhotoURL})
                        
                    }
                    
                  
                }
                //extra add
                  if(todayBdayEmp.length>=15){
                      todayBdayEmps2 = [...todayBdayEmp];
                      todayBdayEmp=todayBdayEmp.slice(0, 15);
                      todayBdayEmps2=todayBdayEmps2.slice(15,31);

                  }
//
            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};



/*** Badge data */

function GetRencataBadgeList() {
    debugger;
    $.ajax({
        url: rencataBadgeApiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            for (i = 0; i < data.d.results.length; i++) {
                rencataBadgeList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                rencataBadgeApiPath = data.d.__next;
                GetRencataBadgeList();
                return;
            }



            var empYearMonth;
            var empBadgeMonth;
            var emppastBadgeMonth;
            rencataBadgeList;
            if (rencataBadgeList.length > 0) {
                for (i = 0; i < rencataBadgeList.length; i++) {
                    let empBDate = new Date(new Date(rencataBadgeList[i].Created).toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
}));
                    empYearMonth = empBDate.getFullYear();
                    empBadgeDate = empBDate.getDate();
                    empBadgeMonth=empBDate.getMonth()+1;
                    emppastBadgeMonth=empBDate.getMonth()


                 if(presentDate<=7 && ((presentDate == empBadgeDate) || ( empBadgeDate >= pastDate)) && ( presentYear == empYearMonth)&& presentMonth==empBadgeMonth){todayBadgeEmp.push({ create:rencataBadgeList[i].Created, name: rencataBadgeList[i].UserName, mailId: rencataBadgeList[i].UserEmail, empPic:rencataBadgeList[i].PhotoURL})}

                    else if (presentDate>7 &&((presentDate == empBadgeDate) || ( empBadgeDate >= pastDate)) && ( presentYear == empYearMonth)&& presentMonth==empBadgeMonth &&pastmonth==emppastBadgeMonth ) {
                        todayBadgeEmp.push({ create:rencataBadgeList[i].Created, name: rencataBadgeList[i].UserName, mailId: rencataBadgeList[i].UserEmail, empPic:rencataBadgeList[i].PhotoURL})
                    }
                  

                }
            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};

/*End*/


/* JSON Sort method */

function GetSortOrder(prop) {
    return function (a, b) {
        if (a[prop] > b[prop]) {
            return 1;
        } else if (a[prop] < b[prop]) {
            return -1;
        }
        return 0;
    }
};

/**************** slider JSON DATA ***************/
function GetSlierListItems() {
    var apiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Carousel Management')/items";
    $.ajax({
        url: apiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {

            carouselJsonString = data.d.results.filter(data => data.SlideImages);

            if (carouselJsonString.length > 0) {
                carouselJsonString.sort(GetSortOrder("SlideOrder"));
                $('.rencata-slides').empty()
                for (i = 0; i < carouselJsonString.length; i++) {
                    slideCatogey = carouselJsonString[i].Category;
                    sliderTitle = carouselJsonString[i].Title;
                    sliderOrder = carouselJsonString[i].SlideOrder;
                    sliderState = carouselJsonString[i].State;
                    sliderImg = carouselJsonString[i].SlideImages.slice(carouselJsonString[i].SlideImages.indexOf("/site"), carouselJsonString[i].SlideImages.indexOf('"id"') - 2);


                  if (slideCatogey == "Kudos" && todayBdayEmp.length > 0 && sliderState == "Active") {

                        $('.rencata-slides').append('<div id="Birthday" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Birthday').append('<h2> t </h2><div class="emp-list"></div>');
                        for (j = 0; j < todayBdayEmp.length; j++) {
                            let empPhoto = todayBdayEmp[j].empPic ? todayBdayEmp[j].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empname = todayBdayEmp[j].name;
                            let empMail = todayBdayEmp[j].mailId ? "mailto:"+todayBdayEmp[j].mailId +"?subject=kudos to you!!" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div title= "${empname}" class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayBdayEmp[j].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#Birthday .emp-list').append(content);
                        }

                    } 

                    //addmore
                    if (slideCatogey == "Kudos" && todayBdayEmps2.length > 0 && sliderState == "Active") {

                        $('.rencata-slides').append('<div id="kudos" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#kudos').append('<h2> t </h2><div class="emp-list"></div>');
                        for (j = 0; j < todayBdayEmps2.length; j++) {
                            let empPhoto = todayBdayEmps2[j].empPic ? todayBdayEmps2[j].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empname = todayBdayEmps2[j].name;
                            let empMail = todayBdayEmps2[j].mailId ? "mailto:"+todayBdayEmps2[j].mailId +"?subject=kudos to you!!" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div title= "${empname}" class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayBdayEmps2[j].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#kudos .emp-list').append(content);
                        }

                    } 
                  

                  if (slideCatogey == "Badge" && todayBadgeEmp.length > 0 && sliderState == "Active") {
                        $('.rencata-slides').append('<div id="Anniversary" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Anniversary').append('<h2> Badge </h2><div class="emp-list"></div>');
                        for (j = 0; j < todayBadgeEmp.length; j++) {
                            let empPhoto = todayBadgeEmp[j].empPic ? todayBadgeEmp[j].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empname = todayBadgeEmp[j].name;
                            let empMail = todayBadgeEmp[j].mailId ? "mailto:"+todayBadgeEmp[j].mailId +"?subject=Congrats to you!!" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div title= "${empname}" class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayBadgeEmp[j].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#Anniversary .emp-list').append(content);
                        }

                    } 



                    if (slideCatogey == "Others" && sliderState == "Active") {
                        
                        $('.rencata-slides').append(`<div class="rencata-slide"><img src="${sliderImg}" title="${sliderTitle}" /><div class="slide-title">${sliderTitle}</div></div>`);
                    }
                }
            }
        },

        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};



function openVideoModel(id){
                
let vidContent
if(data.Video_x002f_Link== "Video") {
  vidContent = `<video width="100%" height="360" controls>
  <source src="${data[0].Video.Url}" type="video/mp4">
</video>`
} else {
     vidContent = `<ul class="nav nav-tabs">
		<!--	<li>
				<a href="javascript:void(0)" data-toggle="tab" href="#holiactive">2023
					</a>
				</li> -->
				
				<li class="active">
					<a data-toggle="tab" href="#holirest" data-placement="bottom" title="holirest" >Rest of the year
					</a>
				</li>
                </ul>`
}
$('#announceModel .modal-title').html(`${data[0].Title}`)
$("#an-notes").html(vidContent);
$('#announceModel .modal-body a').attr('target','_blank');
$('#announceModel .modal-body a').css({'font-weight':'500','text-decoration':'underline'});
$('#announceModel').modal('show')
};

$('#announceModel').on('hidden.bs.modal', function (e) {
  $("#an-notes").empty()
})


			
var openModelBox = (name,isIframe,Url,modelW,iframeW,iframeH,closeFunc) =>{
  let content;
  isIframe ? content = `<iframe src="${Url}" width="${iframeW}" height="${iframeH}" frameborder="0" allowtransparency="true">
</iframe>` : content = `<embed src="${Url}" frameborder="0" width="100%" height="600px">`
  let model = `<div class="modal fade" id="model-${name}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false" aria-hidden="true">
<div class="modal-dialog" style="width:${modelW}">
	<div class="modal-content">
    <button type="button" class="btn btn-default" data-dismiss="modal" onclick="${closeFunc}">View Archive Year</button>
		<div class="modal-body" style="display:flex; justify-content:center">
          ${content}
              </div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal" onclick="${closeFunc}">Close</button>
		</div>
	</div>
</div>
</div>`;
  $('body').append(model);
  $('#model-'+name).modal('show');
  }
  

