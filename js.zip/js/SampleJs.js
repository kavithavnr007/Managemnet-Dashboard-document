 var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Student Form')/items"
 var studentData =[];

 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }

function showstdet(){
  debugger;
var stdwrap = $('.student'); //document.getElementByClass('student')
stdwrap.empty();
for(i=0;i<studentData.length; i++){
   stdwrap.append(`<div style="border: 1px solid;padding: 10px;display: flex;gap: 10px;">${studentData[i].Title} <button onclick="showpopup(${studentData[i].ID})" style="width:80px">Show PopUp</button></div>`) 
}
}



function savestd(){
    debugger;
// SharePoint site URL
var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
// SharePoint list name
var listName = 'Student Form';

// Endpoint URL
var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/items";
// Request paydata for each item
 var payload ={
     '__metadata': {'type': 'SP.Data.Student_x0020_FormListItem'}, 
    'Title':".NET"
}

// Refresh the Request Digest value
$.ajax({
  url: siteUrl + "/_api/contextinfo",
  method: "POST",
  headers: { "Accept": "application/json;odata=verbose" },
  success: function(data) {
    var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

    // Make the AJAX POST request with the refreshed Request Digest value
    $.ajax({
      url: url,
      type: "POST",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": requestDigest
      },
      data: JSON.stringify(payload),
      success: function(data) {
        console.log("Item created successfully.");
        showstdet();
      },
      error: function(error) {
        console.log("Error creating item: " + JSON.stringify(error));
        // Handle error
      }
    });
  },
  error: function(error) {
    console.log("Error refreshing Request Digest: " + JSON.stringify(error));
    // Handle error
  }
});
}



//delete record
function deleteRecordFromList(itemId) {
  debugger;
  var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
  var listName = 'Student Form';

  // Endpoint URL
  var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/getItemById(" + itemId + ")";

  // Refresh the Request Digest value
  $.ajax({
    url: siteUrl + "/_api/contextinfo",
    method: "POST",
    headers: { "Accept": "application/json;odata=verbose" },
    success: function(data) {
      var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

      // Make the AJAX POST request with the refreshed Request Digest value
      $.ajax({
        url: url,
        type: "POST",
        headers: {
          "Accept": "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose",
          "X-RequestDigest": requestDigest,
          "X-HTTP-Method": "DELETE",
          "If-Match": "*"
        },
        success: function(data) {
                $(".popup").css('display','none');
                studentdet();
                showstdet();
                console.log("Item deleted successfully.");
        },
        error: function(error) {
          console.log("Error deleting item: " + JSON.stringify(error));
          // Handle error
        }
      });
    },
    error: function(error) {
      console.log("Error refreshing Request Digest: " + JSON.stringify(error));
      // Handle error
    }
  });
}


//edit

function getFormDigest() {
            return $.ajax({
                url: _spPageContextInfo.webAbsoluteUrl + "/_api/contextinfo",
                method: "POST",
                headers: { "Accept": "application/json; odata=verbose" }
            });
        }

        function editSharePointData(id) {
            var itemID = id;
            var newDescription = $('#newDescription').val();

            var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
            var listName = 'Student Form';
            var endpointUrl = siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items(" + itemID + ")";

            getFormDigest().then(function (data) {
                var formDigestValue = data.d.GetContextWebInformation.FormDigestValue;

                 var itemPayload = {
                __metadata: { 'type': 'SP.Data.Student_x0020_FormListItem' },
                Title: "edit Test entry"
            };

                $.ajax({
                    url: endpointUrl,
                    type: 'POST',
                    contentType: 'application/json;odata=verbose',
                    data: JSON.stringify(itemPayload),
                    headers: {
                        'X-RequestDigest': formDigestValue,
                        'IF-MATCH': '*',
                        'X-HTTP-Method': 'MERGE'
                    },
                    success: function (data) {
                       $(".popup").css('display','none');
                studentdet();
                showstdet();
                        alert('Item updated successfully!');
                    },
                    error: function (error) {
                        alert('Error updating item: ' + JSON.stringify(error));
                    }
                });
            });
        }

//show popup

function showpopup(id){
  debugger;
$(".popup").css('display','block');
window.confirmationparams ={
  param1:id
}
}

//confirmdel
function confirmdel(){
  debugger;
  var params = window.confirmationparams;
   var param1 =params.param1;
   editSharePointData(param1);
}

//closepopup

function closepopup(){
debugger;
$(".popup").css('display','none');
}
