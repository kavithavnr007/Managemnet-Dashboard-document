var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Topic Evaluation User Badge')/items"
 var studentData =[];

function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }
// Function to fetch and populate Super Parent dropdown from SharePoint
function populateSuperParentDropdown() {
$.ajax({
url: studentpath,
method: "GET",
headers: {
"Accept": "application/json; odata=verbose"
},
success: function (data) {
var superParentDropdown = $("#superParentDropdown");
superParentDropdown.empty();
superParentDropdown.append("<option value=''>Select Super Parent</option>");

 studentData .forEach(function (item) {
superParentDropdown.append("<option value='" + item.Id + "'>" + item.Title + "</option>");
});
},
error: function (error) {
console.log(error);
}
});
}

// Function to fetch and populate Parent dropdown from SharePoint based on selected Super Parent
function populateParentDropdown(superParentId) {
  debugger
$.ajax({
url: "/_api/web/lists/getbytitle('YourParentList')/items?$filter=SuperParentId eq " + superParentId,
method: "GET",
headers: {
"Accept": "application/json; odata=verbose"
},
success: function (data) {
var parentDropdown = $("#parentDropdown");
parentDropdown.empty();
parentDropdown.append("<option value=''>Select Parent</option>");

data.d.results.forEach(function (item) {
parentDropdown.append("<option value='" + item.Id + "'>" + item.Title + "</option>");
});
},
error: function (error) {
console.log(error);
}
});
}

// Function to fetch and populate Child dropdown from SharePoint based on selected Parent
function populateChildDropdown(parentId) {
$.ajax({
url: "/_api/web/lists/getbytitle('YourChildList')/items?$filter=ParentId eq " + parentId,
method: "GET",
headers: {
"Accept": "application/json; odata=verbose"
},
success: function (data) {
var childDropdown = $("#childDropdown");
childDropdown.empty();
childDropdown.append("<option value=''>Select Child</option>");

data.d.results.forEach(function (item) {
childDropdown.append("<option value='" + item.Id + "'>" + item.Title + "</option>");
});
},
error: function (error) {
console.log(error);
}
});
}

// Populate Super Parent dropdown on page load
populateSuperParentDropdown();

// Event handler for Super Parent dropdown change
$("#superParentDropdown").change(function () {
var selectedSuperParentId = $(this).val();

if (selectedSuperParentId) {
// Populate Parent dropdown based on the selected Super Parent
populateParentDropdown(selectedSuperParentId);
} else {
// Clear Parent and Child dropdowns if no Super Parent is selected
$("#parentDropdown").empty();
$("#childDropdown").empty();
$("#parentDropdown").append("<option value=''>Select Parent</option>");
$("#childDropdown").append("<option value=''>Select Child</option>");
}
});

// Event handler for Parent dropdown change
$("#parentDropdown").change(function () {
var selectedParentId = $(this).val();

if (selectedParentId) {
// Populate Child dropdown based on the selected Parent
populateChildDropdown(selectedParentId);
} else {
// Clear Child dropdown if no Parent is selected
$("#childDropdown").empty();
$("#childDropdown").append("<option value=''>Select Child</option>");
}
});