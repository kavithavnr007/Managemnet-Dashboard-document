/***LMS favorite*****/

var favtPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS favorite')/items?&$top=5000"
var emresultPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Topic Evaluation User Badge')/items?&$top=5000"
var cmptPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Course Evaluation User Badge')/items?&$top=5000&$orderby=Modified desc"
var cmtdocPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Completed Course Certificate')/items?&$top=5000"
var wishlistpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('WishList Course')/items?&$top=5000"
var cmptdata =[];
var cmtdocData =[];
var emresultdata =[];
var results=[];
var favtdata =[];
var wishlistdata=[];
var allWishlistdata=[];
var top10Scores=[];
var loggedUserPath = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + _spPageContextInfo.userId + ")";
var loggedUserMail,myEmail,userName,reportingManager,employeeID =[];

function favtfunc() {
debugger;
$.ajax({
    url: loggedUserPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        loggedUserMail = data.d.Email;
        userName = data.d.Title;
        console.log("Logged-in user: " + userName);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});

// Make an AJAX request to SharePoint REST API
$.ajax({
  url: _spPageContextInfo.webAbsoluteUrl + "/_api/SP.UserProfiles.PeopleManager/GetMyProperties",
  method: "GET",
  headers: {
    "Accept": "application/json;odata=verbose",
    "Content-Type": "application/json;odata=verbose",
    "X-RequestDigest": $("#__REQUESTDIGEST").val()
  },
  success: function(data) {
    // Handle the successful response here
    var extendedManagers = data.d.ExtendedManagers.results;
    var lastManagerEmail = extendedManagers[extendedManagers.length - 1];
    
    // Extract the email portion
    reportingManager = lastManagerEmail.split("|")[2];
    console.log("Reporting Manager Email:", reportingManager);
    var employeeID = data.d.ExtendedManagers.results[0].AccountName;
    console.log("Employee ID:", employeeID);
  },
  error: function(xhr, status, error) {
    // Handle the error here
    console.error("Error:", error);
  }
});


//

$.ajax({
    url: favtPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        favtdata = data.d.results;
        console.log("favt list: " + favtdata);
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});


$.ajax({
    url: emresultPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        emresultdata = data.d.results;
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});

$.ajax({
    url: cmptPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        cmptdata = data.d.results;

        // Sort the data based on the score column (assuming the column name is "Score")
        cmptdata.sort(function(a, b) {
            return b.Score - a.Score;
        });

        // Get the top 10 scores
        top10Scores = cmptdata.slice(0, 10);
        top10Scores= top10Scores.filter(item=> item.Score >= 50)
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});

$.ajax({
    url: cmtdocPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        cmtdocData = data.d.results;
        console.log("my certificate" + cmtdocData);
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
//get wishlist data
$.ajax({
    url: wishlistpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        wishlistdata = data.d.results;
        allWishlistdata = data.d.results;
        wishlistdata= wishlistdata.filter(item => item.Title.toLowerCase() == loggedUserMail.toLowerCase() && item.Status =="InProgress")

    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});


}


//external user or internal user

function isExternalUser() {
      var email = loggedUserMail;

      // Get the domain part of the email address
      var emailDomain = email.substring(email.indexOf("@") + 1);

      // Compare the domain with your organization's domain
      var organizationDomain = "rencata.com";
      var isExternal = emailDomain.toLowerCase() !== organizationDomain;
      var elements = document.getElementsByClassName("containerlog");

for (var i = 0; i < elements.length; i++) {
  var element = elements[i];
  element.style.height = window.innerHeight + "px";
}
      if (isExternal) {
        $(".containerlog").show();
        console.log("The logged-in user is an external user.");
      } else {
        $(".containerlog").show();
        console.log("The logged-in user is not an external user.");
      }
    
 
}



//end of the user chk code


function appendfavt(){
$('.clear-course').hide();
$('.norecordcrs').hide();
const searchcInput = document.getElementById("searchcourse");
searchcInput.value="";
let favtWrap = $('.favt-wrap');
favtWrap.empty();
$('.scrollcrs').show();

// Sort the data based on the sort direction and column<img title="Your favorite"  align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/favorite.png" style="border:none;border-radius:0%;width: 12px;height: 12px;margin-left: 140px;float: right;position: absolute;">
 favtdata.sort((a, b) => {
  if (a.Title < b.Title) {
    return -1;
  }
  if (a.Title > b.Title) {
    return 1;
  }
  return 0;
});

favtdata = favtdata.filter(list =>  list.EmployeeEmail === loggedUserMail);
document.getElementById('addcount').innerHTML = 'Favorite ( ' + favtdata.length +' )' ;
if(favtdata.length > 0){
$('.favt-wrap').empty();
$('.favt-container').show()
for (k=0; k<favtdata.length; k++){

favtWrap.append(`<div class="post" onclick=""><img align="left" src="${ favtdata[k].ImageURL ? (favtdata[k].ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius: 15%;width:80px;height: 70px;margin-top: 5px;"/>
<img title="Remove your favorite"  onclick="deleteRecordFromList(${favtdata[k].ID})" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/favorite.png" style="cursor: pointer;border:none;border-radius:0%;width: 20px;height: 20px;float: right;">

<a title="Start Course" target="_blank" data-interception="off" href="${favtdata[k].NavigateURL ? favtdata[k].NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}">
<img title="Start Course" onclick="addRecordToList('${favtdata[k].Course.replace(/'/g, "\\'")}','${favtdata[k].Category.replace(/'/g, "\\'")}','${favtdata[k].Section.replace(/'/g, "\\'")}','${favtdata[k].NavigateURL.Url.replace(/'/g, "\\'")}','${favtdata[k].Author0.replace(/'/g, "\\'")}','${favtdata[k].AboutAuthor.replace(/'/g, "\\'")}')" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="cursor: pointer;border:none;border-radius:0%;width: 30px;height: 80px;padding-bottom: 8%;margin-top: 5%;"></a>

<p style="font-size: 100%; color:#3d8084;">${favtdata[k].Course.replace(/<[^>]*>?/gm, '')}</p>
<P> ${favtdata[k].SectionOverview}</p></div>`)

}
}
else{
    let favtWrap = $('.favt-wrap');
favtWrap.empty();
$('.favt-container').hide();
$('.norecordcrs').show();
$('.scrollcrs').hide();
}
}



// Assuming 'sharepointData' is the array of SharePoint data
function searchcourse(inputValue) {
    debugger;
  const searchResults = favtdata.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search
    return item.Course.toLowerCase().includes(inputValue.toLowerCase())&& item.EmployeeEmail === loggedUserMail;
  });
  return searchResults;
}

// Get a reference to the input element
const searchcInput = document.getElementById("searchcourse");

// Add the onchange event handler to the input element
searchcInput.onchange = function() {
  
  const inputValue = searchcInput.value;
  if(inputValue.length >0){
     $('.clear-course').show()  
  }
  else{
    appendfavt();
    const searchcInput = document.getElementById("searchcourse");
    searchcInput.value="";
      $('.clear-course').hide()  
  };
  var results = searchcourse(inputValue);
  console.log(results);


if(results.length > 0){
let favtWrap = $('.favt-wrap');
favtWrap.empty();
$('.favt-container').show()
for (k=0; k<results.length; k++){

favtWrap.append(`<div class="post" onclick=""><img align="left" src="${ results[k].ImageURL ? (results[k].ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius: 15%;width:80px;height: 70px;margin-top: 5px;"/>
<img title="Remove your favorite"  onclick="deleteRecordFromList(${results[k].ID})" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/favorite.png" style="cursor: pointer;border:none;border-radius:0%;width: 20px;height: 20px;float: right;">

<a title="Start Course" target="_blank" data-interception="off" href="${results[k].NavigateURL ? results[k].NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}">
<img title="Start Course" onclick="addRecordToList('${results[k].Course.replace(/'/g, "\\'")}','${results[k].Category.replace(/'/g, "\\'")}','${results[k].Section.replace(/'/g, "\\'")}','${results[k].NavigateURL.Url.replace(/'/g, "\\'")}','${results[k].Author0.replace(/'/g, "\\'")}','${results[k].AboutAuthor.replace(/'/g, "\\'")}')" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="cursor: pointer;border:none;border-radius:0%;width: 30px;height: 80px;padding-bottom: 8%;margin-top: 5%;"></a>

<p style="font-size: 100%; color:#3d8084;">${results[k].Course.replace(/<[^>]*>?/gm, '')}</p>
<P> ${results[k].SectionOverview}</p></div>`)

}
}
else{
    let favtWrap = $('.favt-wrap');
favtWrap.empty();
$('.favt-container').hide();
$('.norecordcrs').show();
$('.scrollcrs').hide();
}
}


function evalresult(){
  var inputBox = document.getElementById("searcheval");
  inputBox.value = "";
 $('.clear-eval').hide();  
emresultdata = emresultdata.filter(list =>  list.UserEmail.toLowerCase() === loggedUserMail.toLowerCase());
document.getElementById('evacount').innerHTML = 'Evaluation Result ( ' + emresultdata.length +' )' ;
if(emresultdata.length>0){
  $('.btn-export').show();
  $('.resultview').show();
  $('.norecordeva').hide();
var tableData = emresultdata.map(value => {
  return (
    `<tr>
       <td>${value.Category1}</td>
       <td>${value.Category}</td>
       <td>${value.Section}</td>
       <td>${new Date(value.Created).toString().slice(4,15)}</td>
       <td>${value.Score}</td>
       <td>${value.TOTALTime}</td>
    </tr>`
  );
}).join('');

const tableBody = document.querySelector("#resultBody");
tableBody.innerHTML = tableData;
}

else{
  $('.btn-export').hide();
  $('.resultview').hide();
  $('.norecordeva').show();
}
}

//document.addEventListener("DOMContentLoaded", function() {
function cmpltfunc(){
var inputBox = document.getElementById("searchcmpt");
  inputBox.value = "";
 $('.clear-cmpt').hide(); 
cmptdata = cmptdata.filter(list =>  list.UserEmail.toLowerCase() === loggedUserMail.toLowerCase());
document.getElementById('cmtcount').innerHTML = 'Completed Course ( ' + cmptdata.length +' )' ;
if(cmptdata.length>0){
  $('.btn-exportcmpt').show();
  $('.norecordcmpt').hide();
  $('.cmpltview').show();
var tableData = cmptdata.map(value => {
  return (
    `<tr>
       <td>${value.Category1}</td>
       <td>${value.Category}</td>
       <td>${value.Section}</td>
       <td>${value.Score}</td>
       <td>${value.Badge}</td>
       <td>${new Date(value.Created).toString().slice(4,15)}</td>
    </tr>`
  );
}).join('');

const tableBody = document.querySelector("#cmptBody");
tableBody.innerHTML = tableData;
}
 else{
    $('.btn-exportcmpt').hide();
   $('.cmpltview').hide();
   $('.norecordcmpt').show();
 }

}
//})

// Assuming 'sharepointData' is the array of SharePoint data
function searcheval(inputValue) {
  emresultdata = emresultdata.filter(list =>  list.UserEmail.toLowerCase() === loggedUserMail.toLowerCase());
  const searchResults = emresultdata.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search   
    return item.Category1.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Get a reference to the input element


// Add the onchange event handler to the input element
//searchevalInput.onchange = 
function searchevalInput() {
  var searchevalInput = document.getElementById("searcheval");
  const inputValue = searchevalInput.value;
  if(inputValue.length >0){
     $('.clear-eval').show()  
  }
  else{
    var inputBox = document.getElementById("searcheval");
  inputBox.value = "";
    evalresult();
      $('.clear-eval').hide()  
  };
  var results = searcheval(inputValue);
  console.log(results);


if(results.length > 0){
$('.btn-export').show();
$('.resultview').show();
  $('.norecordeva').hide();
var tableData = results.map(value => {
  return (
    `<tr>
       <td>${value.Category1}</td>
       <td>${value.Category}</td>
       <td>${value.Section}</td>
       <td>${new Date(value.Created).toString().slice(4,15)}</td>
       <td>${value.Score}</td>
       <td>${value.TOTALTime}</td>
    </tr>`
  );
}).join('');

const tableBody = document.querySelector("#resultBody");
tableBody.innerHTML = tableData;
}
else{
  const tableBody = document.querySelector("#resultBody");
tableBody.innerHTML = "";
$('.btn-export').hide();
  $('.resultview').hide();
  $('.norecordeva').show();
}
}




//search cmplt course


// Assuming 'sharepointData' is the array of SharePoint data
function searchcmpt(inputValue) {
  debugger;
  cmptdata = cmptdata.filter(list =>  list.UserEmail.toLowerCase() === loggedUserMail.toLowerCase());
  const searchResults = cmptdata.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search   
    return item.Category1.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Get a reference to the input element


// Add the onchange event handler to the input element
//searchcmptInput.onchange = 
function searchcmptInput() {
  debugger;
  var searchcmptInput = document.getElementById("searchcmpt");
  const inputValue = searchcmptInput.value;
  if(inputValue.length >0){
     $('.clear-cmpt').show()  
  }
  else{
    var inputBox = document.getElementById("searchcmpt");
  inputBox.value = "";
    cmpltfunc();
      $('.clear-cmpt').hide()  
  };
  var results = searchcmpt(inputValue);
  console.log(results);


if(results.length > 0){
  $('.btn-exportcmpt').show();
$('.norecordcmpt').hide();
  $('.cmpltview').show();
var tableData = results.map(value => {
  return (
    `<tr>
       <td>${value.Category1}</td>
       <td>${value.Category}</td>
       <td>${value.Section}</td>
       <td>${value.Score}</td>
       <td>${value.Badge}</td>
       <td>${new Date(value.Created).toString().slice(4,15)}</td>
    </tr>`
  );
}).join('');

const tableBody = document.querySelector("#cmptBody");
tableBody.innerHTML = tableData;
}
 else{
   const tableBody = document.querySelector("#cmptBody");
   tableBody.innerHTML = "";
   $('.btn-exportcmpt').hide();
   $('.cmpltview').hide();
   $('.norecordcmpt').show();
 }
}



//get document of certificate

//document.addEventListener("DOMContentLoaded", function() {
function certificateresult(){
  debugger;
  var inputBox = document.getElementById("searchcertify");
  inputBox.value = "";
 $('.clear-certify').hide();  
cmtdocData = cmtdocData.filter(list =>  list.UserEmail.toLowerCase() === loggedUserMail.toLowerCase());
document.getElementById('certificatcount').innerHTML = 'Certificates ( ' + cmtdocData.length +' )' ;
if(cmtdocData.length>0){
  $('.scrollcertify').show();
  $('.nocertify').hide();
  let cwrap = $(".cContainer");
  cwrap.empty();
cmtdocData.map(items => cwrap.append(`  <div class="row-c">
<div class="div1">
    <p>Course Name</p>
    <p>Issued By</p>
    <p>Issued Date</p>
    <p>Validity Status</p>
    <p>Certificate</p>
  </div>
  <div class="div2">
    <p>${items.CourseName}</p>
    <p>RENCATA</p>
    <p>${new Date(items.Created).toString().slice(4,15)}</p>
    <p>Valid</p>
    <p style="padding-top: 0px;"><a href="${items.ServerRedirectedEmbedUri}" target="_blank()"><button title="Click to View Certificate" style="height: 23px;margin-top: 2px;font-size: 12px;">View Certificate</button></a>
    <button onclick="downloadPdf('${items.ID}')" title="Download PDF" style="height: 23px;border: none;background: white;padding-left: 5%;"><img src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/PDFIcon.png" width="20px" height="20px"></button></p>
  </div></div><hr class="separator">`)) 
}

else{
  //$('.btn-export').hide();
  $('.scrollcertify').hide();
  $('.nocertify').show();
}
}

//})



//search certificate


// Assuming 'sharepointData' is the array of SharePoint data
function searchcertificate(inputValue) {
  cmtdocData = cmtdocData.filter(list =>  list.UserEmail.toLowerCase() === loggedUserMail.toLowerCase());
  const searchResults = cmtdocData.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search   
    return item.CourseName.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Get a reference to the input element


// Add the onchange event handler to the input element
//searchcertifyInput.onchange = 
function searchcertifyInput() {
  var searchcertifyInput = document.getElementById("searchcertify");
  const inputValue = searchcertifyInput.value;
  if(inputValue.length >0){
     $('.clear-certify').show()  
  }
  else{
    certificateresult();
      $('.clear-certify').hide()  
  };
  var results = searchcertificate(inputValue);
  console.log(results);


if(results.length > 0){
let cwrap = $(".cContainer");
  cwrap.empty();
results.map(items => cwrap.append(`  <div class="row-c">
<div class="div1">
    <p>Course Name</p>
    <p>Issued By</p>
    <p>Issued Date</p>
    <p>Validity Status</p>
    <p>Certificate</p>
  </div>
  <div class="div2">
    <p>${items.CourseName}</p>
    <p>RENCATA</p>
    <p>${new Date(items.Created).toString().slice(4,15)}</p>
    <p>Valid</p>
    <p style="padding-top: 0px;"><a href="${items.ServerRedirectedEmbedUri}" target="_blank()"><button title="Click to View Certificate" style="height: 23px;margin-top: 2px;font-size: 12px;">View Certificate</button></a>
    <button onclick="downloadPDF('${items.ServerRedirectedEmbedUri}')" title="Download PDF" style="height: 23px;border: none;background: white;padding-left: 5%;"><img src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/PDFIcon.png" width="20px" height="20px"></button></p>
  </div></div><hr class="separator">`)) 
}
 else{
   $('.scrollcertify').hide();
   $('.nocertify').show();
 }
}



// download pdf

function downloadPdf(id) {
  debugger
  var fileUrl = `https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Completed Course Certificate')/items?$filter=ID eq '${id}'\&$select=FileRef`;
  //"https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle(Completed Course Certificate)/items?$filter=ID eq \"  +id + \&$select=FileRef";

 $.ajax({
    url: fileUrl,
    type: 'GET',
    headers: {
      'Accept': 'application/json;odata=verbose'
    },
    success: function (data) {
      if (data.d.results.length > 0) {
        var fileRef = data.d.results[0].FileRef;
        var fileName = fileRef.substring(fileRef.lastIndexOf('/') + 1);
        var downloadLink = document.createElement('a');
        downloadLink.href = fileRef;
        downloadLink.download = fileName;
        downloadLink.click();
      } else {
        console.log('Record not found');
      }
    },
    error: function (error) {
      console.log('Error:', error);
    }
  });
}


///Add to list


function addRecordToList(course,category,section,navigateURL,authorname,aboutauthor){
  debugger;

var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
var listName = 'LMS Learner';
// Endpoint URL
var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/items";
var storevalue =[];
$.ajax({
    url: url,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
      storevalue = data.d.results;
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
storevalue = storevalue.filter(item => item.Course ===course &&item.Category ===category && item.EmployeeEmail.toLocaleLowerCase() ===loggedUserMail.toLocaleLowerCase())
if(storevalue.length == 0){
var Section = section; 
var numSections = parseInt(Section, 10);
var itemTitles = [];
for (var i = 1; i <= numSections; i++) {
  itemTitles.push("Topic " + i);
}
function createItem(title) {
var hyperlinkValuenav = {
    "__metadata": { "type": "SP.FieldUrlValue" },
    "Url": navigateURL,
    "Description": "nav link"
  };

  // Request payload for each item
  var payload = {
    '__metadata': { 'type': 'SP.Data.LMS_x0020_LearnerListItem' }, 
    'Title': userName,
    'Category': category,
    'Section': title,
    'Course' : course,
    'EmployeeEmail' :loggedUserMail,
    'AuthorName':authorname,
    'AboutAuthor':aboutauthor,
    'NavigateURL':hyperlinkValuenav,
    'CourseStatus' : 'InProgress'
  };

// Refresh the Request Digest value
$.ajax({
  url: siteUrl + "/_api/contextinfo",
  method: "POST",
  headers: { "Accept": "application/json;odata=verbose" },
  success: function(data) {
    var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

    // Make the AJAX POST request with the refreshed Request Digest value
    $.ajax({
      url: url,
      type: "POST",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": requestDigest
      },
      data: JSON.stringify(payload),
      success: function(data) {
        console.log("Item created successfully.");
        lmsData = [];
        lmsData1=[];
        lsrdata=[];
        results=[];
        filteredItems = [];
        lmsfunc();
        appendlms();
        testeva();
        // Handle success
      },
      error: function(error) {
        console.log("Error creating item: " + JSON.stringify(error));
        // Handle error
      }
    });
  },
  error: function(error) {
    console.log("Error refreshing Request Digest: " + JSON.stringify(error));
    // Handle error
  }
});
}


// Create items in a loop
for (var i = 0; i < itemTitles.length; i++) {
  createItem(itemTitles[i]);
}
}
}



//remove or delete from the favt list


function deleteRecordFromList(itemId) {
  var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
  var listName = 'LMS favorite';

  // Endpoint URL
  var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/getItemById(" + itemId + ")";

  // Refresh the Request Digest value
  $.ajax({
    url: siteUrl + "/_api/contextinfo",
    method: "POST",
    headers: { "Accept": "application/json;odata=verbose" },
    success: function(data) {
      var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

      // Make the AJAX POST request with the refreshed Request Digest value
      $.ajax({
        url: url,
        type: "POST",
        headers: {
          "Accept": "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose",
          "X-RequestDigest": requestDigest,
          "X-HTTP-Method": "DELETE",
          "If-Match": "*"
        },
        success: function(data) {
          favtfunc();
          appendfavt();
             const searchcInput = document.getElementById("searchcourse");
             searchcInput.value="";
          console.log("Item deleted successfully.");
           results=[];
        populardata=[];
        favtdata =[];
        lmsfunc();
        favtfunc();
        appendfavt();
        displayAnnouncementOnHomePage();
          // Handle success
        },
        error: function(error) {
          console.log("Error deleting item: " + JSON.stringify(error));
          // Handle error
        }
      });
    },
    error: function(error) {
      console.log("Error refreshing Request Digest: " + JSON.stringify(error));
      // Handle error
    }
  });
}


//Leader Board
//document.addEventListener("DOMContentLoaded", function() {
function leaderboard(){
  debugger;
  var inputBox = document.getElementById("searchleader");
  inputBox.value = "";
 $('.clear-leader').hide();  
document.getElementById('leadercount').innerHTML = 'Leader Board - Course ( ' + top10Scores.length +' )' ;
if(top10Scores.length>0){
  $('.scrollleader').show();
  $('.noleader').hide();
  /*var tableData = top10Scores.map(value => {
  return (
    `<tr>
       <td>${value.UserName}</td>
       <td>${value.Category1}</td>
       <td>${value.Score}</td>
    </tr>`
  );
}).join('');
<div style="color: black;background: #b8cfe9;padding: 5px;border-radius: 10px 0px 0px 0px;"><div style="display: flex;flex-direction: row;gap: 10%;justify-content: space-between;"><p>${items.UserName}</p><p>${items.Category1}</p><p>${items.Score}</p> </div></div>
const tableBody = document.querySelector("#leaderBody");
tableBody.innerHTML = tableData;*/

lbWrap =$('.leaderdata');
lbWrap.empty();
top10Scores.map(items => lbWrap.append(`<li title="${items.Category1}">
            <mark>${items.UserName}</mark>
            <small>${items.Score}<img style="width: 30px;" src="${items.Badge=="Gold" ? `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/GoldBadge.png` : items.Badge=="Silver" ? `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/SiverBadge.png` : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/PlatinumBadge.png` }"/></small>
        </li>`)) 

}
 else{
   $('.scrollleader').hide();
   $('.noleader').show();
 }
}
//})

//search leader board


// Assuming 'sharepointData' is the array of SharePoint data
function searchleader(inputValue) {
  const searchResults = top10Scores.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search   
    return item.UserName.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Get a reference to the input element


// Add the onchange event handler to the input element
//searchleaderInput.onchange = 
function searchleaderInput() {
  debugger;
  var searchleaderInput = document.getElementById("searchleader");
  const inputValue = searchleaderInput.value;
  if(inputValue.length >0){
     $('.clear-leader').show()  
  }
  else{
    var inputBox = document.getElementById("searchleader");
  inputBox.value = "";
    cmpltfunc();
      $('.clear-leader').hide()  
  };
  var results = searchleader(inputValue);
  console.log(results);


if(results.length > 0){
  $('.scrollleader').show();
  $('.noleader').hide();
  lbWrap =$('.leaderdata');
  lbWrap.empty();
results.map(items => lbWrap.append(`<li title="${items.Category1}">
            <mark>${items.UserName}</mark>
            <small>${items.Score}<img style="width: 30px;" src="${items.Badge=="Gold" ? `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/GoldBadge.png` : items.Badge=="Silver" ? `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/SiverBadge.png` : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/PlatinumBadge.png` }"/></small>
        </li>`)) 
}
 else{
   $('.scrollleader').hide();
   $('.noleader').show();
 }
}


//show wishlist
function wishlistshow(){
  var searchwlInput = document.getElementById("wlInput");
   searchwlInput.value = "";
  if(wishlistdata.length>0){
    $('.norecordwl').hide();
    $('.scrollwl').show();
   $('.tablewl').show();
   $('.clear-searchwl').hide();
  var wldata =$('.leaderboard__profiles');
  wldata.empty();
  wishlistdata.map(items => wldata.append(`<article class="leaderboard__profile">
      <img src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/wishlist-icon-01.svg" class="leaderboard__picture">
      <span class="leaderboard__name">${items.CourseName}</span>
      <span class="leaderboard__value"><img width=30px; src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Inprogress.png" /></span>
    </article>`))
  }
  else{
    $('.tablewl').hide();
    $('.scrollwl').hide();
   $('.norecordwl').show();
  }

}



//add to fav8 
function addRecordTofavt(course,category,section,navigateURL,imgurl,secover,author,authorinfo){
  debugger;
  // SharePoint site URL
var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';

// SharePoint list name
var listName = 'LMS favorite';

// Endpoint URL
var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/items";

// Input section value
var Section = section; // Change this value to your actual section input

// Extract the number of sections from the input
var numSections = parseInt(Section, 10);

// Array to store item titles
var itemTitles = [];
if(category==="null"){
  category=""
}

var hyperlinkValueimg = {
    "__metadata": { "type": "SP.FieldUrlValue" },
    "Url": imgurl,
    "Description": "img link"
  };
  var hyperlinkValuenav = {
    "__metadata": { "type": "SP.FieldUrlValue" },
    "Url": navigateURL,
    "Description": "nav link"
  };
// Request paydata for each item
  var paydata = {
    '__metadata': { 'type': 'SP.Data.LMS_x0020_favoriteListItem' }, // Use the correct entity type name
    'Title': userName,
    'Category': category,
    'Section': section,
    'Course' : course,
    'EmployeeEmail' :loggedUserMail,
    'Author0': author,
    'AboutAuthor':authorinfo,
    'ImageURL' :hyperlinkValueimg,
    'NavigateURL':hyperlinkValuenav,
    'SectionOverview': secover ,
    'CourseStatus' : 'Yes'
  };

// Refresh the Request Digest value
$.ajax({
  url: siteUrl + "/_api/contextinfo",
  method: "POST",
  headers: { "Accept": "application/json;odata=verbose" },
  success: function(data) {
    var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

    // Make the AJAX POST request with the refreshed Request Digest value
    $.ajax({
      url: url,
      type: "POST",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": requestDigest
      },
      data: JSON.stringify(paydata),
      success: function(data) {
        console.log("Item created successfully.");
        //$(`.announce-wrap`).empty();
        results=[];
        populardata=[];
        favtdata =[];
        favtfunc();
        appendfavt();
        lmsfunc();
        displayAnnouncementOnHomePage();
      },
      error: function(error) {
        console.log("Error creating item: " + JSON.stringify(error));
        // Handle error
      }
    });
  },
  error: function(error) {
    console.log("Error refreshing Request Digest: " + JSON.stringify(error));
    // Handle error
  }
});
}




//add to wishlist 
function addwishlist(course,repmanager,empID,courseurl){
  debugger;
  $(".notifywl").show();
  // SharePoint site URL
var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';

// SharePoint list name
var listName = 'WishList Course';

// Endpoint URL
var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/items";
var hyperlinkcourseurl = {
    "__metadata": { "type": "SP.FieldUrlValue" },
    "Url": courseurl,
    "Description": "nav link"
  };
// Request paydata for each item
  var paydata = {
    '__metadata': { 'type': 'SP.Data.WishList_x0020_CourseListItem' }, // Use the correct entity type name
    'Title': loggedUserMail,
    'ReportingManager': repmanager,
    'Status': 'InProgress',
    'CourseName' : course,
    'EmployeeID' :empID,
    'CourseURL' :hyperlinkcourseurl
  };

// Refresh the Request Digest value
$.ajax({
  url: siteUrl + "/_api/contextinfo",
  method: "POST",
  headers: { "Accept": "application/json;odata=verbose" },
  success: function(data) {
    var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

    // Make the AJAX POST request with the refreshed Request Digest value
    $.ajax({
      url: url,
      type: "POST",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": requestDigest
      },
      data: JSON.stringify(paydata),
      success: function(data) {
        $(".notifywl").show();
        console.log("Item created successfully.");
        wishlistdata=[];
        favtfunc();
        wishlistshow();
        var popup = document.getElementById("popup");
        popup.style.display = "none";
        //$(".notifywl").hide();
        //alert("Your WishList Form has been submitted successfully!");
      },
      error: function(error) {
        console.log("Error creating item: " + JSON.stringify(error));
        // Handle error
      }
    });
  },
  error: function(error) {
    console.log("Error refreshing Request Digest: " + JSON.stringify(error));
    // Handle error
  }
});
}




//search wishlist course


// Assuming 'sharepointData' is the array of SharePoint data
function searchwlInputfc(inputValue) {
  debugger;
  const searchResults = wishlistdata.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search   
    return item.CourseName.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Get a reference to the input element


// Add the onchange event handler to the input element
//searchcmptInput.onchange = 
function searchwlInput() {
  debugger;
  var searchwlInput = document.getElementById("wlInput");
  const inputValue = searchwlInput.value;
  if(inputValue.length >0){
     $('.clear-searchwl').show()  
  }
  else{
    var inputBox = document.getElementById("wlInput");
  inputBox.value = "";
    wishlistshow();
      $('.clear-searchwl').hide();
  };
  var results = searchwlInputfc(inputValue);
  console.log(results);


if(results.length > 0){
  $('.norecordwl').hide();
   $('.tablewl').show();
   $('.scrollwl').show();
  var wldata =$('.leaderboard__profiles');
  wldata.empty();
  results.map(items => wldata.append(`<article class="leaderboard__profile">
      <img src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/wishlist-icon-01.svg" class="leaderboard__picture">
      <span class="leaderboard__name">${items.CourseName}</span>
      <span class="leaderboard__value"><img width=30px; src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Inprogress.png" /></span>
    </article>`))
  }
  else{
    $('.scrollwl').hide();
    $('.tablewl').hide();
   $('.norecordwl').show();
   
  }
}



//to show all the wishlist in admin screen

function allwishlist(){
  debugger;
  var allwldata =$('#wishlistc-wrap');
  allwldata.empty();
  allWishlistdata.map(items => allwldata.append(`<div class="col-lg-4">
                <div class="text-center card-box">
                    <div class="member-card pt-2 pb-2">
                        <div class="thumb-lg member-thumb mx-auto"><img src=${items.Status==="InProgress" ? `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Shoping-Card.jpg` :`https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Shoping-Card-Progress.jpg`} class="rounded-circle img-thumbnail" alt="profile-image"></div>
                        <div style="width:100%" class="">
                            <h3 style="display: -webkit-box;overflow: hidden;-webkit-line-clamp: 1;-webkit-box-orient: vertical;" title="${items.CourseName}">${items.CourseName}</h3>
                            <h4 style="display: -webkit-box;overflow: hidden;-webkit-line-clamp: 1;-webkit-box-orient: vertical;" title="${items.Title}">${items.Title}</h4>
                            <h5 style="display: -webkit-box;overflow: hidden;-webkit-line-clamp: 1;-webkit-box-orient: vertical;" title="${items.ReportingManager}">${items.ReportingManager}</h5>
                           </div>
                        <a href="${items.CourseURL.Url}" target="_blank()" data-interception="off"><button type="button" class="btn btn-primary mt-3 btn-rounded waves-effect w-md waves-light">View Course</button></a>
                        
                    </div>
                </div>
            </div>`))
}


//get user info as prefilled

function getinfo(){
  document.getElementById("name").value = userName;
      document.getElementById("employeeID").value = employeeID;
      document.getElementById("email").value = loggedUserMail;
      document.getElementById("manager").value = reportingManager;
}