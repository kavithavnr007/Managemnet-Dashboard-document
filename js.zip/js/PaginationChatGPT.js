 var resultpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Topic Evaluation User Badge')/items"
 var resultData =[];
var tableRows =[];
const timeValues = [];
 // to get the student details

 function resultdet() {
     debugger;
$.ajax({
    url: resultpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        resultData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + resultData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }

function resultshowdet(){ 
        var stdwrap = $('.cevaluation');
        stdwrap.empty();
        var averages = {};
        // Hardcoded data as an array of objects
        const data = resultData;

        // Function to calculate the average time for each unique combination

        function calculateAverageTime(data) {
      
          data.forEach((row) => {

                const key = `${row.Category1}-${row.Section}-${row.Category}`;


               var rtotaltime= row.TOTALTime.toString();
                const totalTime = rtotaltime.split(":");

                const totalSeconds = parseInt(totalTime[0]) * 3600 + parseInt(totalTime[1]) * 60 + parseInt(totalTime[2]);

                if (!averages[key]) {

                    averages[key] = {

                        count: 1,

                        totalSeconds: totalSeconds,

                    };

                } else {

                    averages[key].count++;

                    averages[key].totalSeconds += totalSeconds;

                }

            });

 

            for (const key in averages) {

                if (averages.hasOwnProperty(key)) {

                    averages[key].averageSeconds = averages[key].totalSeconds / averages[key].count;

                }

            }

 

            return averages;

        }

 

        // Calculate and display the average times in the separate table

        const averageTimes = calculateAverageTime(data);

        //const averageTable = document.getElementById("average-table").getElementsByTagName('tbody')[0];

 

        for (const key in averageTimes) {

            if (averageTimes.hasOwnProperty(key)) {

                const [course, section, category] = key.split('-');

                const averageTime = averageTimes[key].averageSeconds;

                const hours = Math.floor(averageTime / 3600);

                const minutes = Math.floor((averageTime % 3600) / 60);

                const seconds = Math.floor(averageTime % 60);

                    var payload = {
                    'course':course,
                    'category':category,
                    'section':section,
                    'count' : averages[key].count

                    };
                   tableRows.push(payload);


                stdwrap.append(`<tr><td>${category}</td>
                         <td>${course}</td>
                          <td>${section}</td>
                          <td>${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}</td>
                           <td><button style="background:transparent;border:none;" onclick="EmployeeDetailshowbelow('${category}','${course}','${section}')" background: transparent;
    border: none;>  ${averages[key].count}</button></td></tr>`
   )
                //const newRow = averageTable.insertRow();

                //newRow.insertCell().textContent = course;

                //newRow.insertCell().textContent = section;

                //newRow.insertCell().textContent = category;

                //newRow.insertCell().textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

                //newRow.insertCell().textContent = averages[key].count;

            }

        }
}



//Employee Details view code


function EmployeeDetailshowbelow(category,course,section)
{
  debugger

var lsrdata =[];

lsrdata = resultData.filter(list => list.Category.toLocaleLowerCase() ===category.toLocaleLowerCase() && list.Category1.toLocaleLowerCase() ===course.toLocaleLowerCase() && list.Section.toLocaleLowerCase() ===section.toLocaleLowerCase() )
var lsrdata1 = $('.cevaluation01');
lsrdata1.empty();
console.log("lsrdata: " + lsrdata); 
for(i=0;i<lsrdata.length; i++){
   lsrdata1.append(`<tr><td>${lsrdata[i].UserName}</td>
                         <td>${lsrdata[i].Category1}</td>
                         <td>${lsrdata[i].Section}</td>
                         <td>${new Date(lsrdata[i].Created).toLocaleDateString('en-GB')}</td>
                         <td>${lsrdata[i].Score}</td>
                         <td>${lsrdata[i].TOTALTime}</td>
                         <td>None</td>
                         <td>None</td></tr>`
   )  
}

  
}

// Assuming 'sharepointData' is the array of SharePoint data

function searchData(inputValue) {

    debugger;

  const searchResults = tableRows.filter(item => {

    // Replace 'columnName' with the actual name of the column you want to search

    return item.category.toLowerCase().includes(inputValue.toLowerCase());

  });

  return searchResults;

}



// Add the onchange event handler to the input element

 function searchfun() {
debugger;

const searchInput = document.getElementById("Searchresultsum");
  const inputValue = searchInput.value;

  if(inputValue.length >0){

     $('.clear-search').show()  

  }

  else{

      $('.clear-search').hide()  

  };

  var results = searchData(inputValue);

  console.log(results);

var stdwrap = $('.cevaluation');
 stdwrap.empty();


if(results.length > 0){
  stdwrap.show()

results.map(items => stdwrap.append(`<tr><td>${items.category}</td>
                         <td>${items.course}</td>
                          <td>${items.section}</td>
                           <td><button style="background:transparent;border:none;" onclick="EmployeeDetailshowbelow('${items.category}','${items.course}','${items.section}')" background: transparent;
    border: none;>  ${averages[key].count}</button></td></tr>`)) //<div class="vl"></div>
}
};

