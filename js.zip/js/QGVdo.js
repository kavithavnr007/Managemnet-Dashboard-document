

/***Quarterly Goals *****/

var qgPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Quarterly Goal')/items?&$filter=(Active eq 1)"

var VDoData = [];
var currentDate = new Date(new Date().toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
})).getTime();

function getVDoData(){
$.ajax({
    url: qgPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,

    success: function (data) {

VDoData = [...VDoData,...data.d.results]

if (data.d.__next) {

qgPath = data.d.__next;

getVDoData();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}

getVDoData();

    /*success: function (data) {
        
        for (i = 0; i < data.d.results.length; i++) {
            qgData.push(data.d.results[i]);
        }
        if (data.d.__next) {
            qgPath = data.d.__next;
            getQGData();
            return;
        }*/
      



var slideIndex = 1;

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slides[slideIndex-1].style.display = "block";  
  
}


function Vdogoal(){
let WorkWrap = $('.VD-wrap');
WorkWrap.empty()

if(VDoData.length  > 0){$('.VD-wrap').show()
VDoData .map(items => WorkWrap.append(`<div class="mySlides slide-fade"><div class="Video-Section" ><img src="${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/MicrosoftTeams-image%20(10).png`}" onclick="openVideoModel(${items.ID})" alt="Quarterly Goals" title= "${items.Title}" style="cursor:pointer; 	width: 100%; " /><img src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/MicrosoftTeams-image%20(10).png" onclick="openVideoModel(${items.ID})" alt="Quarterly Goals" title= "${items.Title}" style=" cursor:pointer; position: absolute; width:40px;" /></div><div class="text">${items.Title}</div></div>`))
}
showSlides(slideIndex);
}


function openVideoModel(id){
let data = VDoData.filter(items => items.ID == id);
let vidContent
if(data.Video_x002f_Link== "Video") {
  vidContent = `<video width="100%" height="360" controls>
  <source src="${data[0].Video.Url}" type="video/mp4">
</video>`
} else {
     vidContent = `<iframe width="100%" height="360"  src="${data[0].Video.Url} " ></iframe>`
}
$('#announceModel .modal-title').html(`${data[0].Title}`)
$("#an-notes").html(vidContent);
$('#announceModel .modal-body a').attr('target','_blank');
$('#announceModel .modal-body a').css({'font-weight':'500','text-decoration':'underline'});
$('#announceModel').modal('show')
};

$('#announceModel').on('hidden.bs.modal', function (e) {
  $("#an-notes").empty()
})