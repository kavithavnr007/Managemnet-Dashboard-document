var pageName = window.location.pathname.split("/").pop().split(".").shift();
var currentDate = new Date(new Date().toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
})).getTime();




var nextUsNewsPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('News Letter')/items"
var nextUsNews = [];

function timeSince(date) {
        var seconds = Math.floor((new Date() - date) / 1000);

        var interval = seconds / 31536000;
       /*  if (interval > 1) {
          return Math.floor(interval) + ' years';
        }
        interval = seconds / 2592000;
        if (interval > 1) {
          return Math.floor(interval) + ' months';
        }*/
        var interval = seconds / 86400;
        if (interval > 1) {
          //return Math.floor(interval) + ' days';
          return new Intl.DateTimeFormat('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' }).format(date)
        }
        interval = seconds / 3600;
        if (interval > 1) {
          let res = `${Math.floor(interval)} ${Math.floor(interval) > 1 ? 'hours ago' : 'hour ago'}`
          return res;
        }
        interval = seconds / 60;
        if (interval > 1) {
             let res = `${Math.floor(interval)} ${Math.floor(interval) > 1 ? ' minutes ago' : 'minute ago'}`
            return res;
         }
        return `${Math.floor(seconds)} ${Math.floor(seconds) > 1 ? 'seconds ago' : 'second ago'}`
      }
      //var aDay = 24 * 60 * 60 * 1000;


function getNextUsNews() {
$.ajax({
    url:nextUsNewsPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        nextUsNews = [...nextUsNews,...data.d.results]
        if (data.d.__next) {
            nextUsNewsPath = data.d.__next;
            getNextUsNews();
            return;
        }
    },


    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});

}
getNextUsNews()

/***Job Posting*****/

var jobPostPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Job Posting')/items"

var jobPostingData = [];

function jobPosting3() {

$.ajax({

url:jobPostPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

jobPostingData = [...jobPostingData,...data.d.results]

if (data.d.__next) {

jobPostPath = data.d.__next;

jobPosting3();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}



function appendJobPost(){
let jobPostWrap = $('.career-wrap3');

jobPostWrap.empty()

jobPostingData = jobPostingData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(jobPostingData.length > 0){$('.car-container3').show()

jobPostingData.map(items => jobPostWrap.append(`<div class="post" onclick="jobPostDetails3(${items.ID})"><p style="font-size: 140%;">${items.field_Job_x0020_Title.replace(/<[^>]*>?/gm, '')}</p>
<P> No of Positions :   ${items.field_No_x0020_Of_x0020_Position}</p></div>`))



}

}

function jobPostDetails3(id){

let data = jobPostingData.filter(items => items.ID == id);
let content = ` <div class="c-container3"><div class="c-wrap">
            <P>Job ID : <span>${data[0].Title.replace(/<[^>]*>?/gm, '')}</span></p>
            <P>Job Title :<span> ${data[0].field_Job_x0020_Title.replace(/<[^>]*>?/gm, '')}</span></p> </div>
            <div class="c-wrap">
            <P>No of Positions :<span> ${data[0].field_No_x0020_Of_x0020_Position}</span></p>
            <P>Years of Experience :<span> ${data[0].field_Years_x0020_Of_x0020_Experience}</span></p> </div></div>
            <P><span style="font-weight:500; color:#000">Job Description :</span> <br /> ${data[0].field_Job_x0020_Description}</p>`;

$('#jobPostingModel5 .modal-title').html(`${data[0].field_Job_x0020_Title.replace(/<[^>]*>?/gm, '')}`);

$('#jobPostingModel5 .modal-body').html(content);

$('#jobPostingModel5').modal('show')

}



/*** Employee Directory***/

var defaultEmpPath = "https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items"

var EmpDPath02 = "https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items?&$filter=(Active eq 1)&$orderby=field_Employee_x0020_Name asc&$top=15"
var isScrolled  = false;
var showLazyLoad  = true;
var isDepAndLoc = false;
var EmpDData=[]

/*
function EmpD() {

$.ajax({

url:EmpDPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

EmpDData = [...EmpDData,...data.d.results]

if (data.d.__next) {

EmpDPath = data.d.__next;

EmpD();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}



function appendEmpD(){
let displayData = EmpDData
if($('#emp_department').val() != 'null') displayData = displayData.filter(data => data.Department == $('#emp_department').val())
if($('#emp_location').val() != 'null') displayData = displayData.filter(data => data.field_Location == $('#emp_location').val())
let EmpDWrap = $('.career-wrapEmpD');
EmpDWrap.empty()
$('.car-containerEmpD').show()
if( $('#myInput').val() !=''){
let fliterBy = $('#myInput').val()
displayData = displayData.filter(data => data.field_Employee_x0020_Name.toLowerCase().includes(fliterBy.toLowerCase()) || data.Email && data.Email.toLowerCase().includes(fliterBy.toLowerCase()))
}

displayData.sort((a, b) => a.field_Employee_x0020_Name.localeCompare(b.field_Employee_x0020_Name))
displayData.map(items => EmpDWrap.append(`<div class="post" onclick="EmpDetails(${items.ID})"> <p style="text-align:center;" data-toggle="tooltip" title="${items.field_Employee_x0020_Name}"><img style="border-radius: 100%; border: 2px solid #ADD8E6; display: block;
  margin-left: auto;
  margin-right: auto;" vertical-align= "top" align="left" width="60" height="60" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: medium;">${items.field_Employee_x0020_Name}</p></div>`)
)
}

$('#emp_department, #emp_location').change(function(){
    appendEmpD()
})
*/
function EmpDetails(id){
let apiPath = `https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items?$filter=ID eq ${id}`
$.ajax({
url:apiPath,
method:'GET',
headers: {
Accept: "application/json;odata=verbose"
},
//async: false,
success: function (data) {
  
let content = ` <div class="c-containerEmpD"><div class="c-wrap">
            <P>Employee Name : <span>${data.d.results[0].field_Employee_x0020_Name}</span></p>
            <P>Location :<span> ${data.d.results[0].field_Location}</span></p> </div>
            <div class="c-wrap">
            <P>Mobile Number :<span> ${data.d.results[0].Mobile}</span></p>
            <P>Department :<span> ${data.d.results[0].Department}</span></p> </div></div>
            <div class="c-containerEmpD" style="border:none"><div class="c-wrap">
            <P><span style="font-weight:500; color:#000">Employee Email </span> <br /> <a href="mailto:${data.d.results[0].Email}">${data.d.results[0].Email}</a> </p>
            <P style="text-align:right"><span style="font-weight:500; color:#000">Blood Group</span> <br /> <a href="mailto:${data.d.results[0].Email}">${data.d.results[0].BloodGroup && data.d.results[0].BloodGroup}</a> </p>
            </div></div>
            `;


$('#jobPostingModel55 .modal-title').html(`<img style="border-radius: 50%;" vertical-align= "top" align="left" width="45" height="45" src= "${data.d.results[0].Photo ? (data.d.results[0].Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="30%" height="30%" alt="Avatar">  ${data.d.results[0].field_Employee_x0020_Name}`);

$('#jobPostingModel55 .modal-body').html(content);

$('#jobPostingModel55').modal('show')

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});

}
jobPosting3();
//EmpD();

function fetchEmpData() {

$('.car-containerEmpD').show()
$('.car-containerEmpD #icon').css('display','none')
let EmpDWrap = $('.career-wrapEmpD'); 
$.ajax({
url:EmpDPath02,
method:'GET',
headers: {
Accept: "application/json;odata=verbose"
},
//async: false,
success: function (data) {
data.d.results.map(items => EmpDWrap.append(`<div class="post" onclick="EmpDetails(${items.ID})"> <p style="text-align:center;" data-toggle="tooltip" title="${items.Designation}"><img style="border-radius: 100%; border: 2px solid #ADD8E6; display: block;
  margin-left: auto;
  margin-right: auto;" vertical-align= "top" align="left" width="60" height="60" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: medium;">${items.field_Employee_x0020_Name}</p></div>`)
)
if (data.d.__next) {
EmpDPath02 = `${data.d.__next}`;
isScrolled = true
}
},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});
}
$('.epchange').scroll(function(){
            if(showLazyLoad){
            if ($('.epchange').scrollTop() >= $('.car-containerEmpD').height() - ($('.epchange').height()+30) && isScrolled){
            isScrolled = false; 
            if(isDepAndLoc){
            scrollDepAndLoc()
            } else {fetchEmpData()}
            }
            }
});



function searchEmpData() {
let EmpDWrap = $('.career-wrapEmpD'); 
if( $('#myInput').val() !=''){
$('#clear-search-btn').show()  
showLazyLoad = false 
let fliterBy = $('#myInput').val()
let EmpDPath02 = `https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items?
$filter=(Active eq 1) and ( startswith(field_Employee_x0020_Name,'${fliterBy}') or startswith(Email,'${fliterBy}'))`
if($('#emp_department').val() != 'null') EmpDPath02 = `${EmpDPath02}and(Department eq '${$('#emp_department').val()}')`
if($('#emp_location').val() != 'null') EmpDPath02 = `${EmpDPath02}and(field_Location eq '${$('#emp_location').val()}')`
if($('#emp_bgrp').val() != 'null') EmpDPath02 = `${EmpDPath02}and(BloodGroup eq '${$('#emp_bgrp').val()}')`
$('.car-containerEmpD').show()
$.ajax({
url:EmpDPath02,
method:'GET',
headers: {
Accept: "application/json;odata=verbose"
},
//async: false,
success: function (data) {
  EmpDWrap.empty()
  let employee = [...new Map(data.d.results.map(items => [items.ID,items])).values()]
  employee.map(items => EmpDWrap.append(`<div class="post" onclick="EmpDetails(${items.ID})"> <p style="text-align:center;" data-toggle="tooltip" title="${items.Designation}"><img style="border-radius: 100%; border: 2px solid #ADD8E6; display: block;
  margin-left: auto;
  margin-right: auto;" vertical-align= "top" align="left" width="60" height="60" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: medium;">${items.field_Employee_x0020_Name}</p></div>`)
)
if (data.d.__next) {

EmpDPath02 = `${data.d.__next}`;
isScrolled = true
}
},

error: function (data) {
console.log("An error occurred. Please try again.");
}

});
} else if($('#emp_department').val() != 'null' || $('#emp_location').val() != 'null' || $('#emp_bgrp').val() != 'null') {
 showLazyLoad = true 
 handleLocAndDep()
}
else{
  showLazyLoad = true;
  EmpDWrap.empty();
  EmpDPath02 = "https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items?&$filter=(Active eq 1)&$orderby=field_Employee_x0020_Name asc&$top=15"
  fetchEmpData()
  }
}

function appendDepartAndLoc(){
$.when( 
  $.ajax({
    url: "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Department')/items",
    headers: {
        Accept: 'application/json;odata=verbose',
    },
    async: false,
}),
$.ajax({
    url: "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Location')/items",
    headers: {
        Accept: 'application/json;odata=verbose',
    },
    async: false,
})).done(function( dep,loc ) {
let department = dep[0].d.results
let location = loc[0].d.results
let bloodGrp = ['O Positive','A Positive','B Positive','A1 Positive','AB Positive','A1B Positive','A2 Positive','A Negative','B Negative','A1 Negative','AB Negative','O Negative',]
$('#emp_department, #emp_location, #emp_bgrp').empty()
$('#emp_department').append(`<option value=null>Choose Department</option>`)
$('#emp_location').append(`<option value=null>Choose Location</option>`)
$('#emp_bgrp').append(`<option value=null>Choose Blood Group</option>`)
department.filter(data => data != null).map(items => $('#emp_department').append(`<option value="${items.Department}">${items.Department}</option>`))
location.filter(data => data != null).map(items => $('#emp_location').append(`<option value="${items.Location}">${items.Location}</option>`))
bloodGrp.filter(data => data != null).map(items => $('#emp_bgrp').append(`<option value="${items}">${items}</option>`))
});
}
appendDepartAndLoc();



var scrollPath = ''
function handleLocAndDep(){
var currentEmpPath = ""
$("div.epchange").scrollTop(0)  
isDepAndLoc = true;
let apiPath = `${defaultEmpPath}?$filter=(Active eq 1`
if($('#emp_department').val() != 'null') apiPath = `${apiPath} and Department eq '${$('#emp_department').val()}'`
if($('#emp_location').val() != 'null') apiPath = `${apiPath} and field_Location eq '${$('#emp_location').val()}'`
if($('#emp_bgrp').val() != 'null') {apiPath = `${apiPath} and BloodGroup eq '${$('#emp_bgrp').val()}'`}
currentEmpPath = `${apiPath})&$orderby=field_Employee_x0020_Name asc&$top=15`
if($('#emp_department').val() == 'null' && $('#emp_location').val() == 'null' && $('#emp_bgrp').val() == 'null') {
isDepAndLoc = false;
currentEmpPath = ''
$('.career-wrapEmpD').empty()
EmpDPath02 = "https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items?&$filter=(Active eq 1)&$orderby=field_Employee_x0020_Name asc&$top=15"
fetchEmpData()
return false;
}
let EmpDWrap = $('.career-wrapEmpD'); 
$.ajax({
url:currentEmpPath,
method:'GET',
headers: {
Accept: "application/json;odata=verbose"
},
success: function (data) {
  $('.career-wrapEmpD').empty()
  let employee = [...new Map(data.d.results.map(items => [items.ID,items])).values()]
  employee.map(items => EmpDWrap.append(`<div class="post" onclick="EmpDetails(${items.ID})"> <p style="text-align:center;" data-toggle="tooltip" title="${items.Designation}"><img style="border-radius: 100%; border: 2px solid #ADD8E6; display: block;
  margin-left: auto;
  margin-right: auto;" vertical-align= "top" align="left" width="60" height="60" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: medium;">${items.field_Employee_x0020_Name}</p></div>`)
)
if (data.d.__next) {
scrollPath = `${data.d.__next}`;
isScrolled = true
}
},
error: function (data) {
console.log("An error occurred. Please try again.");
}
});
}

function scrollDepAndLoc(){
let EmpDWrap = $('.career-wrapEmpD'); 
$.ajax({
url:scrollPath,
method:'GET',
headers: {
Accept: "application/json;odata=verbose"
},
//async: false,
success: function (data) {
  let employee = [...new Map(data.d.results.map(items => [items.ID,items])).values()]
  employee.map(items => EmpDWrap.append(`<div class="post" onclick="EmpDetails(${items.ID})"> <p style="text-align:center;" data-toggle="tooltip" title="${items.Designation}"><img style="border-radius: 100%; border: 2px solid #ADD8E6; display: block;
  margin-left: auto;
  margin-right: auto;" vertical-align= "top" align="left" width="60" height="60" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: medium;">${items.field_Employee_x0020_Name}</p></div>`)
)
if (data.d.__next) {
scrollPath = `${data.d.__next}`;
isScrolled = true
}
},
error: function (data) {
console.log("An error occurred. Please try again.");
}
});

}

$('#emp_department, #emp_location, #emp_bgrp').change(function(){
    handleLocAndDep()
})

document.getElementById('clear-search-btn').addEventListener('click', function (event) {
$('#myInput').val('')
if($('#emp_department').val() != 'null' || $('#emp_location').val() != 'null' || $('#emp_bgrp').val() != 'null') {
 showLazyLoad = true 
 handleLocAndDep()
}
else{
  let EmpDWrap = $('.career-wrapEmpD'); 
  showLazyLoad = true;
  EmpDWrap.empty();
  EmpDPath02 = "https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items?&$filter=(Active eq 1)&$orderby=field_Employee_x0020_Name asc&$top=15"
  fetchEmpData()
  }
  $('#clear-search-btn').hide()
});



/* News Letter */


function newsOnHomePage() {
let newsData = nextUsNews.filter(items => (items.Section_x002f_Department == "Project Management") && items.Active && items.Publish  && new Date(items.StartDate).getTime() < currentDate)
newsData.sort(function(a,b){
return new Date(b.StartDate) - new Date(a.StartDate);
});

if (newsData.length > 0) {
pinData = newsData.filter(data => data.Pin);
pinCount = 0 ;
if(pinData.length > 0){
   
$('.next-us').show();
for (i=0; i < pinData.length; i++){
if(pinCount == 5) break;    
pinCount++; 
let userEmail = pinData[i].NewsPostedByEmail ? pinData[i].NewsPostedByEmail : "No Email";
let userName = pinData[i].NewsPostedByName ? pinData[i].NewsPostedByName : "No Name";
let postDate = `${timeSince(new Date(pinData[i].StartDate))}`
let iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg'
//pageName.toLowerCase() == "nextushome" ? iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg' : iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg' 

let blogContent = `<div class="vista-blog"><div class="user-profile"><img src="${iconPath}" style="border:none;border-radius:0%; width:60px; height:60px"/></div><div class="blog-content"><h4 style="margin-bottom:3px"><a href="#" style="text-decoration:underline" onclick="blogDetails(${pinData[i].ID},'${userName}')">${pinData[i].Title}</a> <img src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/pin.png"  style="margin-bottom: 5px;margin-left: 5px;"/></h4><p style="margin-bottom:2px;">${userName} - ${postDate.toString()}</p><p>${pinData[i].Description.replace(/<[^>]*>?/gm, '')}</p></div></div>`

$('.nextUs-list').append(blogContent);
}
}

if(pinCount != 2){
$('.next-us').show();
newsData = newsData.filter(items => !items.Pin);
for (i=0; i < newsData.length; i++){
if(pinCount == 5) break;    
pinCount++; 
let userEmail = newsData[i].NewsPostedByEmail ? newsData[i].NewsPostedByEmail : "No Email";
let userName = newsData[i].NewsPostedByName ? newsData[i].NewsPostedByName : "No Name";
let postDate = `${timeSince(new Date(newsData[i].StartDate))}`
let iconPath 
pageName.toLowerCase() == "nextushome" ? iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg' : iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg' 

let blogContent = `<div class="vista-blog"><div class="user-profile"><img src="${iconPath}" style="border:none;border-radius:0%; width:60px; height:60px"/></div><div class="blog-content"><h4 style="margin-bottom:3px"><a href="#" style="text-decoration:underline" onclick="blogDetails(${newsData[i].ID},'${userName}')">${newsData[i].Title}</a></h4><p style="margin-bottom:2px;">${userName} - ${postDate.toString()}</p><p>${newsData[i].Description.replace(/<[^>]*>?/gm, '')}</p></div></div>`

$('.nextUs-list').append(blogContent);
}
}

}  else { $('.archive-list-link').hide()}

}


function newsOnHomePage1() {
let newsData = nextUsNews.filter(items => (items.Section_x002f_Department == "Quality Assurance") && items.Active && items.Publish  && new Date(items.StartDate).getTime() < currentDate)
newsData.sort(function(a,b){
return new Date(b.StartDate) - new Date(a.StartDate);
});

if (newsData.length > 0) {
pinData = newsData.filter(data => data.Pin);
pinCount = 0 ;
if(pinData.length > 0){
  
$('.news').show();
for (i=0; i < pinData.length; i++){
if(pinCount == 5) break;    
pinCount++; 
let userEmail = pinData[i].NewsPostedByEmail ? pinData[i].NewsPostedByEmail : "No Email";
let userName = pinData[i].NewsPostedByName ? pinData[i].NewsPostedByName : "No Name";
let postDate = `${timeSince(new Date(pinData[i].StartDate))}`
let iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg'
//pageName.toLowerCase() == "nextushome" ? iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg' : iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg' 

let blogContent = `<div class="news-blog"><div class="user-profile"><img src="${iconPath}" style="border:none;border-radius:0%; width:60px; height:60px"/></div><div class="news-content"><h4 style="margin-bottom:3px"><a href="#" style="text-decoration:underline" onclick="blogDetails(${pinData[i].ID},'${userName}')">${pinData[i].Title}</a> <img src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/pin.png"  style="margin-bottom: 5px;margin-left: 5px;"/></h4><p style="margin-bottom:2px;">${userName} - ${postDate.toString()}</p><p>${pinData[i].Description.replace(/<[^>]*>?/gm, '')}</p></div></div>`

$('.News-list').append(blogContent);
}
}

if(pinCount != 2){
$('.news').show();
newsData = newsData.filter(items => !items.Pin);
for (i=0; i < newsData.length; i++){
if(pinCount == 5) break;    
pinCount++; 
let userEmail = newsData[i].NewsPostedByEmail ? newsData[i].NewsPostedByEmail : "No Email";
let userName = newsData[i].NewsPostedByName ? newsData[i].NewsPostedByName : "No Name";
let postDate = `${timeSince(new Date(newsData[i].StartDate))}`
let iconPath 
pageName.toLowerCase() == "nextushome" ? iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg' : iconPath = 'https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/RENCATA-LOGO.jpg' 

let blogContent = `<div class="news-blog"><div class="user-profile"><img src="${iconPath}" style="border:none;border-radius:0%; width:60px; height:60px"/></div><div class="news-content"><h4 style="margin-bottom:3px"><a href="#" style="text-decoration:underline" onclick="blogDetails(${newsData[i].ID},'${userName}')">${newsData[i].Title}</a></h4><p style="margin-bottom:2px;">${userName} - ${postDate.toString()}</p><p>${newsData[i].Description.replace(/<[^>]*>?/gm, '')}</p></div></div>`

$('.News-list').append(blogContent);
}
}

}  else { $('.archive-list-link').hide()}

}



function blogDetails(id,username){
$('#blogModel .modal-body').empty()    
let data = nextUsNews.filter(items => items.ID == id)
let startDate = new Intl.DateTimeFormat('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' }).format(new Date(data[0].StartDate))
let content = `<div class="header-wrap"><div class="title">${data[0].Title}</div><div class="date">${startDate}</div></div><div class="desc">${data[0].Description}</div>`
let popupTitle = `<div class="title-wrap">${data[0].Section_x002f_Department}<h3></h3><span>${username}</span></div>`
$('#blogModel .modal-title').html(popupTitle);
$('#blogModel .modal-body').append(content);
$('#blogModel .modal-body a').attr('target','_blank');
$('#blogModel .modal-body a').css({'font-weight':'500','text-decoration':'underline'});
$('#blogModel').modal('show')
}
