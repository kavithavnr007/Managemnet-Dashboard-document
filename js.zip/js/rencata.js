var rencataEmpApiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Kudos Repository')/items?&$filter=(Deleted eq 0)";
var rencataBadgeApiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Techathon User Badge')/items";
var notificationAPIPath = [] ;
var myJsonString, carouselJsonString, sliderTitle, sliderImg, sliderOrder, slideCatogey; //To store the data into JSON format
var todayDate = new Date();
var istTodayDate;
var todayBadgeEmp=[];
var todayBdayEmp = [];
var todaykudosEmps2=[];
var todaykudosEmp = [];
var todayAnnivarsary = [];
var todayjoinees = [];
var rencataEmpList = [];
var rencataBadgeList = [];
var notificationList = [];
var userEmail;
var userid = _spPageContextInfo.userId;
var requestUri = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";

if (todayDate.getTimezoneOffset() == 480) {

    istTodayDate = new Date(todayDate);

} else istTodayDate = todayDate;
var presentMonth = istTodayDate.getMonth() + 1;
var pastmonth=istTodayDate.getMonth();
var presentDate = istTodayDate.getDate();
//var last = new Date(todayDate.getTime() - (days * 24 * 60 * 60 * 1000));
var pastDate =new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) ;
var pastDate =pastDate.getDate();
//var pastDate = istTodayDate.getDate() - 7;
var presentYear = istTodayDate.getFullYear();

$.ajax({
    url: requestUri,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        userEmail = data.d.Email.toLowerCase();
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});



/***Quarterly Goals *****/

var qgPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Quarterly Goal')/items"

var qgData = [];
var currentDate = new Date(new Date().toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
})).getTime();

function getQGData(){
$.ajax({
    url: qgPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
        
        for (i = 0; i < data.d.results.length; i++) {
            qgData.push(data.d.results[i]);
        }
        if (data.d.__next) {
            qgPath = data.d.__next;
            getQGData();
            return;
        }
      
let goalData = qgData.filter(
    (e) => (e.Active && !e.Delete)
);
if (goalData.length > 0) {

    for (i=0; i<goalData.length; i++){
    let startDate = new Date(goalData[i].StartDate).getTime();
    let endDate = new Date(goalData[i].EndDate).getTime();
    let img = goalData[i].Photo.Url
   
    let goalContent = `<div class="Quaterly-Goals" ><img src="${img}" onclick="openVideoModel(${goalData[i].ID})" alt="Quarterly Goals" title= "${goalData[i].Title}" style="cursor:pointer; 	width: 100%; " /><img src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/MicrosoftTeams-image%20(10).png" onclick="openVideoModel(${goalData[i].ID})" alt="Quarterly Goals" title= "${goalData[i].Title}" style=" cursor:pointer; position: absolute; width:40px;" /></div>`;

    if (startDate < currentDate && (endDate > currentDate || endDate == 0)) {
        $('.QG-wrap').empty();
        $('.QG-wrap').append(goalContent);
    } 
    }
}else $('.QG-wrap').hide();
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
}

function openVideoModel(id){
let data = qgData.filter(items => items.ID == id);
let vidContent
if(data.Video_x002f_Link== "Video") {
  vidContent = `<video width="100%" height="360" controls>
  <source src="${data[0].Video.Url}" type="video/mp4">
</video>`
} else {
     vidContent = `<iframe width="100%" height="360"  src="${data[0].Video.Url}" allowfullscreen ></iframe>`
}
$('#announceModel .modal-title').html(`${data[0].Title}`)
$("#an-notes").html(vidContent);
$('#announceModel .modal-body a').attr('target','_blank');
$('#announceModel .modal-body a').css({'font-weight':'500','text-decoration':'underline'});
$('#announceModel').modal('show')
};

$('#announceModel').on('hidden.bs.modal', function (e) {
  $("#an-notes").empty()
})


/*
function GetNotificationList() {
    
    $.ajax({
        url: notificationAPIPath[0],
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            
            for (i = 0; i < data.d.results.length; i++) {
                notificationList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                notificationAPIPath[0] = data.d.__next;
                GetNotificationList();
                return;
            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};

function getOffboardingNotiList(){
 $.ajax({
        url: notificationAPIPath[1],
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            
            for (i = 0; i < data.d.results.length; i++) {
                notificationList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                notificationAPIPath[1] = data.d.__next;
                getOffboardingNotiList();
                return;
            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
}
*/
/***Carosel Management *****/
/*
function GetRencataEmpList() {
    
    $.ajax({
        url: rencataEmpApiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            for (i = 0; i < data.d.results.length; i++) {
                rencataEmpList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                rencataEmpApiPath = data.d.__next;
                GetRencataEmpList();
                return;
            }



            var empBirthMonth, empBirthDate, empJoinMonth, empJoinDate, empJoinYear;
            rencataEmpList = rencataEmpList.filter(function(e){return e.field_DOB});
            if (rencataEmpList.length > 0) {
                for (i = 0; i < rencataEmpList.length; i++) {
                    let empDOB = new Date(new Date(rencataEmpList[i].field_DOB.split("T")[0]).toLocaleString("en-US", {timeZone: "Asia/Kolkata"}));
                    let empDOJ = new Date(new Date(rencataEmpList[i].field_DOJ.split("T")[0]).toLocaleString("en-US", {timeZone: "Asia/Kolkata"}));
                    empBirthMonth = empDOB.getMonth() + 1;
                    empJoinMonth = empDOJ.getMonth() + 1
                    empBirthDate = empDOB.getDate();
                    empJoinDate = empDOJ.getDate();
                    empJoinYear = empDOJ.getFullYear();


                    if ((presentDate == empBirthDate) && (presentMonth == empBirthMonth)) {
                        todayBdayEmp.push({ name: rencataEmpList[i].field_Employee_x0020_Name, mailId: rencataEmpList[i].Email, empPic:rencataEmpList[i].Photo})
                    }
                    if ((presentDate == empJoinDate) && (presentMonth == empJoinMonth)) {

                        if (presentYear != empJoinYear) {

                            todayAnnivarsary.push({ name: rencataEmpList[i].field_Employee_x0020_Name, yoj: empJoinYear, mailId: rencataEmpList[i].Email, empPic:rencataEmpList[i].Photo })
                        } else {

                            todayjoinees.push({ name: rencataEmpList[i].field_Employee_x0020_Name, mailId: rencataEmpList[i].Email , empPic:rencataEmpList[i].Photo})
                        }
                    }

                }
            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};
*/
/*End*/

/* JSON Sort method */

function GetSortOrder(prop) {
    return function (a, b) {
        if (a[prop] > b[prop]) {
            return 1;
        } else if (a[prop] < b[prop]) {
            return -1;
        }
        return 0;
    }
};
/**************** Announcement JSON DATA ***************/
function GetAnnouncementListItems() {
    var apiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Announcement List')/items?&$orderby=StartDate";
    $.ajax({
        url: apiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            if (data.d.results.length > 0) {
                $('.announce-text img').css("display", "none");
                data=  data.d.results.sort((a, b) => b.StartDate > a.StartDate ? 1: -1);
                myJsonString = data
                for (i = 0; i < myJsonString.length; i++) {
                    var startDate = new Date(myJsonString[i].StartDate);
                    var end = new Date(myJsonString[i].EndDate).getTime();
                    var endDate;
                    var newGifEndDay = startDate.getTime() + 86400000;
                    //86340000;
                    startDate = startDate.getTime() - 45000000;
                    //newGifEndDay = startDate + 86340000;
                    if (myJsonString[i].EndDate) {
                        //var end = new Date(myJsonString[i].EndDate);
                        endDate = new Date(myJsonString[i].EndDate);
                        endDate = endDate.getTime() + 41400000;
                    }
                    if (todayDate.getTime() > startDate && (todayDate.getTime() < endDate || endDate == null || end == 0 || end == null )) {
                        
                        if (todayDate.getTime() > startDate && todayDate.getTime() < newGifEndDay) {
                            $("#aList").prepend(`<li class="listOrder" onclick="openModel(${myJsonString[i].ID})">${myJsonString[i].Title}</li>`);
                        } else {
                            $("#aList").append(`<li onclick="openModel(${myJsonString[i].ID})" style="order:2">${myJsonString[i].Title}</li>`);
                        }
                    }

                }


            }
        },
        eror: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};


function openModel(id){
  let data= myJsonString.filter(data => data.ID == id)     
  $("#an-notes").html(data[0].AnnouncementNote);
  $('#announceModel').modal('show')
 };





/***Carosel Management *****/
function GetRencataEmpList() {
    
    $.ajax({
        url: rencataEmpApiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            for (i = 0; i < data.d.results.length; i++) {
                rencataEmpList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                rencataEmpApiPath = data.d.__next;
                GetRencataEmpList();
                return;
            }



            var empBirthMonth;
            var empBirthYear;
            rencataEmpList;
            if (rencataEmpList.length > 0) {
                for (i = 0; i < rencataEmpList.length; i++) {
                    let empDOB = new Date(new Date(rencataEmpList[i].Created).toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
}));
                    empBirthYear = empDOB.getFullYear();
                    empBirthDate = empDOB.getDate();
                    empBirthMonth=empDOB.getMonth()+1;


                   /* if (((presentDate == empBirthDate) || ( empBirthDate >= pastDate)) && (presentYear == empBirthYear)) {
                        todaykudosEmp.push({ desc:rencataEmpList[i].Appreciationdescription,name: rencataEmpList[i].EmployeeName, mailId: rencataEmpList[i].EmployeeEmail, empPic:rencataEmpList[i].PhotoURL})
                    }*/

                     if(presentDate<=7 && ((presentDate == empBirthDate) || ( empBirthDate >= pastDate)) && ( presentYear == empBirthYear)&& (presentMonth==empBirthMonth ||pastmonth==empBirthMonth) ){ todaykudosEmp.push({ desc:rencataEmpList[i].Appreciationdescription,name: rencataEmpList[i].EmployeeName, mailId: rencataEmpList[i].EmployeeEmail, empPic:rencataEmpList[i].PhotoURL})}

                    else if (presentDate>7 &&((presentDate == empBirthDate) || ( empBirthDate >= pastDate)) && ( presentYear == empBirthYear)&& presentMonth==empBirthMonth) {
                         todaykudosEmp.push({ desc:rencataEmpList[i].Appreciationdescription,name: rencataEmpList[i].EmployeeName, mailId: rencataEmpList[i].EmployeeEmail, empPic:rencataEmpList[i].PhotoURL})
                    }
                  

                }
                //extra add
                  if(todaykudosEmp.length>=15){
                    todaykudosEmps2 = [...todaykudosEmp];
                      todaykudosEmp=todaykudosEmp.slice(0, 15);
                      todaykudosEmps2=todaykudosEmps2.slice(15,31);

                  }
//

            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};

/*** Badge data */

function GetRencataBadgeList() {
    $.ajax({
        url: rencataBadgeApiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            for (i = 0; i < data.d.results.length; i++) {
                rencataBadgeList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                rencataBadgeApiPath = data.d.__next;
                GetRencataBadgeList();
                return;
            }



            var empYearMonth;
            var empBadgeMonth;
            var emppastBadgeMonth;
            rencataBadgeList;
            if (rencataBadgeList.length > 0) {
                for (i = 0; i < rencataBadgeList.length; i++) {
                    let empBDate = new Date(new Date(rencataBadgeList[i].Created).toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
}));
                    empYearMonth = empBDate.getFullYear();
                    empBadgeDate = empBDate.getDate();
                    empBadgeMonth=empBDate.getMonth()+1;
                    


                 if(presentDate<=7 && ((presentDate == empBadgeDate) || ( empBadgeDate >= pastDate)) && ( presentYear == empYearMonth)&& (presentMonth==empBadgeMonth ||pastmonth==empBadgeMonth) ){todayBadgeEmp.push({ empbadge:rencataBadgeList[i].Badge,topic:rencataBadgeList[i].SubCategory1,scorebd:rencataBadgeList[i].Score, name: rencataBadgeList[i].UserName, mailId: rencataBadgeList[i].UserEmail, empPic:rencataBadgeList[i].PhotoURL})}

                    else if (presentDate>7 &&((presentDate == empBadgeDate) || ( empBadgeDate >= pastDate)) && ( presentYear == empYearMonth)&& presentMonth==empBadgeMonth) {
                        todayBadgeEmp.push({ empbadge:rencataBadgeList[i].Badge,topic:rencataBadgeList[i].SubCategory1,scorebd:rencataBadgeList[i].Score,  name: rencataBadgeList[i].UserName, mailId: rencataBadgeList[i].UserEmail, empPic:rencataBadgeList[i].PhotoURL})
                    }
                  

                }
            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};

/*End*/

/**************** slider JSON DATA ***************/
function GetSlierListItems() {
    var apiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Carousel Management')/items";
    $.ajax({
        url: apiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {

            carouselJsonString = data.d.results.filter(data => !data.Delete &&data.SlideImageURL);

            if (carouselJsonString.length > 0) {
                carouselJsonString.sort(GetSortOrder("SlideOrder"));
                $('.rencata-slides').empty()
                for (i = 0; i < carouselJsonString.length; i++) {
                    slideCatogey = carouselJsonString[i].Category;
                    sliderTitle = carouselJsonString[i].Title;
                    sliderOrder = carouselJsonString[i].SlideOrder;
                    sliderState = carouselJsonString[i].State;
                    //sliderImg = carouselJsonString[i].SlideImages.slice(carouselJsonString[i].SlideImages.indexOf("/site"), carouselJsonString[i].SlideImages.indexOf('"id"') - 2);
                    sliderImg = carouselJsonString[i].SlideImageURL.Url;

                  if (slideCatogey == "Kudos"  && todaykudosEmp.length >0 && sliderState == "Active" ) {

                        $('.rencata-slides').append('<div id="Birthday" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Birthday').append('<h2></h2><div class="emp-list"></div>');
                        for (j = 0; j < todaykudosEmp.length; j++) {
                            let empPhoto = todaykudosEmp[j].empPic ? todaykudosEmp[j].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empname = todaykudosEmp[j].name;
                            let Adesc = todaykudosEmp[j].desc;
                            let empMail = todaykudosEmp[j].mailId ? "mailto:"+todaykudosEmp[j].mailId +"?subject=kudos to you!!" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div title= "${Adesc}" class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todaykudosEmp[j].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#Birthday .emp-list').append(content);
                        }

                    }

                    if (slideCatogey == "Kudos"  && todaykudosEmps2.length >0 && sliderState == "Active" ) {

                        $('.rencata-slides').append('<div id="Kudos" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Kudos').append('<h2>Kudos to you!!!</h2><div class="emp-list"></div>');
                        for (j = 0; j < todaykudosEmps2.length; j++) {
                            let empPhoto = todaykudosEmps2[j].empPic ? todaykudosEmps2[j].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empname = todaykudosEmps2[j].name;
                            let Adesc = todaykudosEmps2[j].desc;
                            let empMail = todaykudosEmps2[j].mailId ? "mailto:"+todaykudosEmps2[j].mailId +"?subject=kudos to you!!" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div title= "${Adesc}" class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todaykudosEmps2[j].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#Kudos .emp-list').append(content);
                        }

                    }

                    if (slideCatogey == "Child"   && sliderState == "Active" ) {

                        $('.rencata-slides').append(`<div id="Child" class="rencata-slide"><img src="${sliderImg}" title="${sliderTitle}" /><div class="slide-title">${sliderTitle}</div></div>`);
    $('#Child').append('<a style="margin: 0px;position:absolute; top: 60%; width: 5%; height: 50px; left: 25%;" href="https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/SitePages/Children%27s_Day_2022.aspx" target="_blank" data-interception="off"></a>');
                        }

                    

                    if (slideCatogey == "Badge" && todayBadgeEmp.length > 0 && sliderState == "Active") {
                        $('.rencata-slides').append('<div id="Anniversary" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Anniversary').append('<h2> Badge </h2><div class="emp-list"></div>');
                        for (j = 0; j < todayBadgeEmp.length; j++) {
                            let empPhoto = todayBadgeEmp[j].empPic ? todayBadgeEmp[j].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empname = todayBadgeEmp[j].name;
                            let empbadgedata = todayBadgeEmp[j].empbadge;
                            let emptopic = todayBadgeEmp[j].topic;
                            let empscore = todayBadgeEmp[j].scorebd;
                            let empMail = todayBadgeEmp[j].mailId ? "mailto:"+todayBadgeEmp[j].mailId +"?subject=Congrats to you!!" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div title= "${emptopic} ,${empscore} ,${empbadgedata}" class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayBadgeEmp[j].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#Anniversary .emp-list').append(content);
                        }

                    } 
 
                      if (slideCatogey == "Video" && sliderState == "Active") {
                        
                        $('.rencata-slides').append(`<div class="rencata-slide"><video style="height:425px; width:100%" title="${sliderTitle}" poster="${sliderImg}" controls autoplay> <source src="${sliderImg}" title="${sliderTitle}" type="video/mp4"> </video><div class="slide-title">${sliderTitle}</div></div>`);
                    }


                    if (slideCatogey == "Others" && sliderState == "Active") {
                        
                        $('.rencata-slides').append(`<div class="rencata-slide"><img src="${sliderImg}" title="${sliderTitle}" /><div class="slide-title">${sliderTitle}</div></div>`);
                    }
                }
            }
        },

        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};


/* Notification Module*/

/*
function showBellNotification(){
    notificationAPIPath[0] = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Offshore New Employee onboarding Checklist')/items";
    notificationAPIPath[1] = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Offshore Offboarding Checklist')/items";
    GetNotificationList();
    getOffboardingNotiList();
    var notificationCount = 0;
    notificationList = notificationList.filter(function(n){return n.To != null && n.Completed_x003f_.toLowerCase() === 'no'});
    if (notificationList.length > 0) {
        for (i = 0; i < notificationList.length; i++) {
            if (notificationList[i].To.toLowerCase().includes(userEmail)) {

                notificationCount += 1;
               
            } else if (notificationList[i].CC) {
                if (notificationList[i].CC.toLowerCase().includes(userEmail)) {
                    notificationCount += 1;
                   
                }
            }
        }
        
        if(notificationCount > 0){
        $('#notiCount').html(notificationCount);
        $('.notification').addClass('alert');
        $('.notification__bell').animate({deg:45},250);
        } else $('.notification').removeClass('alert');

    }
    notificationList=[];
}
showBellNotification();
setInterval(showBellNotification,20000);
*/




//add emp dob and doj 

/*                    if (slideCatogey == "Birthday" && todayBdayEmp.length > 0 && sliderState == "Active") {

                        $('.rencata-slides').append('<div id="Birthday" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Birthday').append('<h2>RENCATA Wishes a Happy Birthday to our employee(s)</h2><div class="emp-list"></div>');
                        for (j = 0; j < todayBdayEmp.length; j++) {
                            let empPhoto = todayBdayEmp[j].empPic ? todayBdayEmp[j].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empMail = todayBdayEmp[j].mailId ? "mailto:"+todayBdayEmp[j].mailId +"?subject=Happy Birthday" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayBdayEmp[j].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#Birthday .emp-list').append(content);
                        }

                    } 


                    if (slideCatogey == "Anniversary" && todayAnnivarsary.length > 0 && sliderState == "Active") {
                        todayAnnivarsary.sort(GetSortOrder("yoj"));
                        $('.rencata-slides').append('<div id="Anniversary" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Anniversary').append('<h2>RENCATA Wishes a Happy Anniversary to our employee(s)</h2><div class="emp-list"></div>');
                        for (k = 0; k < todayAnnivarsary.length; k++) {
                            let completedYr = presentYear - todayAnnivarsary[k].yoj;
                            let empPhoto = todayAnnivarsary[k].empPic ? todayAnnivarsary[k].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empMail = todayAnnivarsary[k].mailId ? "mailto:"+todayAnnivarsary[k].mailId +"?subject=Happy Work Anniversary" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayAnnivarsary[k].name}<br/><span style="padding:0px">${completedYr}&nbspYear(s) Completed</span></div>
                            <i class="fa fa-envelope" style="font-size:13px;" aria-hidden="true"></div></div></a>`
                            $('#Anniversary .emp-list').append(content);

                        }


                    }

                    if (slideCatogey == "New joiners" && todayjoinees.length > 0 && sliderState == "Active") {

                        $('.rencata-slides').append('<div id="New_joiners" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#New_joiners').append('<h2>RENCATA Welcomes you onboarding</h2><div class="emp-list"></div>');
                        for (l = 0; l < todayjoinees.length; l++) {
                            let empPhoto = todayjoinees[l].empPic ? todayjoinees[l].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empMail = todayjoinees[l].mailId ? "mailto:"+todayjoinees[l].mailId +"?subject=Warm Welcome to RENCATA" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayjoinees[l].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#New_joiners .emp-list').append(content);

                        }


                    }*/

//Check admin rights for Edit the website
var loggedUserPath = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + _spPageContextInfo.userId + ")";
var webAbsoluteUrl = _spPageContextInfo.webAbsoluteUrl;
var editRights=[];
var loggedUserMail;
$.ajax({
    url: loggedUserPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        loggedUserMail = data.d.Email;
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
var qAdminTeamList=`${webAbsoluteUrl}/_api/lists/getbytitle('Admin Team')//items?$select=Email&$filter=Email eq '${loggedUserMail}'`;
$.ajax({
    url: qAdminTeamList,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
       
        editRights = data.d.results;
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});


//give/revoke edit rights

if(editRights!=null && editRights.length>0){
    $('button[title="Settings"]').show();
    $('div[id="spCommandBar"]').show();
}
else{
    $('button[title="Settings"]').hide();
    $('div[id="spCommandBar"]').hide();
}


//***** Quick Link  *****/



var addImg = `<span class="_2tvCNqil81Lsi6owqrTDMq  custom-font">SharePoint</span>`;
    $('#leftRegion a').html(addImg);
    $('#leftRegion a span').html('SharePoint');
    $('#leftRegion a').attr("href", "javascript:void(0)");
var webAbsoluteUrl = _spPageContextInfo.webAbsoluteUrl;
var qlPath = `${webAbsoluteUrl}/_api/lists/getbytitle('Quick Links')/items`;
var quickLinks = []
var currentDate = new Date(new Date().toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
})).getTime();
$.ajax({
    url: qlPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
    quickLinks = data.d.results.filter(res => (
        //!res.Delete && 
        res.Active));
    /*quickLinks = quickLinks.filter(res => ((new Date(new Date(res.StartDate).toLocaleString("en-US", {
        timeZone: "America/Los_Angeles"
    })).getTime() < currentDate)) && ((new Date(new Date(res.EndDate).toLocaleString("en-US", {
        timeZone: "America/Los_Angeles"
    })).getTime() > currentDate) || res.EndDate == null));*/
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});

var openModelBox1 = (
  name,
  isIframe,
  Url,
  modelW,
  iframeW,
  iframeH,
  closeFunc
) => {
    let mWidth;
    isIframe =="Mobile" ? mWidth='20%' : mWidth='67%';
    console.log(mWidth);
  let content;
  debugger;
  //isIframe =="Mobile"
    //? (content = `<iframe src="${Url}" width="100%" height="500" frameborder="0" allowtransparency="true">
												//</iframe>`)                                                                          
    //<iframe src="${Url}" width="100%" height="686" frameborder="0" allowtransparency="true">
//</iframe>`)  width: 1000px; left: -60%;
    //: (
        content = `<embed src="${Url}" frameborder="0" width="100%" height="700px">`
                                                //<iframe src="${Url}" width="100%" height="500" frameborder="0" allowtransparency="true">
//</iframe>`);
    //(content = `<embed src="${Url}" frameborder="0" width="100%" height="600px">`);${mWidth}
    //<div class="modal-footer">
    //<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			//<button type="button" class="btn btn-default" data-dismiss="modal" onclick="closeModel('model-${name}')">Close</button>
		//</div>
  let model = `<div class="modal fade" id="model-${name}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false" aria-hidden="true">
<div class="modal-dialog" style="width:67%"> 
	<div class="modal-content">
    <div class="modal-header">
												<button style="opacity: 0.8;" type="button" class="close" data-dismiss="modal" onclick="closeModel('model-${name}')">X</button>
												<h4 class="modal-title" id="myModalLabel">${name}</h4>
											</div>
		<div class="modal-body" style="display:flex; justify-content:center">
          ${content}
              </div>
	</div>
</div>
</div>`;
isIframe =="Mobile" ? mWidth='20%' : mWidth='68%';
  $('.modal-dialog').css('width',mWidth);
  $('body').append(model);
  $('#model-' + name).modal('show');
};



function closeModel(modelID) {
  $(`#${modelID}`).remove();
  $('.modal-backdrop').remove();
}
function GetSortOrder(prop) {
return function (a, b) {
    if (a[prop] > b[prop]) {
        return 1;
    } else if (a[prop] < b[prop]) {
        return -1;
    }
    return 0;
}
};

function handleQuickLink() {

if (quickLinks.length > 0){

quickLinks.sort(GetSortOrder('OrderNumber'))

for(i=0;i < quickLinks.length; i++){
  let content = quickLinks[i].LinkType.toLowerCase() != 'power apps' ? `<li><div class="flip-card">
<a href="${quickLinks[i].URL.Url}" target="_blank" data-interception="off" >
    <div class="flip-card-inner">
        <div class="flip-card-front">
            <img src="${quickLinks[i].DisplayImage.Url}" alt="${quickLinks[i].Title}" style="width:65%" />
        </div>
        <div class="flip-card-back">
           ${quickLinks[i].HoveringImage ? `<img src="${quickLinks[i].HoveringImage.Url}" alt="${quickLinks[i].Title}" style="width:100%" />` : `<h5>${quickLinks[i].Title}</h5>`}
        </div>
    </div>
</a>
</div></li>`
:
`<li><div class="flip-card">
<a href="javascript:void(0)" onclick="openpopupQL('${quickLinks[i].Title.trim().replace(/ /g,"-")}','${quickLinks[i].LayoutofPowerApps}','${quickLinks[i].URL.Url}')">
    <div class="flip-card-inner">
        <div class="flip-card-front">
            <img src="${quickLinks[i].DisplayImage.Url}" alt="${quickLinks[i].Title}" style="width:65%" />
        </div>
        <div class="flip-card-back">
            ${quickLinks[i].HoveringImage ? `<img src="${quickLinks[i].HoveringImage.Url}" alt="${quickLinks[i].Title}" style="width:100%" />` : `<h5>${quickLinks[i].Title}</h5>`}
        </div>
    </div>
</a>
</div></li>
`;

  $('.flip-container').append(content);
  }
  }
}
handleQuickLink()




/*

<a href="javascript:void(0)" onclick="${quickLinks[i].LayoutofPowerApps=="Tablet" ? `openModelBox1('${quickLinks[i].Title.trim().replace(/ /g,"-")}','${quickLinks[i].LayoutofPowerApps}','${quickLinks[i].URL.Url}','100%','100%','500px','')` : `openModelBox('${quickLinks[i].Title.trim().replace(/ /g,"-")}','${quickLinks[i].LayoutofPowerApps}','${quickLinks[i].URL.Url}','30%','100%','500px','')`}">

function openModelBox(name,isIframe,Url)  {
    debugger;
    let mWidth;
    isIframe =="Mobile" ? mWidth='20%' : mWidth='68%';
    console.log(mWidth);
  let content;
  debugger;
  //isIframe =="Mobile"?
     (content = `<iframe src="${Url}" width="100%" height="500px" frameborder="0" allowtransparency="true"></iframe>`)                                                                          
    //old <iframe src="${Url}" width="100%" height="686" frameborder="0" allowtransparency="true">
//</iframe>`)  width: 1000px; left: -60%;
   // :  (content = `<embed src="${Url}" frameborder="0" width="100%" height="700px">`)
                                                //<iframe src="${Url}" width="100%" height="500" frameborder="0" allowtransparency="true">
//</iframe>`);
    //(content = `<embed src="${Url}" frameborder="0" width="100%" height="600px">`);${mWidth}openModelBox('${quickLinks[i].Title.trim().replace(/ /g,"-")}','${quickLinks[i].LayoutofPowerApps}','${quickLinks[i].URL.Url}','100%','100%','500px','')
    //<div class="modal-footer">
			//<button type="button" class="btn btn-default" data-dismiss="modal" onclick="closeModel('model-${name}')">Close</button>
		//</div>
  /*let model = `<div class="modal fade" id="model-${name}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false" aria-hidden="true">
<div class="modal-dialog" style="width:${mWidth}"> 
	<div class="modal-content">
    <div class="modal-header">
                                               <button type="button" class="close" data-dismiss="modal" onclick="closeModel('model-${name}')">X</button>
												<h4 class="modal-title" id="myModalLabel">${name}</h4>
											</div>
		<div class="modal-body" style="display:flex; justify-content:center">
          ${content}
              </div>
		
	</div>
</div>
</div>`;
isIframe =="Mobile" ? mWidth='20%' : mWidth='68%';
  $('.modal-dialog').css('width',mWidth);
  $('body').append(model);
  $('#model-' + name).modal('show');
};
*/

var openModelBox = (
name,
  isIframe,
  Url,
  modelW,
  iframeW,
  iframeH,
  closeFunc
) => {
    let mWidth='20%'
    console.log(mWidth);
  let content;
  debugger;
 content = `<embed src="${Url}" frameborder="0" width="100%" height="700px">`
                                                //<iframe src="${Url}" width="100%" height="500" frameborder="0" allowtransparency="true">
//</iframe>`);
    //(content = `<embed src="${Url}" frameborder="0" width="100%" height="600px">`);${mWidth}
    //<div class="modal-footer">
    //<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			//<button type="button" class="btn btn-default" data-dismiss="modal" onclick="closeModel('model-${name}')">Close</button>
		//</div>
  let model = `<div class="modal fade" id="model-${name}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static" data-keyboard="false" aria-hidden="true">
<div class="modal-dialog" style="width:67%"> 
	<div class="modal-content">
    <div class="modal-header">
												<button style="opacity: 0.8;" type="button" class="close" data-dismiss="modal" onclick="closeModel('model-${name}')">X</button>
												<h4 class="modal-title" id="myModalLabel">${name}</h4>
											</div>
		<div class="modal-body" style="display:flex; justify-content:center">
          ${content}
              </div>
	</div>
</div>
</div>`;
 mWidth='20%' ;
  $('.modal-dialog').css('width',mWidth);
  $('body').append(model);
  $('#model-' + name).modal('show');
};

function openpopupQL(name,layout,url){
    debugger
    layout =="Mobile" ? mWidth='22%' : mWidth='68%';
    layout =="Mobile" ? ml='38%' : ml='20%';
content = `<div style="display:flex;justify-content: space-between;"><p id="namepu" style="color:black;font-weight: 700;font-size: 20px;">${name} </p><button style="background: white;border:none;font-weight: 700;font-size: 18px;" onclick="cancelAction()">X</button></div>
<embed src="${url}" frameborder="0" width="100%" height="700px">`
$(".popupContent").empty();
 $(".popupContent").append(content);
 $('.popupContent').css('width',mWidth);
 $('.popupContent').css('margin-left',ml);
 $("#PopupQuicklink").show();
}
function cancelAction(){
    $("#PopupQuicklink").hide();
}