 var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Learner')/items"
 var studentData =[];

 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }

function showstdet(){
  debugger;
var stdwrap = $('.cevaluation'); //document.getElementByClass('student')
stdwrap.empty();
for(i=0;i<studentData.length; i++){
   stdwrap.append(`<tr><td>${studentData[i].Category}</td>
                         <td>${studentData[i].Course}</td>
                          <td>${studentData[i].Section}</td>
                           <td>${studentData[i].Title}</td></tr>`
   ) 
}
}
function Couresecountdet(){
    //Object to store employee entry counts
    var EmployeeCount={};

    //Counting  employee entries
    for (var i = 0; i < studentData.length; i++) {
  var Course = studentData[i].Course;
  var Category =studentData[i].Category;
  var Topic = studentData[i].Section;

  //Creating a unique key combining

  var EmployeeCOUNTKEY= Course + "-" +  Category + "-" + Topic;

   if (!EmployeeCount.hasOwnProperty(EmployeeCOUNTKEY)) {

    EmployeeCount[EmployeeCOUNTKEY] = 1;
   }else{
       EmployeeCount[EmployeeCOUNTKEY]++;
   }
}

var stdwrap01= $('.cevaluation01'); //document.getElementByClass('student')
stdwrap.empty01();
for (var EmployeeCOUNTKEY in EmployeeCount) {
  var parts = EmployeeCOUNTKEY.split("-");
  var Course = parts[0];
  var Category = parts[1];
  var Topic = parts[2];
  var Count =EmployeeCount[EmployeeCOUNTKEY];

  stdwrap.append(`<tr><td>${EmployeeCOUNTKEY.CATEGORY}</td>
                         <td>${EmployeeCOUNTKEY.Course}</td>
                          <td>${EmployeeCOUNTKEY.TOPIC}</td>
                           <td>${EmployeeCOUNTKEY.Count}</td></tr>`
  )
}

  function initPagination(tableId, itemsPerPage) {
  const table = document.getElementById(tableId);
  const tbody = table.getElementsByTagName('tbody')[0];
  const rows = tbody.getElementsByTagName('tr');
  const numRows = rows.length;

  const numPages = Math.ceil(numRows / itemsPerPage);

  // Create pagination links
  const paginationDiv = document.getElementById('pagination');
  for (let i = 1; i <= numPages; i++) {
    const link = document.createElement('a');
    link.href = '#';
    link.innerText = i;
    link.addEventListener('click', function () {
      showPage(i);
    });
    paginationDiv.appendChild(link);
  }

  // Function to show the selected page and hide others
  function showPage(pageNum) {
    const start = (pageNum - 1) * itemsPerPage;
    const end = Math.min(start + itemsPerPage, numRows);

    for (let i = 0; i < numRows; i++) {
      if (i >= start && i < end) {
        rows[i].style.display = 'table-row';
      } else {
        rows[i].style.display = 'none';
      }
    }
  }

  // Show the first page by default
  showPage(1);
}

// Call the initPagination function on page load
window.addEventListener('load', function () {
  initPagination('myTable', 5); // Adjust 'myTable' with your table ID and '5' with items per page
});

}

  

