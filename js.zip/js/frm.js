var rencataEmpApiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/Lists/Kudos%20Repository/AllItems.aspx";
var notificationAPIPath = [] ;
var myJsonString, carouselJsonString, sliderTitle, sliderImg, sliderOrder, slideCatogey; //To store the data into JSON format
var todayDate = new Date();
var istTodayDate;
var todaykudos = [];
//var todayAnnivarsary = [];
//var todayjoinees = [];
//var rencataEmpList = [];
var notificationList = [];
var userEmail;
var userid = _spPageContextInfo.userId;
var requestUri = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";

if (todayDate.getTimezoneOffset() == 480) {

    istTodayDate = new Date(todayDate.toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));

} else istTodayDate = todayDate;
var presentMonth = istTodayDate.getMonth() + 1;
var presentDate = istTodayDate.getDate();
var presentYear = istTodayDate.getFullYear();

$.ajax({
    url: requestUri,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        userEmail = data.d.Email.toLowerCase();
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});



/***Quarterly Goals *****/

var qgPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Quarterly Goal')/items"

var qgData = [];
var currentDate = new Date(new Date().toLocaleString("en-US", {
    timeZone: "America/Los_Angeles"
})).getTime();

function getQGData(){
$.ajax({
    url: qgPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
        
        for (i = 0; i < data.d.results.length; i++) {
            qgData.push(data.d.results[i]);
        }
        if (data.d.__next) {
            qgPath = data.d.__next;
            getQGData();
            return;
        }
      
let goalData = qgData.filter(
    (e) => (e.Active && !e.Delete)
);
if (goalData.length > 0) {

    for (i=0; i<goalData.length; i++){
    let startDate = new Date(goalData[i].StartDate).getTime();
    let endDate = new Date(goalData[i].EndDate).getTime();
    let img = goalData[i].Photo.Url
   
    let goalContent = `<div class="Quaterly-Goals" ><img src="${img}" onclick="openVideoModel(${goalData[i].ID})" alt="Quarterly Goals" title= "${goalData[i].Title}" style="cursor:pointer; 	width: 100%; " /><img src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/MicrosoftTeams-image%20(10).png" onclick="openVideoModel(${goalData[i].ID})" alt="Quarterly Goals" title= "${goalData[i].Title}" style=" cursor:pointer; position: absolute; width:40px;" /></div>`;

    if (startDate < currentDate && (endDate > currentDate || endDate == 0)) {
        $('.QG-wrap').empty();
        $('.QG-wrap').append(goalContent);
    } 
    }
}else $('.QG-wrap').hide();
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
}

function openVideoModel(id){
let data = qgData.filter(items => items.ID == id);
let vidContent
if(data.Video_x002f_Link== "Video") {
  vidContent = `<video width="100%" height="360" controls>
  <source src="${data[0].Video.Url}" type="video/mp4">
</video>`
} else {
     vidContent = `<iframe width="100%" height="360"  src="${data[0].Video.Url}" allowfullscreen ></iframe>`
}
$('#announceModel .modal-title').html(`${data[0].Title}`)
$("#an-notes").html(vidContent);
$('#announceModel .modal-body a').attr('target','_blank');
$('#announceModel .modal-body a').css({'font-weight':'500','text-decoration':'underline'});
$('#announceModel').modal('show')
};

$('#announceModel').on('hidden.bs.modal', function (e) {
  $("#an-notes").empty()
})


/*
function GetNotificationList() {
    
    $.ajax({
        url: notificationAPIPath[0],
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            
            for (i = 0; i < data.d.results.length; i++) {
                notificationList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                notificationAPIPath[0] = data.d.__next;
                GetNotificationList();
                return;
            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};

function getOffboardingNotiList(){
 $.ajax({
        url: notificationAPIPath[1],
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            
            for (i = 0; i < data.d.results.length; i++) {
                notificationList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                notificationAPIPath[1] = data.d.__next;
                getOffboardingNotiList();
                return;
            }
        },
        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
}
*/
/***Carosel Management *****/
/*
function GetRencataEmpList() {
    
    $.ajax({
        url: rencataEmpApiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
            for (i = 0; i < data.d.results.length; i++) {
                rencataEmpList.push(data.d.results[i]);
            }
            if (data.d.__next) {
                rencataEmpApiPath = data.d.__next;
                GetRencataEmpList();
                return;
            }*/



            var empBirthMonth, empBirthDate, empJoinMonth, empJoinDate, empJoinYear;
            rencataEmpList = rencataEmpList.filter(function(e){return e.field_DOB});
            if (rencataEmpList.length > 0) {
                for (i = 0; i < rencataEmpList.length; i++) {
                    let empDOB = new Date(new Date(rencataEmpList[i].DateofAppreciation.split("T")[0]).toLocaleString("en-US", {timeZone: "Asia/Kolkata"}));
                    empBirthDate = empDOB.getDate();
                    


                  /*  if ((presentDate == empBirthDate) && (presentMonth == empBirthMonth)) {
                        todayBdayEmp.push({ name: rencataEmpList[i].field_Employee_x0020_Name, mailId: rencataEmpList[i].Email, empPic:rencataEmpList[i].Photo})
                    }
                    if ((presentDate == empJoinDate) && (presentMonth == empJoinMonth)) {

                        if (presentYear != empJoinYear) {

                            todayAnnivarsary.push({ name: rencataEmpList[i].field_Employee_x0020_Name, yoj: empJoinYear, mailId: rencataEmpList[i].Email, empPic:rencataEmpList[i].Photo })
                        } else {

                            todayjoinees.push({ name: rencataEmpList[i].field_Employee_x0020_Name, mailId: rencataEmpList[i].Email , empPic:rencataEmpList[i].Photo})
                        }
                    }

                }
            }
        //},
       // error: function (data) {
           // console.log("An error occurred. Please try again.");
      //  }
   // });
//;
//*/
/*End*/


/* JSON Sort method */

function GetSortOrder(prop) {
    return function (a, b) {
        if (a[prop] > b[prop]) {
            return 1;
        } else if (a[prop] < b[prop]) {
            return -1;
        }
        return 0;
    }
};
/**************** Announcement JSON DATA ***************/
function GetAnnouncementListItems() {
    var apiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Announcement List')/items?&$orderby=StartDate";
    $.ajax({
        url: apiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
             debugger;
            if (data.d.results.length > 0) {
                $('.announce-text img').css("display", "none");
                data=  data.d.results.sort((a, b) => b.StartDate > a.StartDate ? 1: -1);
                myJsonString = data
                for (i = 0; i < myJsonString.length; i++) {
                    var startDate = new Date(myJsonString[i].StartDate);
                    var end = new Date(myJsonString[i].EndDate).getTime();
                    var endDate;
                    var newGifEndDay = startDate.getTime() + 86400000;
                    //86340000;
                    startDate = startDate.getTime() - 45000000;
                    //newGifEndDay = startDate + 86340000;
                    if (myJsonString[i].EndDate) {
                        //var end = new Date(myJsonString[i].EndDate);
                        endDate = new Date(myJsonString[i].EndDate);
                        endDate = endDate.getTime() + 41400000;
                    }
                    if (todayDate.getTime() > startDate && (todayDate.getTime() < endDate || endDate == null || end == 0 || end == null )) {
                        
                        if (todayDate.getTime() > startDate && todayDate.getTime() < newGifEndDay) {
                            $("#aList").prepend(`<li class="listOrder" onclick="openModel(${myJsonString[i].ID})">${myJsonString[i].Title}</li>`);
                        } else {
                            $("#aList").append(`<li onclick="openModel(${myJsonString[i].ID})" style="order:2">${myJsonString[i].Title}</li>`);
                        }
                    }

                }


            }
        },
        eror: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};


function openModel(id){
  let data= myJsonString.filter(data => data.ID == id)     
  $("#an-notes").html(data[0].AnnouncementNote);
  $('#announceModel').modal('show')
 };

/**************** slider JSON DATA ***************/
function GetSlierListItems() {
    var apiPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Carousel Management')/items";
    $.ajax({
        url: apiPath,
        headers: {
            Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {

            carouselJsonString = data.d.results.filter(data => data.SlideImages);

            if (carouselJsonString.length > 0) {
                carouselJsonString.sort(GetSortOrder("SlideOrder"));
                $('.rencata-slides').empty()
                for (i = 0; i < carouselJsonString.length; i++) {
                    slideCatogey = carouselJsonString[i].Category;
                    sliderTitle = carouselJsonString[i].Title;
                    sliderOrder = carouselJsonString[i].SlideOrder;
                    sliderState = carouselJsonString[i].State;
                    sliderImg = carouselJsonString[i].SlideImages.slice(carouselJsonString[i].SlideImages.indexOf("/site"), carouselJsonString[i].SlideImages.indexOf('"id"') - 2);

/***********gopi data  */
                    if (slideCatogey == "Kudos" && todaykudos.length >= 7 && sliderState == "Active") {

                        $('.rencata-slides').append('<div id="Appreciation" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Birthday').append('<h2>RENCATA KUDOS</h2><div class="emp-list"></div>');
                        for (j = 0; j < todayBdayEmp.length; j++) {
                            let empPhoto = todayBdayEmp[j].empPic ? todayBdayEmp[j].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empMail = todayBdayEmp[j].mailId ? "mailto:"+todayBdayEmp[j].mailId +"?subject=Happy Birthday" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayBdayEmp[j].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#Birthday .emp-list').append(content);
                        }

                    } 


 /*                   if (slideCatogey == "Anniversary" && todayAnnivarsary.length > 0 && sliderState == "Active") {
                        todayAnnivarsary.sort(GetSortOrder("yoj"));
                        $('.rencata-slides').append('<div id="Anniversary" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#Anniversary').append('<h2>RENCATA Wishes a Happy Anniversary to our employee(s)</h2><div class="emp-list"></div>');
                        for (k = 0; k < todayAnnivarsary.length; k++) {
                            let completedYr = presentYear - todayAnnivarsary[k].yoj;
                            let empPhoto = todayAnnivarsary[k].empPic ? todayAnnivarsary[k].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empMail = todayAnnivarsary[k].mailId ? "mailto:"+todayAnnivarsary[k].mailId +"?subject=Happy Work Anniversary" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayAnnivarsary[k].name}<br/><span style="padding:0px">${completedYr}&nbspYear(s) Completed</span></div>
                            <i class="fa fa-envelope" style="font-size:13px;" aria-hidden="true"></div></div></a>`
                            $('#Anniversary .emp-list').append(content);

                        }


                    }

                    if (slideCatogey == "New joiners" && todayjoinees.length > 0 && sliderState == "Active") {

                        $('.rencata-slides').append('<div id="New_joiners" class="rencata-slide" style="background-image:url(' + sliderImg + ');"><div class="slide-title">' + sliderTitle + '</div></div>');
                        $('#New_joiners').append('<h2>RENCATA Welcomes you onboarding</h2><div class="emp-list"></div>');
                        for (l = 0; l < todayjoinees.length; l++) {
                            let empPhoto = todayjoinees[l].empPic ? todayjoinees[l].empPic.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
                            let empMail = todayjoinees[l].mailId ? "mailto:"+todayjoinees[l].mailId +"?subject=Warm Welcome to RENCATA" : "javascript:void(0)";
                            let content = `<a href="${empMail}"><div class="card"><div class="empName-wrap"><img src="${empPhoto}" alt="Avatar">
                            <div class="empName">${todayjoinees[l].name}<div><i class="fa fa-envelope" aria-hidden="true"></i><span>Send Wishes</span></div></div></div></div></a>`
                            $('#New_joiners .emp-list').append(content);

                        }


                    }*/


                    if (slideCatogey == "Others" && sliderState == "Active") {
                        
                        $('.rencata-slides').append(`<div class="rencata-slide"><img src="${sliderImg}" title="${sliderTitle}" /><div class="slide-title">${sliderTitle}</div></div>`);
                    }
                }
            }
        },

        error: function (data) {
            console.log("An error occurred. Please try again.");
        }
    });
};

/* Notification Module*/

/*
function showBellNotification(){
    notificationAPIPath[0] = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Offshore New Employee onboarding Checklist')/items";
    notificationAPIPath[1] = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Offshore Offboarding Checklist')/items";
    GetNotificationList();
    getOffboardingNotiList();
    var notificationCount = 0;
    notificationList = notificationList.filter(function(n){return n.To != null && n.Completed_x003f_.toLowerCase() === 'no'});
    if (notificationList.length > 0) {
        for (i = 0; i < notificationList.length; i++) {
            if (notificationList[i].To.toLowerCase().includes(userEmail)) {

                notificationCount += 1;
               
            } else if (notificationList[i].CC) {
                if (notificationList[i].CC.toLowerCase().includes(userEmail)) {
                    notificationCount += 1;
                   
                }
            }
        }
        
        if(notificationCount > 0){
        $('#notiCount').html(notificationCount);
        $('.notification').addClass('alert');
        $('.notification__bell').animate({deg:45},250);
        } else $('.notification').removeClass('alert');

    }
    notificationList=[];
}
showBellNotification();
setInterval(showBellNotification,20000);
*/


