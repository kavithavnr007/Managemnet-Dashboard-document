
 //var cmtdocPath12 = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Completed Course Certificate')/items?&$top=5000"
 var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Completed Course Certificate')/items"
 var studentData =[];
var tableRows =[];
 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }

 function studentdup(){
 var inputBox = document.getElementById("Searchresultsum");
  inputBox.value = "";

  $('.nocertify15').hide();
  $('.clear-certify15').hide();
  $('.cContainer13').empty()
 if(studentData.length>0){



 var stdwrap = $('.cContainer12');
 stdwrap.empty();
// Object to store employee entry counts
var entryCounts01 = {};
var timeSums = {}; // Object to store total time sums for each entry
console.log("entryCounts01" , entryCounts01);
// Counting employee entries
for (var i = 0; i < studentData.length; i++) {
 
  var coursename = studentData[i].CourseName
  
  // Creating a unique key combining employeeId and department
  var key = coursename ;

  if (!entryCounts01.hasOwnProperty(key)) {
    entryCounts01[key] = 1;
    
  } else {
    entryCounts01[key]++;
    
  }
}
debugger;
for (var key in entryCounts01) {
  var parts = key.split("|");
  var coursename= parts[0];
  var count = entryCounts01[key];
  // Calculate average time

  // Create the HTML table row and push it to the array 
  



var payload = {

'coursename':coursename,

'count' : count

};



  tableRows.push(payload);
  // stdwrap.append(`<tr><td>${coursename}</td>

  //                          <td><button style="background:transparent;border:none;" onclick="EmployeeDetailshowbelow('${coursename}')" background: transparent;
  //   border: none;> ${count}</button></td></tr>`
  //  )
  stdwrap.append(`<div class="post" onclick="">
  <p>${coursename}</p>
  <button style="background:transparent;border:none;padding-left:90%;" onclick="EmployeeDetailshowbelow('${coursename}')" background: transparent;
    border: none;> ${count}</button>
  </div>`)



  //coursePAGE.push( key )
   }
}
 else{
   $('.nocertify15').show();
}

 }
 //console.log("stdwrap" + stdwrap  );

//function showstdet(){
  //debugger;
//var stdwrap = $('.cevaluation'); //document.getElementByClass('student')
//stdwrap.empty();
//for(i=0;i<studentData.length; i++){
  // stdwrap.append(`<tr><td>${studentData[i].Category}</td>
    //                     <td>${studentData[i].Course}</td>
    //                    <td>${studentData[i].Section}</td>
   //                       <td>${studentData[i].Title}</td></tr>`
   //) 
//}
//}
function Couresecountdet(){
    //Object to store employee entry counts
    var EmployeeCount={};

    //Counting  employee entries
    for (var i = 0; i < studentData.length; i++) {
  var coursename= studentData[i].CourseName;
  
  //Creating a unique key combining

  var EmployeeCOUNTKEY= coursename ;

   if (!EmployeeCount.hasOwnProperty(EmployeeCOUNTKEY)) {

    EmployeeCount[EmployeeCOUNTKEY] = 1;
   }else{
       EmployeeCount[EmployeeCOUNTKEY]++;
   }
}

}

function EmployeeDetailshowbelow(coursename)
{
  debugger

var lsrdata =[];

lsrdata = studentData.filter(list => list.CourseName.toLocaleLowerCase() ===coursename.toLocaleLowerCase() )
var lsrdata1 = $('.cContainer13');
lsrdata1.empty();
console.log("lsrdata: " + lsrdata); 
for(i=0;i<lsrdata.length; i++){
   lsrdata1.append(`<tr><td>${lsrdata[i].CourseName}</td>
                         <td>${lsrdata[i].UserEmail}</td>
                         <td>${new Date(lsrdata[i].Created).toLocaleDateString('en-GB')}</td>
                         <td>${lsrdata[i].TOTALTime}</td>
                         <td>${lsrdata[i].Retake}</td>
                         <td>${lsrdata[i].PauseTimer}</td>
                         </tr>`
   )  
}

  
}

//  Assuming 'sharepointData' is the array of SharePoint data

// function searchData(inputValue) {

//     debugger;

//   const searchResults = tableRows.filter(item => {

//      Replace 'columnName' with the actual name of the column you want to search

//     return item.coursename.toLowerCase().includes(inputValue.toLowerCase());

//   });

//   return searchResults;

// }



//  Add the onchange event handler to the input element

//  function searchfun() {
// debugger;

// const searchInput = document.getElementById("Searchresultsum");
//   const inputValue = searchInput.value;

//   if(inputValue.length >0){
// $('.nocertify15').hide();
//       $('.clear-certify15').show()   
// $('.cContainer13').empty()
//   }

//   else{
// $('.nocertify15').show();
//      $('.clear-certify15').hide()  
// $('.cContainer13').empty()
//   };

//   var results = searchData(inputValue);

//   console.log(results);

// var stdwrap = $('.cContainer12');
//  stdwrap.empty();


// if(results.length > 0){
//   stdwrap.show()


// results.map(items => stdwrap.append(`<div class="post" onclick="">
//   <p>${items.coursename}</p>
//                            <button style="background:transparent;border:none;padding-left:90%" onclick="EmployeeDetailshowbelow('${items.coursename}')" background: transparent;
//     border: none;> ${items.count}</button>
//   </div>`)) <div class="vl"></div>
// }
// else{
// $('.nocertify15').show();

//  }
// };

function searchData(inputValue) {
  // Filter the tableRows array based on the inputValue
  const searchResults = tableRows.filter(item => {
    return item.coursename.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Add the onchange event handler to the input element
function searchfun() {
  const searchInput = document.getElementById("Searchresultsum");
  const inputValue = searchInput.value.toLowerCase();

  if (inputValue.length > 0) {
    $('.nocertify15').hide();
    $('.clear-certify15').show();
    $('.cContainer13').empty();
  } else {
    $('.nocertify15').show();
    $('.clear-certify15').hide();
    $('.cContainer13').empty();
  }

  // Perform the search and store the results in the 'results' variable
  var results = searchData(inputValue);
  console.log(results);

  var stdwrap = $('.cContainer12');
  stdwrap.empty();

  // Use a Set to store unique course names
  var uniqueCourses = new Set();

  if (results.length > 0) {
    stdwrap.show();

    results.forEach(item => {
      // Check if the course name is unique
      if (!uniqueCourses.has(item.coursename)) {
        uniqueCourses.add(item.coursename);

        stdwrap.append(`<div class="post" onclick="">
          <p>${item.coursename}</p>
          <button style="background:transparent;border:none;padding-left:90%" onclick="EmployeeDetailshowbelow('${item.coursename}')">${item.count}</button>
        </div>`);
      }
    });
  } else {
    $('.nocertify15').show();
  }
}


