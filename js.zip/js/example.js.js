var custumerpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Customer Details')/items"
var custumerdata =[];

// to get the custumer details

function custumerdet() {

debugger;

$.ajax({

url: custumerpath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,
success: function (data) {
custumerdata = data.d.results;

custumerdata= custumerdata.filter(item=> item. Title=="RK")

 

console.log("custumer details: " + custumerdata);

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});

}
