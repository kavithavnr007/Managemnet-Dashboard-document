 var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Topic Evaluation User Badge')/items"
 var studentData =[];
var tableRows =[];
 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose",
        'Cache-Control': 'no-cache',
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }

 function studentdup(){
 var inputBox = document.getElementById("Searchresultsum");
  inputBox.value = "";

  $('.nocertify15').hide();
  $('.clear-certify15').hide();
  $('.cContainer20').empty();
  
 if(studentData.length>0){



 var stdwrap = $('.cContainer19');
 stdwrap.empty();
// Object to store employee entry counts
var entryCounts01 = {};
var timeSums = {}; // Object to store total time sums for each entry
console.log("entryCounts01" , entryCounts01);
// Counting employee entries
for (var i = 0; i < studentData.length; i++) {




  
  var username = studentData[i].UserName
  


  // Creating a unique key combining employeeId and department
  var key = username;

  if (!entryCounts01.hasOwnProperty(key)) {
    entryCounts01[key] = 1;
    
  } else {
    entryCounts01[key]++;
    
  }
}
debugger;
for (var key in entryCounts01) {
  var parts = key.split("|");
  var username= parts[0];
  var count = entryCounts01[key];
  // Calculate average time

  // Create the HTML table row and push it to the array 
  



var payload = {

'username':username,

'count' : count

};



  tableRows.push(payload);
  // stdwrap.append(`<tr><td>${coursename}</td>

  //                          <td><button style="background:transparent;border:none;" onclick="EmployeeDetailshowbelow('${coursename}')" background: transparent;
  //   border: none;> ${count}</button></td></tr>`
  //  )
  stdwrap.append(`<div class="post" onclick="">
  <p>${username}</p>
  <button style="background:transparent;border:none;padding-left:90%;" onclick="EmployeeDetailshowbelow('${username}')" background: transparent;
    border: none;> ${count}</button>
  </div>`)



  //coursePAGE.push( key )
   }
}
 else{
   $('.nocertify15').show();
}

 }
 //console.log("stdwrap" + stdwrap  );

//function showstdet(){
  //debugger;
//var stdwrap = $('.cevaluation'); //document.getElementByClass('student')
//stdwrap.empty();
//for(i=0;i<studentData.length; i++){
  // stdwrap.append(`<tr><td>${studentData[i].Category}</td>
    //                     <td>${studentData[i].Course}</td>
    //                    <td>${studentData[i].Section}</td>
   //                       <td>${studentData[i].Title}</td></tr>`
   //) 
//}
//}
function Couresecountdet(){
    //Object to store employee entry counts
    var EmployeeCount={};

    //Counting  employee entries
    for (var i = 0; i < studentData.length; i++) {
  var username= studentData[i].UserName;
  
  //Creating a unique key combining

  var EmployeeCOUNTKEY= username;

   if (!EmployeeCount.hasOwnProperty(EmployeeCOUNTKEY)) {

    EmployeeCount[EmployeeCOUNTKEY] = 1;
   }else{
       EmployeeCount[EmployeeCOUNTKEY]++;
   }
}

}

function EmployeeDetailshowbelow(username)
{
  debugger

var lsrdata =[];

lsrdata = studentData.filter(list => list.UserName.toLocaleLowerCase() ===username.toLocaleLowerCase() )
var lsrdata1 = $('.cContainer20');
lsrdata1.empty();
console.log("lsrdata: " + lsrdata); 
for(i=0;i<lsrdata.length; i++){
   lsrdata1.append(`<tr><td>${lsrdata[i].UserName}</td>
                         <td>${lsrdata[i].Category}</td>
                         <td>${lsrdata[i].Category1}</td>
                         <td>${lsrdata[i].Section}</td>
                         <td>${lsrdata[i].Score}</td>
                         <td>${lsrdata[i].Rounds}</td>
                         <td>${new Date(lsrdata[i].Created).toLocaleDateString('en-GB')}</td>
                         <td>${lsrdata[i].PauseTimer}</td>
                         <td>${lsrdata[i].TOTALTime}</td>
                         </tr>`
   )  
}

  
}

// Assuming 'sharepointData' is the array of SharePoint data

function searchData(inputValue) {

    debugger;

  const searchResults = tableRows.filter(item => {

    // Replace 'columnName' with the actual name of the column you want to search

    return item.username.toLowerCase().includes(inputValue.toLowerCase());

  });

  return searchResults;

}



// Add the onchange event handler to the input element
function searchfun() {
  const searchInput = document.getElementById("Searchresultsum");
  const inputValue = searchInput.value.toLowerCase();

  if (inputValue.length > 0) {
    $('.nocertify15').hide();
    $('.clear-certify15').show();
    $('.cContainer20').empty();
  } else {
    $('.nocertify15').show();
    $('.clear-certify15').hide();
    $('.cContainer20').empty();
  }

  var results = searchData(inputValue);

  console.log(results);

  var stdwrap = $('.cContainer19');
  stdwrap.empty();

  if (results.length > 0) {
    stdwrap.show();

    // Use a Set to store unique usernames
    var uniqueUsernames = new Set();

    results.forEach(item => {
      if (!uniqueUsernames.has(item.username)) {
        uniqueUsernames.add(item.username);

        stdwrap.append(`<div class="post" onclick="">
          <p>${item.username}</p>
          <button style="background:transparent;border:none;padding-left:90%" onclick="EmployeeDetailshowbelow('${item.username}')"> ${item.count}</button>
        </div>`);
      }
    });
  } else {
    $('.nocertify15').show();
  }
}
