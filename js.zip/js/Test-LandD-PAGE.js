 var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Learner')/items"
 var studentData =[];
 var coursePAGE=[];
 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }
function Studentdup(){
 var stdwrap = $('.cevaluation');
 stdwrap.empty();
// Object to store employee entry counts
var entryCounts01 = {};
console.log("entryCounts01" , entryCounts01);
// Counting employee entries
for (var i = 0; i < studentData.length; i++) {
  var Course = studentData[i].Course;
  var Category = studentData[i].Category;
  var Section = studentData[i].Section;

  // Creating a unique key combining employeeId and department
  var key = Course + "|" + Category + "|" + Section;

  if (!entryCounts01.hasOwnProperty(key)) {
    entryCounts01[key] = 1;
  } else {
    entryCounts01[key]++;
  }
}
debugger;
for (var key in entryCounts01) {
  var parts = key.split("|");
  var  Course = parts[0];
  var Category = parts[1];
  var Section = parts[2];
  var Count = entryCounts01[key];
  stdwrap.append(`<tr><td>${Category}</td>
                         <td>${Course}</td>
                          <td>${Section}</td>
                           <td>${Count}</td></tr>`
   )
  
  //coursePAGE.push( key )
  
}

// Creating HTML table
// var table = "<table>";
// table += "<tr><th>Course</th><th>Category</th><th>Section</th><th>Employee Count</th></tr>";

 
/*
function showstdet(){
  debugger;
var stdwrap = $('.cevaluation'); //document.getElementByClass('student')
stdwrap.empty();
for(i=0;i<studentData.length; i++){
   stdwrap.append(`<tr><td>${studentData[i].Category}</td>
                         <td>${studentData[i].Course}</td>
                          <td>${studentData[i].Section}</td>
                           <td>${studentData[i].Title}</td></tr>`
   ) 
}
}*/

// {  table += "<tr>";
//   table += "<td>" + Course  + "</td>";
//   table += "<td>" + Category + "</td>";
//   table += "<td>" + Section  + "</td>";
//   table += "<td>" + Count + "</td>";
//   table += "</tr>";
// }

// table += "</table>";

// // Displaying the table
// document.body.innerHTML = table;
}
