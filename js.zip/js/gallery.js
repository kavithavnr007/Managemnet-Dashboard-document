var socialEventGallery1 = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Social Event Gallery')/items?&$orderby=EventDate"


var socialEventData1 = [];

function handleCampFireScreenold(){
$.ajax({
    url:socialEventGallery1,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
        socialEventData1 = [...socialEventData1,...data.d.results]
        if (data.d.__next) {
            socialEventGallery1 = data.d.__next;
            handleCampFireScreenold();
            return;
        }
        let todayDate = new Date();
    
        let campFireData1 = socialEventData1.filter(res => ( res.Active == true && new Date(res.ExpiryDate).getTime() < todayDate.getTime()&& res.ExpiryDate!= null&&res.Delete != true)).reverse();
$('.camp-fire-list1').empty();   
for (i = 0; i < campFireData1.length; i++) {
let slide = `
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <a href="javascript:void(0)" onclick="detailsPage1('CampFire',${campFireData1[i].ID},'${campFireData1[i].Navigation_x0020_Path}')">
                    <div class="card-flyer">
                        <div class="text-box">
                            <div class="image-box">
                                <img src="${campFireData1[i].DisplayImage.Url}" alt="" />
                            </div>
                            <div class="text-container">
                                <h3>${campFireData1[i].Title.replace(/<[^>]*>?/gm, '')}</h3>
                                <h6>${new Date(campFireData1[i].EventDate).toString().slice(4,15)}</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            
`

//<div class="divider"></div>
$('.camp-fire-list1').append(slide);
socialEventData = [];
}


    },


    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
}


function detailsPage1(navPath,gID,folderPath){
    
  localStorage.setItem("root_live" , navPath);    
  localStorage.setItem("vistaGid_live" , gID);
  localStorage.setItem("vistaFolderPath_live" , folderPath);
  window.open('https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/SitePages/Details-Page.aspx', '_blank');
  //window.location = "";
  
  }