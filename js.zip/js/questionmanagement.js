var coursepath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Course Evaluation Quiz')/items"
var courseData = [];
var questionmanagement;
//to get the student details

function Couseget() {
    debugger;
$.ajax({
    url: coursepath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        courseData= data.d.results;
        console.log("course details: " + courseData);
    },
    error: function (data) {
        console.log("An error occured. please try again.");
    }
})
}

function savesdet(){
    debugger;
     var stdwrap = $('.tquiz');
     stdwrap.empty();
    for(i=0;i<courseData.length;i++){
        stdwrap.append(`<tr style="margin: 10px 0; box-shodow: 4px 2px 2px #ccc;">
                                
                                <td>${courseData[i].Category}</td>
                                <td>${courseData[i].Category1}</td>
                                <td>${courseData[i].Title}</td>
                                <td>${courseData[i].SlideOrder}</td>
                                <td>${courseData[i].TimerDuration}</td>
                                <td>${courseData[i].Rounds}</td>
                                
                                <td>
                                <div style="display: flex;">
                                    <div onclick="QuestionDetail(${courseData[i].ID})" style="padding:5px;"><img width="20"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/eye.svg"></div>
                                    <div onclick="showpopup1('${courseData[i].ID}','${courseData[i].Category.length> 0 ? courseData[i].Category : `Null`}','${courseData[i].Category1.length> 0 ? courseData[i].Category1 : `Null`}','${courseData[i].QuizLevel}' ,'${courseData[i].SlideOrder}','${courseData[i].TimerDuration}','${courseData[i].Rounds}') "style="padding: 2px 8px;"><img width="18"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/edit.svg"></div>

                                    <div onclick="showpopup(${courseData[i].ID}) "style="padding:5px;"><img width="15"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/delete.svg"></div></div>
                                </td>
                            </tr>`)
}
}

function QuestionDetail(id){
    
let data = courseData.filter(items => items.ID == id);
let content = ` <div class="c-container3"><div class="c-wrap">
 <p> <b> COURSE</b> : ${data[0].Category} </p>
 <p> <b> CATEGORY</b> : ${data[0].Category1} </p>
 <p> <b> SECTION </b> : ${data[0].Title} </p>
 <p> <b> ORDER </b> : ${data[0].SlideOrder } </p>
 <p> <b> TIME DURATION </b> : ${data[0].TimerDuration } </p>
 <p> <b> RETAKE </b> : ${data[0].Rounds } </p>
 </div>`;

$('#QuestionDetail .modal-title').html(`${data[0].Category.replace(/<[^>]*>?/gm, '')}`);

$('#QuestionDetail .modal-body').html(content);

$('#QuestionDetail').modal('show')
}

function deleteRecordFromList(itemId) {
  debugger;
  var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
  var listName = 'Course Evaluation Quiz';
00
  // Endpoint URL
  var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/getItemById(" + itemId + ")";

  // Refresh the Request Digest value
  $.ajax({
    url: siteUrl + "/_api/contextinfo",
    method: "POST",
    headers: { "Accept": "application/json;odata=verbose" },
    success: function(data) {
      var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

      // Make the AJAX POST request with the refreshed Request Digest value
      $.ajax({
        url: url,
        type: "POST",
        headers: {
          "Accept": "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose",
          "X-RequestDigest": requestDigest,
          "X-HTTP-Method": "DELETE",
          "If-Match": "*"
        },
        success: function(data) {
                  $(".popup").css('display','none');
                  courseData = [];
                  Couseget();
                  savesdet();
                  console.log("Item deleted successfully.");
        },
        error: function(error) {
          console.log("Error deleting item: " + JSON.stringify(error));
          // Handle error
        }
      });
    },
    error: function(error) {
      console.log("Error refreshing Request Digest: " + JSON.stringify(error));
      // Handle error
    }
  });
}
//show popup


function showpopup(id){
    debugger;
 $(".popup").css('display','block');
 window.confirmationparams ={
   param1:id
 }
}

function confirmdel(){
  debugger;
  var params = window.confirmationparams;
   var param1 = params.param1;
   deleteRecordFromList(param1);

}

function closepopup(){
    debugger;
    $(".popup").css('display','none');

}


function getFormDigest() {
return $.ajax({
url: "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/contextinfo",
method: "POST",
headers: { "Accept": "application/json; odata=verbose" }
});
}
debugger;
function editrecord(id){
var itemID = id;
var newDescription = $('#newDescription').val();

var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
var listName = 'Course Evaluation Quiz';
var encodedListName = listName.replace(/ /g, '_x0020_');
var endpointUrl = siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items(" + itemID + ")";

getFormDigest().then(function (data) {
var formDigestValue = data.d.GetContextWebInformation.FormDigestValue;

var slideOrderValue = parseInt($("#iorder").val(), 10);

if (isNaN(slideOrderValue)) {
  // Handle the case when the input is not a valid number
  console.error('Slide Order is not a valid number:', $("#iorder").val());
} else {
  // Update the SlideOrder in the itemPayload object
  var itemPayload = {
    __metadata: { 'type': 'SP.Data.' + encodedListName + 'ListItem' },
    Category: $("#icourse").val(),
    Category1: $("#icategory").val(),
    QuizLevel: $("#ititle").val(),
    SlideOrder: slideOrderValue, // Use the parsed slideOrderValue
    TimeDuration: $("#itimerduration").val(),
    Rounds: $("#iretake").val()
  };
  // ... Your existing code to send the request to SharePoint ...
}

$.ajax({
url: endpointUrl,
type: 'POST',
contentType: 'application/json;odata=verbose',
data: JSON.stringify(itemPayload),
headers: {
'X-RequestDigest': formDigestValue,
'IF-MATCH': '*',
'X-HTTP-Method': 'MERGE'
},

success: function (data) {
$(".popupForm1").css('display','none');
    Couseget();
    savesdet();
alert('Item updated successfully!');
},


error: function (error) {
alert('Error updating item: ' + JSON.stringify(error));
}
});
});
}

function showpopup1(id,Category,Category1,QuizLevel,SlideOrder,TimeDuration,Rounds){
    debugger;
 $(".popupForm1").css('display','block');
  var input=document.getElementById("icourse").value=Category;
  var input=document.getElementById("icategory").value=Category1;
  var input=document.getElementById("ititle").value=QuizLevel;
  var input=document.getElementById("iorder").value=SlideOrder;
  var input=document.getElementById("itimeduration").value=TimeDuration;
  var input=document.getElementById("iretake").value=Rounds;
 window.confirmationparams ={
   param1:id
 }
}

function closepopup2(){
    debugger;
    $(".popupForm1").css('display','none');

}

function confirmedit(){

debugger;
var params = window.confirmationparams;
var param1 = params.param1;
editrecord(param1);
}
 