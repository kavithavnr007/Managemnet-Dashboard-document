/***LMS*****/

var lmsPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Course List')/items?&$top=5000"
var favtPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS favorite')/items?&$top=5000"
debugger;
var lmsData = [];
var results=[];
var favtdata =[];
var loggedUserPath = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + _spPageContextInfo.userId + ")";
var loggedUserMail,myEmail,userName =[];

function lmsfunc() {
debugger;
$.ajax({
    url: loggedUserPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        loggedUserMail = data.d.Email;
        userName = data.d.Title;
        console.log("Logged-in user: " + userName);
        /*if(myEmail.includes(loggedUserMail)==false){
            myEmail.push(loggedUserMail);
        }*/
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});


$.ajax({
    url: favtPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        favtdata = data.d.results;
        console.log("favt list: " + favtdata);
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});


$.ajax({

url:lmsPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

lmsData = [...lmsData,...data.d.results]

if (data.d.__next) {

lmsPath = data.d.__next;

lmsfunc();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});



//external user or internal user

function isExternalUser() {
      var email = loggedUserMail;

      // Get the domain part of the email address
      var emailDomain = email.substring(email.indexOf("@") + 1);

      // Compare the domain with your organization's domain
      var organizationDomain = "rencata.com";
      var isExternal = emailDomain.toLowerCase() !== organizationDomain;
      var elements = document.getElementsByClassName("containerlog");

for (var i = 0; i < elements.length; i++) {
  var element = elements[i];
  element.style.height = window.innerHeight + "px";
}
      if (isExternal) {
        $(".containerlog").show();
        console.log("The logged-in user is an external user.");
        window.location.replace(webAbsoluteUrl+ "/SitePages/Login%20Page.aspx")
      } else {
        $(".containerlog").show();
        console.log("The logged-in user is not an external user.");
      }
}

//end of the user chk code





}



function appendlms(){
let lmsWrap = $('.career-wrap3');
var inputBox = document.getElementById("searchInput");
  inputBox.value = "";
   $('.clear-search').hide();
   $('.tableview').hide();
   $('#no-records-message').hide();
   const selectElement = document.getElementById("mySelect");
    selectElement.selectedIndex = 0;  
lmsWrap.empty()

// Sort the data based on the sort direction and column
 lmsData.sort((a, b) => {
  if (a.Title < b.Title) {
    return -1;
  }
  if (a.Title > b.Title) {
    return 1;
  }
  return 0;
});
//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

//table view
debugger;
const viewElement = document.getElementById("viewselect");
    const selectedviewValue = viewElement.value;
    console.log(selectedviewValue);
    
  if (selectedviewValue === "option2") {
    
    $('.tableview').show();
var tableData = lmsData.map(value => {
  const starPercentage = (value.Rating / 5) * 100;
  const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;

  return (
    `<tr class="${value.ID}">
       <td>${value.ID}</td>
       <td>${value.Title}</td>
       <td>${value.Category}</td>
       <td>${value.Sections}</td>
       <td>${value.Author0}</td>
       <td title="${value.AboutAuthor}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3em;overflow: hidden;text-overflow: ellipsis;">${value.AboutAuthor}</td>
       <td>${value.NoofHits}</td>
       <td><div class="stars-outer">
          <div class="stars-inner" style="width: ${starPercentageRounded}"></div>
        </div></td>
    </tr>`
  );

  //document.querySelector(`.${value.ID} .stars-inner`).style.width = starPercentageRounded; 
}).join('');

const tableBody = document.querySelector("#tableBody");
tableBody.innerHTML = tableData;

/*
$('.camp-fire-list').empty();   
for (i = 0; i < lmsData.length; i++) {
let slide = `
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-2">
                <a href="javascript:void(0)" onclick="">
                    <div class="card-flyer">
                        <div class="text-box">
                        <div style="width: 100%; background: #d96910; padding-top: 1px;">
                            <div class="image-box">
                                <img src="${ lmsData[i].ImageURL ? (lmsData[i].ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" alt="" />
                            </div>
                        </div>
                            <div class="text-container">
                                <h3>${lmsData[i].Title.replace(/<[^>]*>?/gm, '')}</h3>
                                <h6>${lmsData[i].Sections.replace(/<[^>]*>?/gm, '')}</h6>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            
`


$('.camp-fire-list').append(slide);
socialEventData = [];
}*/


}


//grid view
else{
if(lmsData.length > 0){
  $('.career-wrap3').empty();
  $('.car-container3').show();
  $('.career-wrap3').show();
for (k=0; k<lmsData.length; k++){
//lmsData.map(items => //list.Course.toLowerCase() === lmsData[k].Title && list.Course.toLowerCase() === lmsData[k].Title.toLowerCase() &&

lmsWrap.append(`<div class="post" onclick=""><img src="${ lmsData[k].ImageURL ? (lmsData[k].ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/>
${ (favtdata.filter(list =>  list.EmployeeEmail === loggedUserMail && list.Course === lmsData[k].Title &&  list.Category === lmsData[k].Category && list.Section === lmsData[k].Sections)).length >0   ? `<img title="Your favorite"  align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/favorite.png" style="border:none;border-radius:0%;width: 20px;height: 20px;margin-left: 240px;float: right;position: absolute;">` :
`<img title="Add to favorite" onclick="addRecordTofavt('${lmsData[k].Title.replace(/'/g, "\\'")}','${lmsData[k].Category.replace(/'/g, "\\'")}','${lmsData[k].Sections.replace(/'/g, "\\'")}', '${lmsData[k].NavigateURL.Url.replace(/'/g, "\\'")}', '${lmsData[k].ImageURL.Url.replace(/'/g, "\\'")}' , '${lmsData[k].SectionOverview.replace(/'/g, "\\'")}','${lmsData[k].Author0.replace(/'/g, "\\'")}','${lmsData[k].AboutAuthor.replace(/'/g, "\\'")}')" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Addtofav8.jpg" style="border:none;border-radius:0%;width: 25px;height: 25px;margin-left: 240px;float: right;position: absolute;">`}

<a title="Start Course" target="_blank" data-interception="off" href="${lmsData[k].NavigateURL ? lmsData[k].NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}">
<img title="Start Course" onclick="addRecordToList('${lmsData[k].Title}','${lmsData[k].Category.replace(/'/g, "\\'")}','${lmsData[k].Sections.replace(/'/g, "\\'")}','${lmsData[k].NavigateURL.Url}','${lmsData[k].Author0.replace(/'/g, "\\'")}','${lmsData[k].AboutAuthor.replace(/'/g, "\\'")}')" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/view-data-PhotoRoom.png-PhotoRoom.png" style="border:none;border-radius:0%;width: 30px;height: 80px;padding-bottom: 20px;float: right;margin-top: 30px;"></a><p style="font-size: 120%; color:#3d8084;">${lmsData[k].Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${lmsData[k].Sections}</p></div>`)

//) //<div class="vl"></div>
document.getElementById('certificatcount1').innerHTML = 'Course List ( ' + lmsData.length +' )' ;
console.log("lmsData.length",lmsData.length);

}
}}

}



// Assuming 'sharepointData' is the array of SharePoint data
function searchData(inputValue) {
    debugger;
  const searchResults = lmsData.filter(item => {
    // Replace 'columnName' with the actual name of the column you want to search
    return item.Title.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Get a reference to the input element
const searchInput = document.getElementById("searchInput");

// Add the onchange event handler to the input element
searchInput.onchange = function() {
  
  const inputValue = searchInput.value;
  if(inputValue.length >0){
     $('.clear-search').show()  
  }
  else{
      $('.clear-search').hide()  
  };
  var results = searchData(inputValue);
  console.log(results);
  
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){$('.car-container3').show()

results.map(items => lmsWrap.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></div>`)) //<div class="vl"></div>



}
sortfun();
   // This will log an array of items that match the search criteria
};



function sortfun() {
  debugger;
const selectElement = document.getElementById("mySelect");
    const selectedOptionValue = selectElement.value;
    console.log(selectedOptionValue);
    
  if (selectedOptionValue === "option1") {
  
  const inputValue = searchInput.value;
  var results = searchData(inputValue);
  console.log(results);
  document.getElementById('certificatcount1').innerHTML = 'Course List ( ' + results.length +' )' ;
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()
//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){
  
const viewElement = document.getElementById("viewselect");
    const selectedviewValue = viewElement.value;
    console.log(selectedviewValue);

  if (selectedviewValue === "option2") {
    
    $('.tableview').show();
    $('.career-wrap3').hide();
    $('#no-records-message').hide();
var tableData = results.map(value => {
  const starPercentage = (value.Rating / 5) * 100;
  const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;

  return (
    `<tr class="${value.ID}">
       <td>${value.ID}</td>
       <td>${value.Title}</td>
       <td>${value.Category}</td>
       <td>${value.Sections}</td>
       <td>${value.Author0}</td>
       <td title="${value.AboutAuthor}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3em;overflow: hidden;text-overflow: ellipsis;">${value.AboutAuthor}</td>
       <td>${value.NoofHits}</td>
       <td><div class="stars-outer">
          <div class="stars-inner" style="width: ${starPercentageRounded}"></div>
        </div></td>
    </tr>`
  );

  //document.querySelector(`.${value.ID} .stars-inner`).style.width = starPercentageRounded; 
}).join('');

const tableBody = document.querySelector("#tableBody");
tableBody.innerHTML = tableData;  
}
else{  
$('.car-container3').show()

results.map(items => lmsWrap.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></div>`)) //<div class="vl"></div>

}

}
   // This will log an array of items that match the search criteria



// Sort the data based on the sort direction and column
 if(results.length > 0){
 results.sort((a, b) => {
  if (a.Title < b.Title) {
    return -1;
  }
  if (a.Title > b.Title) {
    return 1;
  }
  return 0;
});
// Display the sorted data in your UI
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//results = results.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){
  
  
  const viewElement = document.getElementById("viewselect");
    const selectedviewValue = viewElement.value;
    console.log(selectedviewValue);
    
  if (selectedviewValue === "option2") {
    
    $('.tableview').show();
    $('.career-wrap3').hide();
    $('#no-records-message').hide();
var tableData = results.map(value => {
  const starPercentage = (value.Rating / 5) * 100;
  const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;

  return (
    `<tr class="${value.ID}">
       <td>${value.ID}</td>
       <td>${value.Title}</td>
       <td>${value.Category}</td>
       <td>${value.Sections}</td>
       <td>${value.Author0}</td>
       <td title="${value.AboutAuthor}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3em;overflow: hidden;text-overflow: ellipsis;">${value.AboutAuthor}</td>
       <td>${value.NoofHits}</td>
       <td><div class="stars-outer">
          <div class="stars-inner" style="width: ${starPercentageRounded}"></div>
        </div></td>
    </tr>`
  );

  //document.querySelector(`.${value.ID} .stars-inner`).style.width = starPercentageRounded; 
}).join('');

const tableBody = document.querySelector("#tableBody");
tableBody.innerHTML = tableData;  
}
  
  else{
  $('.car-container3').show()

results.map(items => lmsWrap.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></div>`)) //<div class="vl"></div>
}
}
 }
 else{
    lmsData.sort((a, b) => {
  if (a.Title < b.Title) {
    return -1;
  }
  if (a.Title > b.Title) {
    return 1;
  }
  return 0;
});

// Display the sorted data in your UI
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(lmsData.length > 0){$('.career-wrap3').show();$('#no-records-message').hide();

lmsData.map(items => lmsWrap.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></div>`)) //<div class="vl"></div>
}
 }
 
 //end of sort asc
  } 
  
  else {
    
    
     debugger;
  // Sort the data based on the sort direction and column




const inputValue = searchInput.value;
  var results = searchData(inputValue);
  document.getElementById('certificatcount1').innerHTML = 'Course List ( ' + results.length +' )' ;

   console.log("searchData",searchData.length);
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){$('.career-wrap3').show();$('#no-records-message').hide();

results.map(items => lmsWrap.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></div>`)) //<div class="vl"></div>



}

 if(results.length > 0){
   results.sort((a, b) => {
  if (a.Title < b.Title) {
    return 1;
  }
  if (a.Title > b.Title) {
    return -1;
  }
  return 0;
});
// Display the sorted data in your UI
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//results = results.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){
  
  const viewElement = document.getElementById("viewselect");
    const selectedviewValue = viewElement.value;
    console.log(selectedviewValue);
    
  if (selectedviewValue === "option2") {
    
    $('.tableview').show();
    $('.career-wrap3').hide();
    $('#no-records-message').hide();
var tableData = results.map(value => {
  const starPercentage = (value.Rating / 5) * 100;
  const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;

  return (
    `<tr class="${value.ID}">
       <td>${value.ID}</td>
       <td>${value.Title}</td>
       <td>${value.Category}</td>
       <td>${value.Sections}</td>
       <td>${value.Author0}</td>
       <td title="${value.AboutAuthor}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3em;overflow: hidden;text-overflow: ellipsis;">${value.AboutAuthor}</td>
       <td>${value.NoofHits}</td>
       <td><div class="stars-outer">
          <div class="stars-inner" style="width: ${starPercentageRounded}"></div>
        </div></td>
    </tr>`
  );

  //document.querySelector(`.${value.ID} .stars-inner`).style.width = starPercentageRounded; 
}).join('');

const tableBody = document.querySelector("#tableBody");
document.getElementById('certificatcount1').innerHTML = 'Course List ( ' + results.length +' )' ;
console.log("tableBody",results.length)
tableBody.innerHTML = tableData;  
}
  
  else{$('.career-wrap3').show();$('#no-records-message').hide();

results.map(items => lmsWrap.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></div>`)) //<div class="vl"></div>
}}
 }
 else{
    lmsData.sort((a, b) => {
  if (a.Title < b.Title) {
    return 1;
  }
  if (a.Title > b.Title) {
    return -1;
  }
  return 0;
});

// Display the sorted data in your UI
  let lmsWrap = $('.career-wrap3');

lmsWrap.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(lmsData.length > 0){$('.car-container3').show();$('#no-records-message').hide();

lmsData.map(items => lmsWrap.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section :   ${items.Sections}</p></div>`)) //<div class="vl"></div>
}
 }
  }
  
  
  if(results.length == 0){
   $('.tableview').hide();
    $('.career-wrap3').hide();
    $('#no-records-message').show();
 }
  
  
  }

///Add to list


function addRecordToList(course,category,section,navigateURL,authorname,aboutauthor){
  debugger;

var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
var listName = 'LMS Learner';
// Endpoint URL
var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/items";
var storevalue =[];
$.ajax({
    url: url,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
      storevalue = data.d.results;
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
storevalue = storevalue.filter(item => item.Course ===course &&item.Category ===category && item.EmployeeEmail.toLocaleLowerCase() ===loggedUserMail.toLocaleLowerCase())
if(storevalue.length == 0){
var Section = section; 
var numSections = parseInt(Section, 10);
var itemTitles = [];
for (var i = 1; i <= numSections; i++) {
  itemTitles.push("Topic " + i);
}
function createItem(title) {
var hyperlinkValuenav = {
    "__metadata": { "type": "SP.FieldUrlValue" },
    "Url": navigateURL,
    "Description": "nav link"
  };

  // Request payload for each item
  var payload = {
    '__metadata': { 'type': 'SP.Data.LMS_x0020_LearnerListItem' }, 
    'Title': userName,
    'Category': category,
    'Section': title,
    'Course' : course,
    'EmployeeEmail' :loggedUserMail,
    'AuthorName':authorname,
    'AboutAuthor':aboutauthor,
    'NavigateURL':hyperlinkValuenav,
    'CourseStatus' : 'InProgress'
  };

// Refresh the Request Digest value
$.ajax({
  url: siteUrl + "/_api/contextinfo",
  method: "POST",
  headers: { "Accept": "application/json;odata=verbose" },
  success: function(data) {
    var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

    // Make the AJAX POST request with the refreshed Request Digest value
    $.ajax({
      url: url,
      type: "POST",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": requestDigest
      },
      data: JSON.stringify(payload),
      success: function(data) {
        console.log("Item created successfully.");
        // Handle success
      },
      error: function(error) {
        console.log("Error creating item: " + JSON.stringify(error));
        // Handle error
      }
    });
  },
  error: function(error) {
    console.log("Error refreshing Request Digest: " + JSON.stringify(error));
    // Handle error
  }
});
}


// Create items in a loop
for (var i = 0; i < itemTitles.length; i++) {
  createItem(itemTitles[i]);
}
}
}

//add to fav8 
function addRecordTofavt(course,category,section,navigateURL,imgurl,secover,author,authorinfo){
  debugger;
  // SharePoint site URL
var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';

// SharePoint list name
var listName = 'LMS favorite';

// Endpoint URL
var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/items";

// Input section value
var Section = section; // Change this value to your actual section input

// Extract the number of sections from the input
var numSections = parseInt(Section, 10);

// Array to store item titles
var itemTitles = [];
if(category==="null"){
  category=""
}

var hyperlinkValueimg = {
    "__metadata": { "type": "SP.FieldUrlValue" },
    "Url": imgurl,
    "Description": "img link"
  };
  var hyperlinkValuenav = {
    "__metadata": { "type": "SP.FieldUrlValue" },
    "Url": navigateURL,
    "Description": "nav link"
  };
// Request paydata for each item
  var paydata = {
    '__metadata': { 'type': 'SP.Data.LMS_x0020_favoriteListItem' }, // Use the correct entity type name
    'Title': userName,
    'Category': category,
    'Section': section,
    'Course' : course,
    'EmployeeEmail' :loggedUserMail,
    'ImageURL' :hyperlinkValueimg,
    'Author0': author,
    'AboutAuthor':authorinfo,
    'NavigateURL':hyperlinkValuenav,
    'SectionOverview': secover ,
    'CourseStatus' : 'Yes'
  };

// Refresh the Request Digest value
$.ajax({
  url: siteUrl + "/_api/contextinfo",
  method: "POST",
  headers: { "Accept": "application/json;odata=verbose" },
  success: function(data) {
    var requestDigest = data.d.GetContextWebInformation.FormDigestValue;

    // Make the AJAX POST request with the refreshed Request Digest value
    $.ajax({
      url: url,
      type: "POST",
      headers: {
        "Accept": "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose",
        "X-RequestDigest": requestDigest
      },
      data: JSON.stringify(paydata),
      success: function(data) {
        console.log("Item created successfully.");
        lmsData = [];
        results=[];
        favtdata =[];
        lmsfunc();
        appendlms();
      },
      error: function(error) {
        console.log("Error creating item: " + JSON.stringify(error));
        // Handle error
      }
    });
  },
  error: function(error) {
    console.log("Error refreshing Request Digest: " + JSON.stringify(error));
    // Handle error
  }
});
}


//
if($('#searchInput').value >0){
     $('.clear-search').show()  
  }
  else{
      $('.clear-search').hide()  
       document.getElementById('certificatcount1').innerHTML = 'Course List ( ' + results.length +' )' ;
  }



