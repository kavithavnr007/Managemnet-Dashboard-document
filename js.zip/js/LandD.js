var lmsPath1 = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Course List')/items?&$top=5000"
var favtPath1 = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS favorite')/items?&$top=5000"

var lmsData1 = [];
var results=[];
var favtdata1 =[];
var loggedUserPath1 = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + _spPageContextInfo.userId + ")";
var loggedUserMail1,myEmail,userName1 =[];

function lmsfunc1() {
$.ajax({
    url: loggedUserPath1,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        loggedUserMail1 = data.d.Email;
        userName1 = data.d.Title;
        console.log("Logged-in user: " + userName1);
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});

$.ajax({
    url: favtPath1,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        favtdata1 = data.d.results;
        console.log("favt list1: " + favtdata1);
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    } 
});

$.ajax({

url:lmsPath1,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

lmsData1 = [...lmsData1,...data.d.results]

lmsData1 = lmsData1.filter(item => item.CourseList === "Rencata Course List")

/*lmsData2 = lmsData1.filter(item => item.CourseList === "Course List")
Error = function (data) {
lmsData1 = lmsData1.filter(item => applcation === "An error occured. please try again.")
}*/
if (data.d.__next) {

lmsPath1 = data.d.__next;

lmsfunc1();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}

function solutionlms(){
 
let lmsWrap1 = $('.career-wrap5');
var inputBox1 = document.getElementById("searchInput1");
  inputBox1.value="";
   $('.norecrdrencata').hide();


   $('.clear-search1').hide();
   $('.tableview1').hide();


   const selectElement1 = document.getElementById("mySelect1");
   selectElement1.selectedIndex = 0;
lmsWrap1.empty();

// Sort the data based on the sort direction and column
lmsData1.sort((a, b) => {
  if (a.Title < b.Title) {
  return -1;
  }
  if (a.Title > b.Title) {
    return 1;
  }
  return 0;
});

//lmsdata1 = lmsData.filter(list => list.field_Status.toLowerCase()=="open"|| list.field_Status.toLowercase() == "reopen");

//table view
const viewElement1 = document.getElementById("viewselect1");
   const selectedviewValue1 = viewElement1.value;
   console.log(selectedviewValue1);

  if (selectedviewValue1 === "option2") {

  $('.tableview1').show();

  //$('.car-container3').hide();
 // $('.career-wrap5').hide();
var tableData1 = lmsData1.map(value => {
  const starPercentage = (value.Rating / 5) * 100;
  const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;
  return (
    `<tr class="${value.ID}">
      <td>${value.ID}</td>
      <td>${value.Title}</td>
      <td>${value.Category}</td>
      <td>${value.Sections}</td>
      <td>${value.Author0}</td>
      <td title="${value.AboutAuthor}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3em;overflow: hidden;text-overflow: ellipsis;">${value.AboutAuthor}</td>
      <td>${value.NoofHits}</td>
      <td><div class="stars-outer">
      <div class="stars-inner" style="width: ${starPercentageRounded}"></div>
      </div></td>
    </tr>`
  );

   
//document.querySelector(`.${value.ID} .stars-inner`).style.width = starPercentageRounded;
}).join('');

const tableBody1 = document.querySelector("#tableBody1");


tableBody1.innerHTML = tableData1;
}
//grid view

else{
   $('.norecrdrencata').hide();
   if(lmsData1.length > 0){
   $('.career-wrap5').empty();
   $('.career-wrap5').show();
   $('.car-container3').show();
for (k=0; k<lmsData1.length; k++){

//lmsData.map(items => //list.Course.toLowerCase() === lmsData[k].Title && list.Course.toLowerCase() === lmsData[k].Title.toLowerCase() &&

lmsWrap1.append(`<div class="post" onclick=""><img src="${ lmsData1[k].ImageURL ? (lmsData1[k].ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/>
${ (favtdata1.filter(list => list.EmployeeEmail === loggedUserMail1 && list.Course === lmsData1[k].Title && list.Category === lmsData1[k].Category && list.Section === lmsData1[k].Sections)).length >0 ? `<img title="Your favorite" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/favorite.png" style="border:none;border-radius:0%;width: 20px;height: 20px;margin-left: 240px;float: right;position: absolute;">` :

`<img title="Add to favorite" onclick="addRecordTofavt1('${lmsData1[k].Title.replace(/'/g, "\\'")}','${lmsData1[k].Category.replace(/'/g, "\\'")}','${lmsData1[k].Sections.replace(/'/g, "\\'")}', '${lmsData1[k].NavigateURL.Url.replace(/'/g, "\\'")}', '${lmsData1[k].ImageURL.Url.replace(/'/g, "\\'")}' , '${lmsData1[k].SectionOverview.replace(/'/g, "\\'")}','${lmsData1[k].Author0.replace(/'/g, "\\'")}','${lmsData1[k].AboutAuthor.replace(/'/g, "\\'")}')" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Addtofav8.jpg" style="border:none;border-radius:0%;width: 25px;height: 25px;margin-left: 240px;float: right;position: absolute;">`}

<a title="Start Course" target="_blank" data-interception="off" href="${lmsData1[k].NavigateURL ? lmsData1[k].NavigateURL.Url : `https://www.udemy.com/course/azure100/learn/lecture/33163158?start=270`}">
<img title="Start Course" onclick="addRecordToList1('${lmsData1[k].Title}','${lmsData1[k].Category.replace(/'/g, "\\'")}','${lmsData1[k].Sections.replace(/'/g, "\\'")}','${lmsData1[k].NavigateURL.Url}','${lmsData1[k].Author0.replace(/'/g, "\\'")}','${lmsData1[k].AboutAuthor.replace(/'/g, "\\'")}')" align="right" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/play.png" style="border:none;border-radius:0%;width: 20px;height: 45px;padding-bottom: 20px;float: right;margin-top: 50px;"></a><p style="font-size: 120%; color:#3d8084;">${lmsData1[k].Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section : ${lmsData1[k].Sections}</p></div>`)
//) //<div class="vl"></div>

document.getElementById('certificatcount').innerHTML = 'Rencata Course List ( ' + lmsData1.length +' )' ;

}

}}

}
  
// Assuming 'sharepointData' is the array of SharePoint data

   function searchData1(inputValue1) {
    //  debugger;
    const searchResults1 = lmsData1.filter(item => {

    // Replace 'columnName' with the actual name of the column you want to search
      return item.Title.toLowerCase().includes(inputValue1.toLowerCase());
    });
    return searchResults1;

    
  }

// Get a reference to the input element
const searchInput1 = document.getElementById("searchInput1");

// Add the onchange event handler to the input element
searchInput1.onchange = function() {

  const inputValue1 = searchInput1.value;
  if(inputValue1.length > 0){
     $('.clear-search1').show()
  }
  else{
  $('.clear-search1').hide()
};

var results = searchData1(inputValue1);


let lmsWrap1 = $('.career-wrap5');

lmsWrap1.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){$('.car-container3').show()

results.map(items => lmsWrap1.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section : ${items.Sections}</p></div>`)) //<div class="vl"></div>

}


solvefun();
   // This will log an array of items that match the search crite
};


function solvefun() {
  // debugger;
const selectElement1 = document.getElementById("mySelect1");
    const selectedOptionValue1 = selectElement1.value;

  if (selectedOptionValue1 === "option1")  {

  const inputValue1 = searchInput1.value;
  var results = searchData1(inputValue1);
  document.getElementById('certificatcount').innerHTML = 'Rencata Course List ( ' + results.length +' )' ;


  var resultLength = results.length;
  if(resultLength != 0){
  $('.norecrdrencata').hide();
  $('.career-wrap5').show();
  $('.tableview1').hide();
  }
else{
  
  $('.norecrdrencata').show();
  $('.career-wrap5').hide();
  $('.tableview1').hide();
}

let lmsWrap1 = $('.career-wrap5');
lmsWrap1.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")


if(results.length > 0){
  
  const viewElement1 = document.getElementById("viewselect1");
   const selectedviewValue1 = viewElement1.value;


  if (selectedviewValue1 === "option2") {
  $('.tableview1').show();
  //$('.car-container3').hide();
  $('.career-wrap5').hide();
var tableData1 =results.map(value => {
  const starPercentage = (value.Rating / 5) * 100;
  const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;

  return (
    `<tr class="${value.ID}">
      <td>${value.ID}</td>
      <td>${value.Title}</td>
      <td>${value.Category}</td>
      <td>${value.Sections}</td>
      <td>${value.Author0}</td>
      <td title="${value.AboutAuthor}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3em;overflow: hidden;text-overflow: ellipsis;">${value.AboutAuthor}</td>
      <td>${value.NoofHits}</td>
      <td><div class="stars-outer">
      <div class="stars-inner" style="width: ${starPercentageRounded}"></div>
      </div></td>
    </tr>`
  );

//document.querySelector(`.${value.ID} .stars-inner`).style.width = starPercentageRounded;
}).join('');

const tableBody1 = document.querySelector("#tableBody1");
tableBody1.innerHTML = tableData1;
}
  
else{  
  
  $('.car-container3').show()

results.map(items => lmsWrap1.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section : ${items.Sections}</p></div>`)) //<div class="vl"></div>

}

}

// This will log an array of items that match the search criteria

// Sort the data based on the sort direction and column

if(results.length > 0){
results.sort((a, b) => {
  if (a.Title < b.Title) {
     return -1;
  }
  if (a.Title > b.Title) {
  return 1;
  }
return 0;
});

// Display the sorted data in your UI
let lmsWrap1 = $('.career-wrap5'); 

lmsWrap1.empty()

//results = results.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){
  
  const viewElement1 = document.getElementById("viewselect1");
   const selectedviewValue1 = viewElement1.value;
   

  if (selectedviewValue1 === "option2") {

  $('.tableview1').show();
  //$('.car-container3').hide();
  $('.career-wrap5').hide();
var tableData1 =results.map(value => {
  const starPercentage = (value.Rating / 5) * 100;
  const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;

  return (
    `<tr class="${value.ID}">
      <td>${value.ID}</td>
      <td>${value.Title}</td>
      <td>${value.Category}</td>
      <td>${value.Sections}</td>
      <td>${value.Author0}</td>
      <td title="${value.AboutAuthor}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3em;overflow: hidden;text-overflow: ellipsis;">${value.AboutAuthor}</td>
      <td>${value.NoofHits}</td>
      <td><div class="stars-outer">
      <div class="stars-inner" style="width: ${starPercentageRounded}"></div>
      </div></td>
    </tr>`
  );

//document.querySelector(`.${value.ID} .stars-inner`).style.width = starPercentageRounded;
}).join('');

const tableBody1 = document.querySelector("#tableBody1");
tableBody1.innerHTML = tableData1;
}
  
else{  
  
  $('.car-container3').show()

results.map(items => lmsWrap1.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section : ${items.Sections}</p></div>`)) //<div class="vl"></div>
}
 }
}
else{
   lmsData1.sort((a, b) => {
  if (a.Title < b.Title) {
    return -1;
  }
  if (a.Title > b.Title) {
    return 1;
  }
  return 0;
});

// Display the sorted data in your UI
let lmsWrap1 = $('.career-wrap5');

lmsWrap1.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")
if(lmsData1.length > 0){$('.car-container3').show()
lmsData1.map(items => lmsWrap1.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section : ${items.Sections}</p></div>`)) //<div class="vl"></div>
}
 }

//end of sort asc

} 

else {


// Sort the data based on the sort direction and column



const inputvalue1 = searchInput1.value;
  var results = searchData1(inputvalue1);
  document.getElementById('certificatcount').innerHTML = 'Rencata Course List ( ' + results.length +' )' ;
  console.log("searchData1",searchData1.length);
  let lmsWrap1 = $('.career-wrap5');
 
lmsWrap1.empty()

         

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){$('.car-container3').show()

results.map(items => lmsWrap1.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section : ${items.Sections}</p></div>`)) //<div class="vl"></div>

 
}

if(results.length > 0){
  results.sort((a, b) => {
 if (a.Title < b.Title) {
   return 1;
  }
  if (a.Title> b.Title) {
   return -1;
  }
  return 0;
});


// Display the sorted data in your UI

let lmsWrap1 = $('.career-wrap5');
lmsWrap1.empty()

//results = results.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(results.length > 0){

const viewElement1 = document.getElementById("viewselect1");
   const selectedviewValue1 = viewElement1.value;
   console.log(selectedviewValue1);

  if (selectedviewValue1 === "option2") {

  $('.tableview1').show();
  //$('.car-container3').hide();
  $('.career-wrap5').hide();
var tableData1 =results.map(value => {
  const starPercentage = (value.Rating / 5) * 100;
  const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;

  return (
    `<tr class="${value.ID}">
      <td>${value.ID}</td>
      <td>${value.Title}</td>
      <td>${value.Category}</td>
      <td>${value.Sections}</td>
      <td>${value.Author0}</td>
      <td title="${value.AboutAuthor}" style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;max-height: 3em;overflow: hidden;text-overflow: ellipsis;">${value.AboutAuthor}</td>
      <td>${value.NoofHits}</td>
      <td><div class="stars-outer">
      <div class="stars-inner" style="width: ${starPercentageRounded}"></div>
      </div></td>
    </tr>`
  );

//document.querySelector(`.${value.ID} .stars-inner`).style.width = starPercentageRounded;
}).join('');

const tableBody1 = document.querySelector("#tableBody1");
document.getElementById('certificatcount').innerHTML = 'Rencata Course List ( ' + results.length +' )' ;
console.log("tableBody1",results.length)
tableBody1.innerHTML = tableData1;
}
  
else{  

  $('.career-wrap5').show()

results.map(items => lmsWrap1.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section : ${items.Sections}</p></div>`)) //<div class="vl"></div>

}}
}
else{
   lmsData1.sort((a, b) => {
  if (a.Title < b.Title) {
    return 1;
  }
  if (a.Title > b.Title) {
    return -1;
}
return 0;
});

// Display the sorted data in your UI
  let lmsWrap1 = $('.career-wrap5');

lmsWrap1.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

if(lmsData1.length > 0){$('.car-container3').show();

lmsData1.map(items => lmsWrap1.append(`<div class="post" onclick=""><img src="${ items.ImageURL ? (items.ImageURL.Url) : `https://img-c.udemycdn.com/course/240x135/1857178_344e_2.jpg`}" style="border:none;border-radius:0%; width:80px; height:90px; position: absolute;"/><p style="font-size: 120%; color:#3d8084;">${items.Title.replace(/<[^>]*>?/gm, '')}</p>
<P> Section : ${items.Sections}</p></div>`)) //<div class="vl"></div>
}
 }
  }

if(results.length == 0){
   $('.tableview1').hide();
    $('.career-wrap5').hide();
    $('.norecrdrencata').show();
    
}
}

///Add to list


function addRecordToList1(course,category,section,navigateURL,authorname,aboutauthor){
   debugger;


var siteUrl1 = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
var listName1 = 'LMS Course List';

// Endpoint URL
var url = siteUrl1 + "/_api/web/lists/getByTitle('" + listName1 + "')/items";
var storevalue1 =[];
$.ajax({
    url: url,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
      storevalue1 = data.d.results;
    },
    error: function (data) {
       console.log("An error occurred. Please try again.");
    }
});
storevalue1 = storevalue1.filter(item => item.Title ===title &&item.Category ===category && item.EmployeeEmail.toLocaleLowerCase() ===loggedUserMail1.toLocaleLowerCase())
if(storevalue1.length == 0){
var Section = section;
var numSections1 = parseInt(Section, 10);
var itemTitles1 = [];
for (var i = 1; i <= numSections1; i++) {
itemTitles1.push("Topic " + i);
}
function createItem(title) {
var hyperlinkValuenav1 = {
"__metadata": { "type": "SP.FieldUrlValue" },
"Url": navigateURL,
"Description": "nav link"
};

// Request payload for each item
var payload1 = {
'__metadata': { 'type': 'SP.Data.LMS_x0020_LearnerListItem' },
'Title': title,
'Section': section,
'Course' : course,
'EmployeeEmail' :loggedUserMail1,
'AuthorName':authorname,
'AboutAuthor':aboutauthor,
'NavigateURL':hyperlinkValuenav,
'CourseStatus' : 'InProgress'
};

// Refresh the Request Digest value
$.ajax({
  url: siteUrl1 + "/_api/contextinfo",
  method: "POST",
  headers: { "Accept": "application/json;odata=verbose" },
  success: function(data) {
   var requestDigest1 = data.d.GetContextWebInformation.FormDigestValue;

   // Make the AJAX POST request with the refreshed Request Digest value
    $.ajax({
      url: url,
      type: "POST",
      headers: {
"Accept": "application/json;odata=verbose",
"Content-Type": "application/json;odata=verbose",
"X-RequestDigest": requestDigest1
},
data: JSON.stringify(payload),
success: function(data) {
console.log("Item created successfully.");

// Handle success
},
error: function(error) {
console.log("Error creating item: " + JSON.stringify(error));

// Handle error
}
});
},
error: function(error) {
console.log("Error refreshing Request Digest: " + JSON.stringify(error));

// Handle error
}
});
}

// Create items in a loop

for (var i = 0; i < itemTitles1.length; i++) {
createItem(itemTitles1[i]);
}
}
}

//add to fav8
function addRecordTofavt1(course,category,section,navigateURL,imgurl,secover,author,authorinfo){
debugger;

// SharePoint site URL
var siteUrl1 = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';

// SharePoint list name
var listName1 = 'LMS favorite';

// Endpoint URL
var url = siteUrl1 + "/_api/web/lists/getByTitle('" + listName1 + "')/items";

// Input section value
var Section = section; // Change this value to your actual section input

// Extract the number of sections from the input
var numSections1 = parseInt(Section, 10);

// Array to store item titles
var itemTitles1 = [];
if(category==="null"){
category=""
}

var hyperlinkValueimg1 = {

"__metadata": { "type": "SP.FieldUrlValue" },

"Url": imgurl,

"Description": "img link"

};

var hyperlinkValuenav1 = {

"__metadata": { "type": "SP.FieldUrlValue" },

"Url": navigateURL,

"Description": "nav link"

};

// Request paydata for each item

var paydata1 = {

'__metadata': { 'type': 'SP.Data.LMS_x0020_favoriteListItem' }, // Use the correct entity type name
'Title': userName1,
'Category': category,
'Section': section,
'Course' : course,
'EmployeeEmail' :loggedUserMail1,
'ImageURL' :hyperlinkValueimg1,
'Author0': author,
'AboutAuthor':authorinfo,
'NavigateURL':hyperlinkValuenav1,
'SectionOverview': secover ,
'CourseStatus' : 'Yes'

};

// Refresh the Request Digest value

$.ajax({

url: siteUrl1 + "/_api/contextinfo",

method: "POST",

headers: { "Accept": "application/json;odata=verbose" },

success: function(data) {

var requestDigest1 = data.d.GetContextWebInformation.FormDigestValue;

// Make the AJAX POST request with the refreshed Request Digest value

$.ajax({

url: url,

type: "POST",

headers: {

"Accept": "application/json;odata=verbose",

"Content-Type": "application/json;odata=verbose",

"X-RequestDigest": requestDigest1

},
        data: JSON.stringify(paydata1),
        success: function(data) {
         console.log("Item created successfully.");
         lmsData1 = [];
         results=[];
         favtdata1 =[];
         lmsfunc1();
         solutionlms();
      },
      error: function(error) {
        console.log("Error creating item: " + JSON.stringify(error));
// Handle error
      }
    });
},
  error: function(error) {
    console.log("Error refreshing Request Digest: " + JSON.stringify(error));

// Handle error
  }
});
}


//console.log("Error refreshing Request Digest: " + Json.stringify(error));
if($('#searchInput1').value >0){
$('.clear-search1').show()
 
}
else{
$('.clear-search1').hide()
  document.getElementById('certificatcount').innerHTML = 'Rencata Course List ( ' + results.length +' )' ;
}

  