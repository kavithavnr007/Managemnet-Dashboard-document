 var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Topic Evaluation User Badge')/items"
 var studentData =[];
var tableRows =[];
const timeValues = [];
 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }

 function studentdup(){
 var stdwrap = $('.cevaluation');
 stdwrap.empty();
// Object to store employee entry counts
var entryCounts01 = {};
var timeSums = {}; // Object to store total time sums for each entry
console.log("entryCounts01" , entryCounts01);
// Counting employee entries
for (var i = 0; i < studentData.length; i++) {
  var course = studentData[i].Category1;
  var category = studentData[i].Category;
  var section = studentData[i].Section;
  var timeTaken = studentData[i].TOTALTime; // Replace this with the actual time field



  // Creating a unique key combining employeeId and department
  var key = course + "|" + category + "|" + section;

  if (!entryCounts01.hasOwnProperty(key)) {
    entryCounts01[key] = 1;
    timeValues.push(timeTaken);
    timeSums[key] = timeTaken; // Initialize time sum with current time

  } else {
    entryCounts01[key]++;
    //timeSums[key] += timeTaken; // Add time to the existing sum
//Start Test Data

// Sample time values in HH:MM:SS format
timeValues.push(timeTaken);
//const timeValues = ["01:30:45", "02:15:30", "00:45:15"];

// Function to convert time values to seconds
function timeToSeconds(time) {
  const parts = time.split(':');
  const hours = parseInt(parts[0], 10);
  const minutes = parseInt(parts[1], 10);
  const seconds = parseInt(parts[2], 10);
  return hours * 3600 + minutes * 60 + seconds;
}

// Sum the time values in seconds
const totalSeconds = timeValues.reduce((total, time) => {
  return total + timeToSeconds(time);
}, 0);

// Convert the totalSeconds back to HH:MM:SS format
function secondsToTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Display the total time
const totalTime = secondsToTime(totalSeconds);
console.log(`Total Time: ${totalTime}`);

  //End Data
  }
}
debugger;
for (var key in entryCounts01) {
  var parts = key.split("|");
  var course= parts[0];
  var category = parts[1];
  var section = parts[2];
  var count = entryCounts01[key];
  var totalTime = timeSums[key];
  var averageTime = totalTime / count; 
  // Calculate average time

  // Create the HTML table row and push it to the array 
  



var payload = {

'course':course,

'category':category,

'section':section,
'count' : count

};



   tableRows.push(payload);
  stdwrap.append(`<tr><td>${category}</td>
                         <td>${course}</td>
                          <td>${section}</td>
                          <td>${ totalTime}</td>
                           <td><button style="background:transparent;border:none;" onclick="EmployeeDetailshowbelow('${category}','${course}','${section}')" background: transparent;
    border: none;> ${count}</button></td></tr>`
   )
  
  //coursePAGE.push( key )
  
  }
 }
 //console.log("stdwrap" + stdwrap  );

//function showstdet(){
  //debugger;
//var stdwrap = $('.cevaluation'); //document.getElementByClass('student')
//stdwrap.empty();
//for(i=0;i<studentData.length; i++){
  // stdwrap.append(`<tr><td>${studentData[i].Category}</td>
    //                     <td>${studentData[i].Course}</td>
    //                    <td>${studentData[i].Section}</td>
   //                       <td>${studentData[i].Title}</td></tr>`
   //) 
//}
//}
function Couresecountdet(){
    //Object to store employee entry counts
    var EmployeeCount={};

    //Counting  employee entries
    for (var i = 0; i < studentData.length; i++) {
  var course= studentData[i].Category1;
  var category =studentData[i].Category;
  var section = studentData[i].Section;

  //Creating a unique key combining

  var EmployeeCOUNTKEY= course + "-" +  category + "-" + section;

   if (!EmployeeCount.hasOwnProperty(EmployeeCOUNTKEY)) {

    EmployeeCount[EmployeeCOUNTKEY] = 1;
   }else{
       EmployeeCount[EmployeeCOUNTKEY]++;
   }
}

}

function EmployeeDetailshowbelow(category,course,section)
{
  debugger

var lsrdata =[];

lsrdata = studentData.filter(list => list.Category.toLocaleLowerCase() ===category.toLocaleLowerCase() && list.Category1.toLocaleLowerCase() ===course.toLocaleLowerCase() && list.Section.toLocaleLowerCase() ===section.toLocaleLowerCase() )
var lsrdata1 = $('.cevaluation01');
lsrdata1.empty();
console.log("lsrdata: " + lsrdata); 
for(i=0;i<lsrdata.length; i++){
   lsrdata1.append(`<tr><td>${lsrdata[i].UserName}</td>
                         <td>${lsrdata[i].Category1}</td>
                         <td>${lsrdata[i].Section}</td>
                         <td>${lsrdata[i].Created}</td>
                         <td>${lsrdata[i].Score}</td>
                         <td>${lsrdata[i].TOTALTime}</td>
                         <td>None</td>
                         <td>None</td></tr>`
   )  
}

  
}

// Assuming 'sharepointData' is the array of SharePoint data

function searchData(inputValue) {

    debugger;

  const searchResults = tableRows.filter(item => {

    // Replace 'columnName' with the actual name of the column you want to search

    return item.category.toLowerCase().includes(inputValue.toLowerCase());

  });

  return searchResults;

}



// Add the onchange event handler to the input element

 function searchfun() {
debugger;

const searchInput = document.getElementById("Searchresultsum");
  const inputValue = searchInput.value;

  if(inputValue.length >0){

     $('.clear-search').show()  

  }

  else{

      $('.clear-search').hide()  

  };

  var results = searchData(inputValue);

  console.log(results);

var stdwrap = $('.cevaluation');
 stdwrap.empty();


if(results.length > 0){
  stdwrap.show()

results.map(items => stdwrap.append(`<tr><td>${items.category}</td>
                         <td>${items.course}</td>
                          <td>${items.section}</td>
                           <td><button style="background:transparent;border:none;" onclick="EmployeeDetailshowbelow('${items.category}','${items.course}','${items.section}')" background: transparent;
    border: none;> ${items.count}</button></td></tr>`)) //<div class="vl"></div>
}
};
