
var BdayPath = "https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items?&$filter=(Active eq 1)"

var empDobDoj = [];


function Bday() {

$.ajax({

url:BdayPath,

headers: {
Accept: "application/json;odata=verbose"
},

async: false,

success: function (data) {

empDobDoj = [...empDobDoj,...data.d.results]

if (data.d.__next) {

BdayPath = data.d.__next;

Bday();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}

Bday();

function activeSlide(div){
  
$(`${div}`).flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 100,
        itemMargin: 6,
        pausePlay: false,
        controlNav:false,
        start: function(slider){
          $('body').removeClass('loading');
        }
      }); 
}

function appendWorkup(){
let WorkWrap = $('.workslider');
WorkWrap.empty()
var Todate = new Date();
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
let WorkData = empDobDoj.filter(list =>  (new Date(list.field_DOJ).getDate() >= Todate.getDate()&& new Date(list.field_DOJ).getMonth() == Todate.getMonth()&& new Date(list.field_DOJ).getFullYear() < Todate.getFullYear() ))
WorkData = WorkData.sort(function(a,b){
return new Date(b.field_DOJ).getDate() - new Date(a.field_DOJ).getDate();
}).reverse();
if(WorkData.length > 0){$('.workslider').show()
WorkData.map(items => WorkWrap.append(`<a href="mailto:${items.Email}?subject=Happy Work Anniversary!"><div class="post" style="" > <p data-toggle="tooltip" title= "${items.field_Employee_x0020_Name}"><img style="border-radius: 50%;" vertical-align= "top" align="left" width="50" height="50" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: 14px;">${new Date(items.field_DOJ).getDate()}- ${months[new Date(items.field_DOJ).getMonth()]} </p></div> </div></div></a>`))
}
}


function appendWork(){
let WorkWrap1 = $('.workslider');

WorkWrap1.empty()

var Todate = new Date();
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

let WorkData1 = empDobDoj.filter(list =>  (new Date(list.field_DOJ).getDate() < Todate.getDate()&& new Date(list.field_DOJ).getMonth() == Todate.getMonth()&& new Date(list.field_DOJ).getFullYear() < Todate.getFullYear() ))

WorkData1 = WorkData1.sort(function(a,b){
return new Date(b.field_DOJ).getDate() - new Date(a.field_DOJ).getDate();
}).reverse();

if(WorkData1.length > 0){$('.workslider').show()

WorkData1.map(items => WorkWrap1.append(`<a href="mailto:${items.Email}?subject=Happy Work Anniversary!"><div class="post" style= "" > <p data-toggle="tooltip" title= "${items.field_Employee_x0020_Name}"><img style="border-radius: 50%;" vertical-align= "top" align="left" width="50" height="50" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: 14px;">${new Date(items.field_DOJ).getDate()}- ${months[new Date(items.field_DOJ).getMonth()]} </p></div> </div></div></a>`)

)

}

}



/***Bday Anniversary *****/

function appendBdayup(){

let BdayWrap = $('.wrapBday');

BdayWrap.empty()

var Todate = new Date();
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

let BdayData = empDobDoj.filter(list =>  (new Date(list.field_DOB).getDate() >= Todate.getDate()&& new Date(list.field_DOB).getMonth() == Todate.getMonth()&& new Date(list.field_DOB).getFullYear() < Todate.getFullYear() ))


BdayData = BdayData.sort(function(a,b){
return new Date(b.field_DOB).getDate() - new Date(a.field_DOB).getDate();
}).reverse();

if(BdayData.length > 0){$('.wrapBday').show()

BdayData.map(items => BdayWrap.append(`<a href="mailto:${items.Email}?subject=Happy Birthday!"><div class="post" style= "" > <p data-toggle="tooltip" title= "${items.field_Employee_x0020_Name}"><img style="border-radius: 50%;" vertical-align= "top" align="left" width="50" height="50" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: 14px;">${new Date(items.field_DOB).getDate()}- ${months[new Date(items.field_DOB).getMonth()]} </p></div> </div></div></a>`)

)

}

}

function appendBday(){

let BdayWrap1 = $('.wrapBday');

BdayWrap1.empty()

var Todate = new Date();
var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

let BdayData1 = empDobDoj.filter(list => (new Date(list.field_DOB).getDate() < Todate.getDate()&& new Date(list.field_DOB).getMonth() == Todate.getMonth()&& new Date(list.field_DOB).getFullYear() < Todate.getFullYear() ))


BdayData1 = BdayData1.sort(function(a,b){
return new Date(b.field_DOB).getDate() - new Date(a.field_DOB).getDate();
}).reverse();


if(BdayData1.length > 0){$('.wrapBday').show()

BdayData1.map(items => BdayWrap1.append(`<a href="mailto:${items.Email}?subject=Happy Birthday!"><div class="post" style= "" > <p data-toggle="tooltip" title= "${items.field_Employee_x0020_Name}"><img style="border-radius: 50%;" vertical-align= "top" align="left" width="50" height="50" src= "${items.Photo ? (items.Photo.Url) : `https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg`}" width="100%" height="100%" alt="Avatar"></p>
<P style="text-align:center; font-size: 14px;">${new Date(items.field_DOB).getDate()}- ${months[new Date(items.field_DOB).getMonth()]} </p></div> </div></div></a>`)
)

}
}





/*** Childrens day */


var cdayPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Childrens day Registration')/items"

var cdaydata = [];
var cdaydata1 = [];

function GetSortOrder(prop) {
    return function (a, b) {
        if (a[prop] > b[prop]) {
            return 1;
        } else if (a[prop] < b[prop]) {
            return -1;
        }
        return 0;
    }
};

$.ajax({

    url: cdayPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
    //Section1 pin collection
    cdaydata = data.d.results.filter(res => (res.Like != null));//.filter(res => (!res.Delete && res.Active &&res.Pin && res.Section == "Section 1"));
    cdaydata1 = data.d.results
    
    },

    eror: function (data) {
        console.log("An error occurred. Please try again.");
    }
});


function Getcday() {
    let cdaywrap = $('.stylewrap');
     let headset=$('.headTop');
     let mytip=$('.myDIV');
cdaywrap.empty();
    cdaydata =cdaydata.sort(GetSortOrder("Like"));
    cdaydata = cdaydata.reverse();
   cdaydata =cdaydata.slice(0, 5);
   if(cdaydata.length==0||cdaydata.length==1 || cdaydata.length==2 || cdaydata.length==3||cdaydata.length==4){
   
       headset.append(`<div> <h2 style="color=whight; position: absolute; font-size:25px;">Trending Stars</h2><div style="width: 30%;" class="myDIV"><img style="width: 30px; height: 30px;margin:25px 0px 0px 175px;;"src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranet/Style%20Library/icons/inf.jpg"></div>
<div class="hidecnt">${"Click on the like in the gallery to get your Trending Star appear here"}</div></div>`)
   }else{
      headset.append(`<div> <h2 style="color=whight;font-size:25px;">Trending Stars</h2></div>`)
   }
   if(cdaydata.length>0){
  
cdaydata.map(items => cdaywrap.append(` <div><a  href="https://apps.powerapps.com/play/e/default-7bf109b7-39a2-49d4-911d-09736db83214/a/580925a3-c07f-41d7-84dc-39ca074d34d4?tenantId=7bf109b7-39a2-49d4-911d-09736db83214&source=portal?ID=${items.ID}" target="_blank" data-interception="off"><div class="cday-title"><img style="width: 40px; height: 40px; position: absolute; margin: 0px 0px 0px 0px;"src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/5ed9f67bbca2fafbcd8640fa_hand_crap.gif"><h3 style="margin:0px 0px 5px 0px; padding: 0px 0px 0px 50px;">${items.ChildGender =="Boy" ? "Master " :"Miss "}${items.ChildName.replace(/<[^>]*>?/gm, '')}</h3><h4 style="margin:0px; padding: 0px 0px 0px 50px;"> ${items.ChildGender =="Boy" ? "Son of" :"Daughter of"} ${items.EmployeeName.replace(/<[^>]*>?/gm, '')}<h4> </div>
    <img title=${items.ChildName} style="border-radius: 0px 8px 0px 0px; margin: 0px 0px 0px 100px; cursor: pointer; width:60%; padding: 4px; height:252px;" src=${items.ChildPhoto ?  items.ChildPhoto.Url : `https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg`}></a></div>`)
)
   }



    };
function Getreg() {
    let ccontent = $('.stylecount');
    
let totalc= cdaydata1.length;
ccontent.append(` <div style="background:black; height: 370px; width:90%;"><img style="opacity: 0.6; height: 370px; width: 100%;" src="https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/MicrosoftTeams-image%20(21).png"><spam class="description" style="position: absolute; left:10%; margin:20px 0px 0px 100px; font-size: 20px; font-weight: 700; color: white;"> ${"Registrations till Date"}</spam><spam class="description" style="position: absolute; left:10%; margin:110px 0px 0px 170px; font-size: 120px; font-weight: 700; color: white;"> ${totalc}</spam></div>`)}
/*<div class="modal fade" id="myModalWithIframeLMS" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">cdetails(${items.ID})
													<div class="modal-dialog" Style="width:1250px" >
														<div class="modal-content">
															<div class="modal-header">
																<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																<h4 class="modal-title" id="myModalLabel">Learning Man</h4>
															</div>
															<div class="modal-body">
																<iframe src="https://apps.powerapps.com/play/3c0eff5f-75a2-418d-b082-58e54022cc60?tenantId=7bf109b7-39a2-49d4-911d-09736db83214 " width="100%" height="800" frameborder="0" allowtransparency="true">
																</iframe>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
															</div>
														</div>
														<!-- /.modal-content -->
													</div>
													<!-- /.modal-dialog -->
												</div>
                                                
                                                
                                                <video width="100%" height="360" controls>
  <source src="${data[0].AttachmentFiles.__deferred.uri}" type="video/mp4">${data[0].AttachmentURL}
</video>*/

function cdetails(id){
/*let data = cdaydata.filter(items => items.ID == id);
 `<a href="https://apps.powerapps.com/play/e/default-7bf109b7-39a2-49d4-911d-09736db83214/a/580925a3-c07f-41d7-84dc-39ca074d34d4?tenantId=7bf109b7-39a2-49d4-911d-09736db83214&source=portal?ID=${data[0].ID}" target="_blank">
    </a>`;*/

let data = cdaydata.filter(items => items.ID == id);
let content = ` <div class="c-container"><div class="c-wrap">
<iframe width="100%" height="360"  src="https://apps.powerapps.com/play/e/default-7bf109b7-39a2-49d4-911d-09736db83214/a/580925a3-c07f-41d7-84dc-39ca074d34d4?tenantId=7bf109b7-39a2-49d4-911d-09736db83214&source=portal?ID=${data[0].ID}" ></iframe> </div></div>`;

$('#cdayModel .modal-title').html(`${" "}`);
$('#cdayModel .modal-body').html(content);

$('#cdayModel').modal('show')

}


/*** Line Chart */

var linechartpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Market')/items"
var LineChart =[];
var LineChartXData = [];
    var LineChartYData = [];
$.ajax({

    url: linechartpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {
    //LineChart = data.d.results;
    for (i = 0; i < data.d.results.length; i++) {
            LineChart.push([data.d.results[i].Date, data.d.results[i].Price]);
        }
debugger;
for (j = 0; j < data.d.results.length; j++) {
    LineChartXData.push(data.d.results[j].Date);
    LineChartYData.push(data.d.results[j].Price);
        var trace1 = {
  x: LineChartXData,
  y: LineChartYData,
  type: 'scatter'
}};

var FinalLineData = [trace1];

Plotly.newPlot('myDiv', FinalLineData);

    
    },

    eror: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
//function calllinechart(){
anychart.onDocumentReady(function () {
  
        // add data
        /*var LineChart = [
          ["2003", 1, 0, 0],
          ["2004", 4, 0, 0],
          ["2005", 6, 0, 0],
          ["2006", 9, 1, 0],
          ["2007", 12, 2, 0],
          ["2008", 13, 5, 1],
          ["2009", 15, 6, 1],
          ["2010", 16, 9, 1],
          ["2011", 16, 10, 4],
          ["2012", 17, 11, 5],
          ["2013", 17, 13, 6],
          ["2014", 17, 14, 7],
          ["2015", 17, 14, 10],
          ["2016", 17, 14, 12],
          ["2017", 19, 16, 12],
          ["2018", 20, 17, 14],
          ["2019", 20, 19, 16],
          ["2020", 20, 20, 17],
          ["2021", 20, 20, 20],
          ["2022", 20, 22, 20]
        ];*/
  
        // create a LineChart set
        var dataSet = anychart.data.set(LineChart);

        // map the data for all series
        var firstSeriesData = dataSet.mapAs({x: 0, value: 1});
        //var secondSeriesData = dataSet.mapAs({x: 0, value: 2});
        //var thirdSeriesData = dataSet.mapAs({x: 0, value: 3});

        // create a line chart
        var chart = anychart.line();

        // create the series and name them
        var firstSeries = chart.line(firstSeriesData);
        firstSeries.name("Market");
        //var secondSeries = chart.line(secondSeriesData);
        //secondSeries.name("Rafael Nadal");
        //var thirdSeries = chart.line(thirdSeriesData);
       // thirdSeries.name("Novak Djokovic");

        // add a legend
        chart.legend().enabled(true);
  
        // add a title
        chart.title("Big Three's Grand Slam Title Race");
  
        // specify where to display the chart
        chart.container("container");
  
        // draw the resulting chart
        chart.draw();
  
      })//};