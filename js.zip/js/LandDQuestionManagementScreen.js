var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Course Evaluation Quiz')/items"
 var studentData =[];
var tableRows =[];
const timeValues = [];
 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }
function appendlms(){
debugger
nrecord=$('.norecord');

nrecord.empty();

let lmsWrap = $('.career-wrap3');

var inputBox = document.getElementById("searchInput");

inputBox.value = "";

$('.clear-search').hide();

const selectElement = document.getElementById("mySelect");

selectElement.selectedIndex = 0;

lmsWrap.empty()

 

// Sort the data based on the sort direction and column

 studentData .sort((a, b) => {

if (a.Category1 < b.Category1) {

return -1;

}

if (a.Category1 > b.Category1) {

return 1;

}

return 0;

});

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")

//document.getElementById('inprghead').innerHTML = 'In Progress ( ' + filteredItems.length +' )' ;

 

//grid view

if(studentData.length > 0){

$('.scrollbar-wrap').show();

$('.car-container3').show()

 

studentData.map(items => lmsWrap.append(`<div class="post" onclick=""> Category:<br> ${items.Category1}<br> Course: ${items.Category} Question Number: ${items.Quiz} </div>`))

}

else{

//exchange

$('.scrollbar-wrap').hide();

$('.car-container3').hide();

$('.norecord').show();

lmsWrap.empty();

nrecord=$('.norecord');

nrecord.empty();

nrecord.append(`<p style="font-size: 120%; color:#3d8084;text-align: center;padding-top: 100px; width: 539px;">${"No Record found"}</p>

`)

 

}

}