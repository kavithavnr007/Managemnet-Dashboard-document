var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Course Evaluation User Badge')/items"
var studentData =[];
var tableRows =[];

 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }

 function studentdup(){

   var inputBox = document.getElementById("Searchresultsum");
  inputBox.value = "";

  $('.nocertify15').hide();
  $('.clear-certify15').hide();
  $('.cevaluation19').empty();

 if(studentData.length>0){

 var stdwrap = $('.cevaluation18');
 stdwrap.empty();
 
// Object to store employee entry counts
var entryCounts01 = {};

console.log("entryCounts01" , entryCounts01);
// Counting employee entries
for (var i = 0; i < studentData.length; i++) {
  var course = studentData[i].Category1;
  var category = studentData[i].Category;
  var section = studentData[i].Section;
  



  // Creating a unique key combining employeeId and department
  var key = course + "|" + category + "|" + section;

  if (!entryCounts01.hasOwnProperty(key)) {
    entryCounts01[key] = 1;
    

  } else {
    entryCounts01[key]++;

  }
}
debugger;
for (var key in entryCounts01) {
  var parts = key.split("|");
  var course= parts[0];
  var category = parts[1];
  var section = parts[2];
  var count = entryCounts01[key];
  
  // Calculate average time

  // Create the HTML table row and push it to the array 
  



var payload = {

'course':course,

'category':category,

'section':section,
'count' : count

};



   tableRows.push(payload);
  stdwrap.append(`<tr><td>${category}</td>
                         <td>${course}</td>
                          <td>${section}</td>
                           <td><button style="background:transparent;border:none;" onclick="EmployeeDetailshowbelow('${category}','${course}','${section}')" background: transparent;
    border: none;> ${count}</button></td></tr>`
   )
  }
}
 else{
   $('.nocertify15').show();
}

 }
 //console.log("stdwrap" + stdwrap  );

//function showstdet(){
  //debugger;
//var stdwrap = $('.cevaluation'); //document.getElementByClass('student')
//stdwrap.empty();
//for(i=0;i<studentData.length; i++){
  // stdwrap.append(`<tr><td>${studentData[i].Category}</td>
    //                     <td>${studentData[i].Course}</td>
    //                    <td>${studentData[i].Section}</td>
   //                       <td>${studentData[i].Title}</td></tr>`
   //) 
//}
//}
function Couresecountdet(){
    //Object to store employee entry counts
    var EmployeeCount={};

    //Counting  employee entries
    for (var i = 0; i < studentData.length; i++) {
  var course= studentData[i].Category1;
  var category =studentData[i].Category;
  var section = studentData[i].Section;

  //Creating a unique key combining

  var EmployeeCOUNTKEY= course + "-" +  category + "-" + section;

   if (!EmployeeCount.hasOwnProperty(EmployeeCOUNTKEY)) {

    EmployeeCount[EmployeeCOUNTKEY] = 1;
   }else{
       EmployeeCount[EmployeeCOUNTKEY]++;
   }
}

}

function EmployeeDetailshowbelow(category,course,section)
{
  debugger

var lsrdata =[];

lsrdata = studentData.filter(list => list.Category.toLocaleLowerCase() ===category.toLocaleLowerCase() && list.Category1.toLocaleLowerCase() ===course.toLocaleLowerCase() && list.Section.toLocaleLowerCase() ===section.toLocaleLowerCase() )
var lsrdata1 = $('.cevaluation19');
lsrdata1.empty();
console.log("lsrdata: " + lsrdata); 
for(i=0;i<lsrdata.length; i++){
   lsrdata1.append(`<tr><td>${lsrdata[i].UserName}</td>
                         <td>${lsrdata[i].Category1}</td>
                         <td>${lsrdata[i].Category}</td>
                         <td>${lsrdata[i].Section}</td>
                         <td>${lsrdata[i].AuthorName}</td>
                         <td>${lsrdata[i].AboutAuthor}</td>
                         </tr>`
   )  
}

  
}

// Assuming 'sharepointData' is the array of SharePoint data

function searchData(inputValue) {
  // Filter the tableRows array based on the inputValue
  const searchResults = tableRows.filter(item => {
    return item.category.toLowerCase().includes(inputValue.toLowerCase());
  });
  return searchResults;
}

// Add the onchange event handler to the input element
function searchfun() {
  const searchInput = document.getElementById("Searchresultsum");
  const inputValue = searchInput.value.toLowerCase();

  if (inputValue.length > 0) {
    $('.nocertify15').hide();
    $('.clear-certify15').show();
    $('.cevaluation19').empty();
  } else {
    $('.nocertify15').show();
    $('.clear-certify15').hide();
    $('.cevaluation19').empty();
  }

  // Perform the search and store the results in the 'results' variable
  var results = searchData(inputValue);
  console.log(results);

  var stdwrap = $('.cevaluation18');
  stdwrap.empty();

  if (results.length > 0) {
    stdwrap.show();

    // Use a Set to store unique entries
    var uniqueEntries = new Set();

    results.forEach(item => {
      // Create a unique key for each item to prevent duplicates
      var key = `${item.category}_${item.course}_${item.section}`;
      
      // Check if the entry is unique
      if (!uniqueEntries.has(key)) {
        uniqueEntries.add(key);

        stdwrap.append(`<tr><td>${item.category}</td>
          <td>${item.course}</td>
          <td>${item.section}</td>
          <td><button style="background:transparent;border:none;" onclick="EmployeeDetailshowbelow('${item.category}','${item.course}','${item.section}')" background: transparent; border: none;>${item.count}</button></td></tr>`);
      }
    });
  } else {
    $('.nocertify15').show();
  }
}
