var Marketpath="https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Rencata Market Place')/items" 
var MaretData=[];
//get Market data
function Marketdet(){
	debugger;
$.ajax({
    url: Marketpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        MaretData = data.d.results;
        
        console.log("student details: " + MaretData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
}
