 var studentpath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Learner')/items"
 var studentData =[];

 // to get the student details

 function studentdet() {
     debugger;
$.ajax({
    url: studentpath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        studentData = data.d.results;
        //studentData= studentData.filter(item=> item. Title=="Durai")
        
        console.log("student details: " + studentData);   
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
 }

function showstdet(){
  debugger;
var stdwrap = $('.student'); //document.getElementByClass('student')
stdwrap.empty();
for(i=0;i<studentData.length; i++){
   stdwrap.append(`<div style="border: 1px solid;padding: 10px;display: flex;gap: 10px;">${studentData[i].Title} <button onclick="showpopup(${studentData[i].ID})" style="width:80px">Show PopUp</button></div>`) 
}
}
