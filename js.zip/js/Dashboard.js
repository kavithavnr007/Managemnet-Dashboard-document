





























document.addEventListener("DOMContentLoaded", function () {
  const notificationBell = document.getElementById("notification-bell");
  const notificationCount = document.getElementById("notification-count");

  // SharePoint site URL
  const siteUrl = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/Lists/LMS%20Course%20List/AllItems.aspx";

  // SharePoint list name
  const listName = "LMS Course List";

  // URL to fetch the item count from the SharePoint list
  const apiUrl = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/ItemCount`;

  // Fetch the item count
  fetch(apiUrl, {
    method: "GET",
    headers: {
      Accept: "application/json;odata=nometadata",
    },
  })
    .then((response) => response.json())
    .then((data) => {
      const itemCount = data.value; // Extract the item count from the response

      // Update the notification count
      notificationCount.innerText = itemCount;
    })
    .catch((error) => {
      console.error("Error fetching item count:", error);
    });
});
function initializeFontAwesome() {
  // Your FontAwesome-related code goes here
  // For example, you can use FontAwesome icons or classes.
}
