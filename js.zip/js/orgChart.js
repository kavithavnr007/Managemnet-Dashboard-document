var orgChartList = [];
var apiURL = "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items";

function GetOrgChartList() {
	$.ajax({
		url: apiURL,
		headers: {
			Accept: "application/json;odata=verbose"
		},
		async: false,
		success: function (data) {


			for (i = 0; i < data.d.results.length; i++) {
				if (data.d.results[i].Email != null && data.d.results[i].Active) {
					orgChartList.push(data.d.results[i]);
				}
			}
			if (data.d.__next) {
				apiURL = data.d.__next;
				GetOrgChartList();
				return;
			}

		},
		error: function (data) {
			console.log("An error occurred. Please try again.");
		}
	});

};
GetOrgChartList();
var department = [...new Set(orgChartList.map(n => n.Department))];
const cHead = orgChartList.filter(function (e) {
	return e.Email.toLowerCase() == "venugopal.balakrishnan@rencata.com"
});
showDepartment = () => {
	$('#tabs-nav').empty();
	for (dept = 0; dept < department.length; dept++) {
		let $li = `<li onclick="showOrgChartBPO('${department[dept]}')"><a href="#tab1">${department[dept]}</a></li>`;
		$('#tabs-nav').append($li);
	}
}
showDepartment();


function showOrgChartByEmail(el, email, isLevel) {
	$('.organizational-chart').empty();
	$('#tabs-nav li').removeClass('active');
	$(el).addClass('active');
	if (email == null || email == undefined) {
		return false;
	}

	let managerDetails = orgChartList.filter(function (e) {
		return e.Email.toLowerCase() == email.toLowerCase()
	});
	let level2 = orgChartList.filter(function (e) {
		return e.ReportingManagerEmail.toLowerCase() == email.toLowerCase()
	});
	let empPhoto = managerDetails[0].Photo ? managerDetails[0].Photo.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
	let manager = `<li><div class="emp-wrapper"><div class="img-name"><img src="${empPhoto}" alt="Avatar">
                    <p class="name">${managerDetails[0].field_Employee_x0020_Name} <span>${managerDetails[0].Designation}</span><span>${managerDetails[0].Email}</span></p></div><div class="emp-mail ${managerDetails[0].field_Location.toLowerCase()}">Location : <span style="font-weight:500">${managerDetails[0].field_Location}</span></div></div></li>`
	$('.organizational-chart').append(manager);
	if (level2.length > 0) {
		$('#container').removeClass();
		$('#container').addClass('level-1');
		$('.organizational-chart li').append("<ol></ol>");
	}

	for (i = 0; i < level2.length; i++) {
		let empPhoto = level2[i].Photo ? level2[i].Photo.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
		let empList = orgChartList.filter(function (e) {
			return e.ReportingManagerEmail.toLowerCase() == level2[i].Email.toLowerCase()
		});
		let emp = `<li id="${level2[i].Title}"> <div><div class="emp-wrapper"><div class="img-name"><img src="${empPhoto}" alt="Avatar">
              <p class="name">${level2[i].field_Employee_x0020_Name} (${empList.length}) <span>${level2[i].Designation}</span><span>${level2[i].Email}</span></p></div><div class="emp-mail ${level2[i].field_Location.toLowerCase()}">Location : <span style="font-weight:500">${level2[i].field_Location}</span></div></div></div></li>`
		$('.organizational-chart > li > ol').append(emp);

		if (empList.length > 0 && isLevel) {
			$("#" + level2[i].Title).append("<ol></ol>");
			$('#container').removeClass();
			$('#container').addClass('level-2');

			for (j = 0; j < empList.length; j++) {
				let empPhoto = empList[j].Photo ? empList[j].Photo.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
				let emp = `<li> <div><div class="emp-wrapper"><div class="img-name"><img src="${empPhoto}" alt="Avatar">
              <p class="name">${empList[j].field_Employee_x0020_Name} <span>${empList[j].Designation}</span><span>${empList[j].Email}</span></p></div><div class="emp-mail ${empList[j].field_Location.toLowerCase()}">Location : <span style="font-weight:500">${empList[j].field_Location}</span></div></div></div></li>`
				$("#" + level2[i].Title + " > ol").append(emp);

			}
			empList = []
		}
	}

}

function showOrgChartBPO(department) {
	debugger;
	let list = orgChartList.filter(e => e.Department == department);
	let projectManager = list.filter(e => e.Level).filter(e => e.Level.toLowerCase() == "project manager");
    if(projectManager.length == 0) projectManager = cHead;
    let $Manager = list.filter(e => e.Level).filter(e => e.Level.toLowerCase() == "manager");
    let empPhoto = projectManager[0].Photo ? projectManager[0].Photo.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
	let $li = `<li><div class="emp-wrapper"><div class="img-name"><img src="${empPhoto}" alt="Avatar">
                 <p class="name">${projectManager[0].field_Employee_x0020_Name} <span>${projectManager[0].Designation}</span><span>${projectManager[0].Email}</span></p>
                 </div><div class="emp-mail ${projectManager[0].field_Location.toLowerCase()}">Location : <span style="font-weight:500">${projectManager[0].field_Location}</span></div></div></li>`
	$('.organizational-chart').empty();
	$('#container').removeClass();

	if (projectManager.length > 1) {
		$('#tabs-nav').empty();
		let backToDept = `<li onclick="showDepartment()"><a href="#tab1">Back to Department</a></li>`;
		$('#tabs-nav').append(backToDept);
		for (let pm = 0; pm < projectManager.length; pm++) {
			let $li = `<li onclick="showOrgChartByEmail(this,'${projectManager[pm].Email}')"><a href="#tab1">${projectManager[pm].field_Employee_x0020_Name}</a></li>`;
			$('#tabs-nav').append($li);

		}
		showOrgChartByEmail($('#tabs-nav li:nth-child(2)'), projectManager[0].Email)
		return false;
	}
    $('.organizational-chart').append($li);
	$('.organizational-chart li').append("<ol></ol>");
	if ($Manager.length > 0) {
		$('#container').removeClass('level-1');
		$('#container').addClass('level-2');
		for (i = 0; i < $Manager.length; i++) {
			let empPhoto = $Manager[i].Photo ? $Manager[i].Photo.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
			let empList = list.filter(function (e) {
				return e.ReportingManagerEmail.toLowerCase() == $Manager[i].Email.toLowerCase()
			});
			let emp = `<li id="${$Manager[i].Title}"> <div><div class="emp-wrapper"><div class="img-name"><img src="${empPhoto}" alt="Avatar">
                 <p class="name">${$Manager[i].field_Employee_x0020_Name} (${empList.length}) <span>${$Manager[i].Designation}</span><span>${$Manager[i].Email}</span></p></div>
                 <div class="emp-mail ${$Manager[i].field_Location.toLowerCase()}">Location : <span style="font-weight:500">${$Manager[i].field_Location}</span></div></div></div></li>`
			$('.organizational-chart > li > ol').append(emp);

			if (empList.length > 0) {

				$("#" + $Manager[i].Title).append("<ol></ol>");

				for (let j = 0; j < empList.length; j++) {
					let empPhoto = empList[j].Photo ? empList[j].Photo.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
					let emp = `<li> <div><div class="emp-wrapper"><div class="img-name"><img src="${empPhoto}" alt="Avatar">
              <p class="name">${empList[j].field_Employee_x0020_Name} <span>${empList[j].Designation}</span><span>${empList[j].Email}</span></p></div>
              <div class="emp-mail ${empList[j].field_Location.toLowerCase()}">Location : <span style="font-weight:500">${empList[j].field_Location}</span></div></div></div></li>`
					$("#" + $Manager[i].Title + " > ol").append(emp);
				}
				empList = []
			}
		}
	} else {
		$('#container').removeClass('level-2');
		$('#container').addClass('level-1');
		let empList = [];
        projectManager[0].Email.toLowerCase() != "venugopal.balakrishnan@rencata.com" ?
        empList = list.filter(function (e){ return e.ReportingManagerEmail.toLowerCase() == projectManager[0].Email.toLowerCase()}) : empList = list;
         
		for (let j = 0; j < empList.length; j++) {
			let empPhoto = empList[j].Photo ? empList[j].Photo.Url : "https://ssgconsulting.sharepoint.com/sites/RENCATAHR/Employee%20Photo/no-photo.jpg";
			let emp = `<li><div><div class="emp-wrapper"><div class="img-name"><img src="${empPhoto}" alt="Avatar">
              <p class="name">${empList[j].field_Employee_x0020_Name} <span>${empList[j].Designation}</span><span>${empList[j].Email}</span></p></div>
              <div class="emp-mail ${empList[j].field_Location.toLowerCase()}">Location : <span style="font-weight:500">${empList[j].field_Location}</span></div></div></div></li>`
			$('.organizational-chart > li > ol').append(emp);
		}
		empList = []
	}
}
showOrgChartBPO(department[0]);

$('#tabs-nav li:first-child').addClass('active');
$('.tab-content').hide();
$('.tab-content:first').show();

// Click function
$('#tabs-nav li').click(function () {
	debugger;
	$('#tabs-nav li').removeClass('active');
	$(this).addClass('active');
	$('.tab-content').hide();

	var activeTab = $(this).find('a').attr('href');
	$(activeTab).fadeIn();
	return false;
});