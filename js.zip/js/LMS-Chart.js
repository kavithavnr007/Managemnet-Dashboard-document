/***LMS*****/

var lmslearnPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Learner')/items"
debugger;
var lmslearnData = [];

function lmslearnfunc() {

$.ajax({

url:lmslearnPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

lmslearnData = [...lmslearnData,...data.d.results]

if (data.d.__next) {

lmslearnPath = data.d.__next;

lmslearnfunc();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}
lmslearnfunc();


function appendlmschart(){
  debugger;

  $('.tableview').show();
var tableData = lmslearnData.map(value => {
  return (
    `<tr style="border-top: none;border-bottom: 1px solid #e9e9e9;">
       <td>${value.Title}</td>
       <td>${value.Course}</td>
       <td>${value.CourseStatus}</td>
    </tr>`
  );
}).join('');

const tableBody = document.querySelector("#tableBody");
tableBody.innerHTML = tableData;

var cpltdata= lmslearnData.filter(list => list.CourseStatus.toLowerCase() === "completed");
var inprocdata= lmslearnData.filter(list => list.CourseStatus.toLowerCase() === "inprogress");
var nsdata= lmslearnData.filter(list => list.CourseStatus.toLowerCase() === "notstarted");

// Get the canvas element

/*var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: ['Completed', 'In Progress', 'Not Started'],
    datasets: [{
      label: '# of Votes',
      data: [cpltdata.length, inprocdata.length, nsdata.length],
      backgroundColor: [
        'rgb(154,205,50)',
        'rgb(237,119,17)',
        'rgb(192,192,192)'
      ],
      borderColor: [
        'rgb(154,205,50)',
        'rgb(237,119,17)',
        'rgb(192,192,192)'
      ],
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false
  }
});*/



var xValues = ['Not Started', 'In Progress', 'Completed'];
var yValues = [nsdata.length, inprocdata.length, cpltdata.length];
var barColors = [
  "rgba(158,158,158,255)",
  'rgba(219,94,40,255)',
  'rgba(104,135,15,255)'
];

new Chart("myChart", {
  type: "doughnut",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: ""
    }
  }
});

}

