// var box  = document.getElementById('box');
// var down = false;


// function toggleNotifi(){
// 	if (down) {
// 		box.style.height  = '0px';
// 		box.style.opacity = 0;
// 		down = false;
// 	}else {
// 		box.style.height  = '510px';
// 		box.style.opacity = 1;
// 		down = true;
// 	}
// }



//Replace the URL with your SharePoint site and list name
//var listUrl = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Course List')";


 let isDropdownVisible = false;

function toggleDropdown() {
  const dropdown = document.getElementById('notificationDropdown');
  isDropdownVisible = !isDropdownVisible;
  dropdown.style.display = isDropdownVisible ? 'block' : 'none';
}

document.getElementById('notificationBell').addEventListener('click', toggleDropdown);

function fetchDataAndPopulateDropdown() {
  // Fetch course data and populate the dropdown
  const courseDataPromise = fetch("https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Course List')/items?$select=Title", {
    method: 'GET',
    headers: {
      'Accept': 'application/json;odata=verbose',
    },
  })
    .then(response => response.json())
    .then(data => {
      const courses = data.d.results;
      const dropdown = document.getElementById('notificationDropdown');
      const courseList = document.createElement('ul');

      courses.forEach(course => {
        const listItem = document.createElement('li');
        listItem.textContent = course.Title;
        courseList.appendChild(listItem);
      });

      dropdown.appendChild(courseList);
    })
    .catch(error => {
      console.error('Error fetching course data:', error);
    });

  // Fetch notification count and update the count
  const countDataPromise = fetch("https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('LMS Course List')", {
    method: 'GET',
    headers: {
      'Accept': 'application/json;odata=verbose',
      'Cache-Control': 'no-cache',
    },
  })
    .then(response => response.json())
    .then(data => {
      const notificationCount = data.d.ItemCount;
      const notificationCountSpan = document.getElementById('notificationCount');
      notificationCountSpan.textContent = notificationCount > 0 ? notificationCount : '';
    })
    .catch(error => {
      console.error('Error fetching count data:', error);
    });

  // Wait for both promises to resolve before continuing
  Promise.all([courseDataPromise, countDataPromise])
    .then(() => {
      // Both requests have completed, you can add any additional logic here if needed
    });
}

// Call the function to fetch data and populate the dropdown and update the count
fetchDataAndPopulateDropdown();





  


























