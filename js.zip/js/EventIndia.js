/***Event***/

var EventsPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Rencata Event List')/items"

var eventsData = [];

function jobPosting() {

$.ajax({

url:EventsPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

eventsData = [...eventsData,...data.d.results]

if (data.d.__next) {

EventsPath = data.d.__next;

jobPosting();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}

jobPosting()
debugger;
function appendevents(){
let jobPostWrap = $('.career-wrap5');
jobPostWrap.empty()
var Todate = new Date().getTime();
var disUSData = eventsData.filter(list => list.EventLocation.toLowerCase() == "us" && new Date(list.EndTime).getTime() > Todate)
$('.car-container5').show();
$('.usecount').append(` (${disUSData.length})`);
if(disUSData.length > 0){
disUSData.map(items => jobPostWrap.append(`<div class="post" onclick="jobPostDetails(${items.ID})"> <p style="font-size: 140%;">${items.Title}</p>
<P> ${(new Date(items.StartTime).getMonth()+1).toString().length > 1 ? new Date(items.StartTime).getMonth()+1 : `0${new Date(items.StartTime).getMonth()+1}`}/${new Date(items.StartTime).getDate().toString().length > 1 ? new Date(items.StartTime).getDate() : `0${new Date(items.StartTime).getDate()}`}/${new Date(items.StartTime).getFullYear()} - ${(new Date(items.StartTime).getHours()% 12|| 12).toString().length > 1 ? new Date(items.StartTime).getHours()% 12|| 12 : `0${new Date(items.StartTime).getHours()% 12 || 12}`}:${new Date(items.StartTime).getMinutes().toString().length > 1 ? new Date(items.StartTime).getMinutes() : `0${new Date(items.StartTime).getMinutes()}`} ${new Date(items.StartTime).getHours()>= 12 ? 'PM' : 'AM'} (${getDuration(items.StartTime,items.EndTime)} Hours) </p></div>`)
);
} else{ jobPostWrap.append(`<p style="text-align:center">No Events Found</p>`);
}
}

function getDuration(startDate,endDate)
{
   
let startDt = new Date(startDate)
let endDt = new Date(endDate)
let dateA = `${startDt.getFullYear()}-${(startDt.getMonth()+1).toString().length > 1 ? (startDt.getMonth()+1):`0${(startDt.getMonth()+1)}`}-${(startDt.getDate()).toString().length > 1 ? (startDt.getDate()):`0${(startDt.getDate())}`}T${(startDt.getHours()% 12|| 12).toString().length > 1 ? (startDt.getHours()% 12|| 12) : `0${startDt.getHours()% 12|| 12}`}:${startDt.getMinutes().toString().length > 1 ? (startDt.getMinutes()) : `0${startDt.getMinutes()}`}`
let dateB = `${endDt.getFullYear()}-${(endDt.getMonth()+1).toString().length > 1 ? (endDt.getMonth()+1):`0${(endDt.getMonth()+1)}`}-${(endDt.getDate()).toString().length > 1 ? (endDt.getDate()):`0${(endDt.getDate())}`}T${(endDt.getHours()% 12|| 12).toString().length > 1 ? (endDt.getHours()% 12|| 12) : `0${endDt.getHours()% 12|| 12}`}:${endDt.getMinutes().toString().length > 1 ? (endDt.getMinutes()) : `0${endDt.getMinutes()}`}`
let timeDiff = (new Date(endDate).getTime() - new Date(startDate).getTime()) / 60000
timeDiff = timeDiff / 60

//let timeDiff =(dateB.getTime() - dateA.getTime()) / 1000;
//timeDiff /= (60 * 60);
//return Math.abs(Math.round(timeDiff));
return Math.abs(Math.round(timeDiff))


}


function jobPostDetails(id){

let data = eventsData.filter(items => items.ID == id);
let content = `<div class="c-container5"><div class="c-wrap">
            <P>Title : <span>${data[0].Title.replace(/<[^>]*>?/gm, '')}</span></p>
            <P>Event Location :<span> ${data[0].EventLocation}</span></p>
             </div>
            <div class="c-wrap">
            <P>Start Date :<span> ${
new Date(data[0].StartTime).getDate()}/${new Date(data[0].StartTime).getMonth()+1}/${new Date(data[0].StartTime).getFullYear()} - ${(new Date(data[0].StartTime).getHours()% 12|| 12).toString().length > 1 ? new Date(data[0].StartTime).getHours()% 12|| 12 : `0${new Date(data[0].StartTime).getHours()% 12|| 12}`}:${new Date(data[0].StartTime).getMinutes().toString().length > 1 ? new Date(data[0].StartTime).getMinutes() : `0${new Date(data[0].StartTime).getMinutes()}`} ${new Date(data[0].StartTime).getHours()>= 12 ? 'PM' : 'AM'}  </span></p>
            <P>End Date :<span> ${new Date(data[0].EndTime).getDate()}/${new Date(data[0].EndTime).getMonth()+1}/${new Date(data[0].EndTime).getFullYear()} - ${(new Date(data[0].EndTime).getHours())% 12|| 12 .toString().length > 1 ? new Date(data[0].EndTime).getHours()% 12|| 12 : `0${new Date(data[0].EndTime).getHours()% 12|| 12}`}:${new Date(data[0].EndTime).getMinutes().toString().length > 1 ? new Date(data[0].EndTime).getMinutes() : `0${new Date(data[0].EndTime).getMinutes()}`} ${new Date(data[0].EndTime).getHours()>= 12 ? 'PM' : 'AM'}</span></p>  </div></div>
            <P><span style="font-weight:500; color:#000">Description :</span> <br /> ${data[0].Description}</p>`;

$('#jobPostingModel .modal-title').html(`${data[0].Title.replace(/<[^>]*>?/gm, '')}`);

$('#jobPostingModel .modal-body').html(content);

$('#jobPostingModel').modal('show')

}



function appendevents1(){
debugger
let EventWrap = $('.career-wrap6');
EventWrap.empty()
var Todate = new Date().getTime();
var disData = eventsData.filter(list => list.EventLocation.toLowerCase() == "india" && new Date(list.EndTime).getTime() > Todate)
$('.car-container6').show();
$('.indiaecount').append(` (${disData.length})`);
if(disData.length > 0){
disData.map(items => EventWrap.append(`<div class="post" onclick="jobPostDetails1(${items.ID})"> <p style="font-size: 140%;">${items.Title}</p>
<P> ${(new Date(items.StartTime).getMonth()+1).toString().length > 1 ? new Date(items.StartTime).getMonth()+1 : `0${new Date(items.StartTime).getMonth()+1}`}/${new Date(items.StartTime).getDate().toString().length > 1 ? new Date(items.StartTime).getDate() : `0${new Date(items.StartTime).getDate()}`}/${new Date(items.StartTime).getFullYear()} - ${(new Date(items.StartTime).getHours()% 12|| 12).toString().length > 1 ? new Date(items.StartTime).getHours()% 12|| 12 : `0${new Date(items.StartTime).getHours()% 12 || 12}`}:${new Date(items.StartTime).getMinutes().toString().length > 1 ? new Date(items.StartTime).getMinutes() : `0${new Date(items.StartTime).getMinutes()}`} ${new Date(items.StartTime).getHours()>= 12 ? 'PM' : 'AM'} (${getDuration(items.StartTime,items.EndTime)} Hours) </p></div>`)
)

}else{ EventWrap.append(`<p style="text-align:center">No Events Found</p>`)
}
}


function jobPostDetails1(id){
let data = eventsData.filter(items => items.ID == id);
let content = ` <div class="c-container6"><div class="c-wrap">
            <P>Title : <span>${data[0].Title.replace(/<[^>]*>?/gm, '')}</span></p>
            <P>Event Location :<span>  ${data[0].EventLocation}</span></p>
             </div>
            <div class="c-wrap">
            <P>Start Date :<span> ${
new Date(data[0].StartTime).getDate()}/${new Date(data[0].StartTime).getMonth()+1}/${new Date(data[0].StartTime).getFullYear()} - ${(new Date(data[0].StartTime).getHours()% 12|| 12).toString().length > 1 ? new Date(data[0].StartTime).getHours()% 12|| 12 : `0${new Date(data[0].StartTime).getHours()% 12|| 12}`}:${new Date(data[0].StartTime).getMinutes().toString().length > 1 ? new Date(data[0].StartTime).getMinutes() : `0${new Date(data[0].StartTime).getMinutes()}`} ${new Date(data[0].StartTime).getHours()>= 12 ? 'PM' : 'AM'}  </span></p>
            <P>End Date :<span> ${new Date(data[0].EndTime).getDate()}/${new Date(data[0].EndTime).getMonth()+1}/${new Date(data[0].EndTime).getFullYear()} - ${(new Date(data[0].EndTime).getHours())% 12|| 12 .toString().length > 1 ? new Date(data[0].EndTime).getHours()% 12|| 12 : `0${new Date(data[0].EndTime).getHours()% 12|| 12}`}:${new Date(data[0].EndTime).getMinutes().toString().length > 1 ? new Date(data[0].EndTime).getMinutes() : `0${new Date(data[0].EndTime).getMinutes()}`} ${new Date(data[0].EndTime).getHours()>= 12 ? 'PM' : 'AM'}</span></p>  </div></div>
            <P><span style="font-weight:500; color:#000">Description :</span> <br /> ${data[0].Description}</p>`;
           

$('#jobPostingModel1 .modal-title').html(`${data[0].Title.replace(/<[^>]*>?/gm, '')}`);

$('#jobPostingModel1 .modal-body').html(content);

$('#jobPostingModel1').modal('show')

}





/*** Who's Away***/

var WhosawayPath = "https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee Vacation')/items"

var EmpPath = "https://ssgconsulting.sharepoint.com/sites//RENCATAHR/_api/lists/getbytitle('Employee List with DOB and DOJ')/items"

var WhosawayData = [];
var EmpData = [];


function Emp() {

$.ajax({

url:EmpPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

EmpData = [...EmpData,...data.d.results]

if (data.d.__next) {

EmpPath = data.d.__next;

Emp();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}

Emp()



function Whosaway() {

$.ajax({

url:WhosawayPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

WhosawayData = [...WhosawayData,...data.d.results]

if (data.d.__next) {

WhosawayPath = data.d.__next;

Whosaway();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}

Whosaway()

function appendWhosaway(){
let WhosawayWrap = $('.career-wrapWIA');

WhosawayWrap.empty()

var Todate = new Date().getTime();

WhosawayData = WhosawayData.filter(list =>  (new Date().getDate() >= new Date(list.StartDate).getDate() && new Date().getMonth() >= new Date(list.StartDate).getMonth() && new Date().getFullYear() >= new Date(list.StartDate).getFullYear() && new Date().getDate() <= new Date(list.EndDate).getDate() && new Date().getMonth() <= new Date(list.EndDate).getMonth() && new Date().getFullYear() <= new Date(list.EndDate).getFullYear() ) || (new Date().getDate() == new Date(list.StartDate).getDate() && new Date().getMonth() == new Date(list.StartDate).getMonth() && new Date().getFullYear() == new Date(list.StartDate).getFullYear() && new Date().getDate() == new Date(list.EndDate).getDate() && new Date().getMonth() == new Date(list.EndDate).getMonth() && new Date().getFullYear() == new Date(list.EndDate).getFullYear() ))

if(WhosawayData.length > 0){$('.car-containerWIA').show()
const distinct=[...new Set(WhosawayData.map(x=> x.Employee_x0020_Name))];
$('.wiatitle').append(`<h3 style="padding:0px; margin:10px 0px 10px 10px;">
Who's Away Today (${distinct.length})
</h3>`)

$('.epchange').css('height', '250px')

WhosawayData.map(items => WhosawayWrap.append(`<div class="post" > <p><img style="border-radius: 50%;" align="left" width="60" height="60" src= "${getEmppic(items.EmployeeNumber)}" alt="Avatar">   <P style="padding-left: 60px; font-size: 140%; color: #3d8084; margin: 0px 0px 0px 10px; Width: 550px;"> ${items.Employee_x0020_Name}</p></p>
<P style="padding-left: 60px; font-size: 16px; margin: 0px 0px 0px 10px; Width: 550px;">     ${items.Days} ${items.Days> 1 ? 'Days' : 'Day'} | From ${(new Date(items.StartDate).getMonth()+1).toString().length > 1 ? new Date(items.StartDate).getMonth()+1 :`0${new Date(items.StartDate).getMonth()+1}`}/${new Date(items.StartDate).getDate().toString().length > 1 ? new Date(items.StartDate).getDate() :`0${new Date(items.StartDate).getDate()}`}/${new Date(items.StartDate).getFullYear()} - To ${(new Date(items.EndDate).getMonth()+1).toString().length > 1 ? new Date(items.EndDate).getMonth()+1 :`0${new Date(items.EndDate).getMonth()+1}`}/${new Date(items.EndDate).getDate().toString().length > 1 ? new Date(items.EndDate).getDate() :`0${new Date(items.EndDate).getDate()}`}/${new Date(items.EndDate).getFullYear()}   </p></div>`)

)

}
else{
    $('.epchange').css('height', '400px')
}

}

function getEmppic(Empcode){

let getpic = EmpData.filter(list =>  list.Title === Empcode)
let EmpImg =  getpic[0].Photo ?  getpic[0].Photo.Url : "https://ssgconsulting.sharepoint.com/:i:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/nophoto.jpg"
return EmpImg
}


function camelCase(str) {
            return str
                .replace(/\s(.)/g, function(a) {
                    return a.toUpperCase();
                })
                .replace(/\s/g, '')
                .replace(/^(.)/, function(b) {
                    return b.toLowerCase();
                });
        }
 


 /***my event count */

 
var loggedUserPath = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + _spPageContextInfo.userId + ")";
var loggedUserMail;
$.ajax({
    url: loggedUserPath,
    headers: {
        Accept: "application/json;odata=verbose"
    },
    async: false,
    success: function (data) {

        loggedUserMail = data.d.Email;
    },
    error: function (data) {
        console.log("An error occurred. Please try again.");
    }
});
var EventcountPath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('My Event Count')/items"
 var eventcountData = [];

function Eventcount() {

$.ajax({

url:EventcountPath,

headers: {

Accept: "application/json;odata=verbose"

},

async: false,

success: function (data) {

eventcountData = [...eventcountData,...data.d.results.filter(res => (res.Title==loggedUserMail))]

if (data.d.__next) {

EventcountPath = data.d.__next;

Eventcount();

return;

}

},

error: function (data) {

console.log("An error occurred. Please try again.");

}

});}

Eventcount()

function cevnt(){
    $('.myecount').append(` (${eventcountData[0].EventCount})`);
}
