var coursepath = "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/lists/getbytitle('Course Evaluation Topic')/items"
var courseData = [];
var questionmanagement;
//to get the student details
function Couseget() {
debugger;
$.ajax({
url: coursepath,
headers: {
Accept: "application/json;odata=verbose"
},
async: false,
success: function (data) {
courseData= data.d.results;
console.log("course details: " + courseData);
},
error: function (data) {
console.log("An error occured. please try again.");
}
})
}
function savesdet(){
var inputBox = document.getElementById("srch-term");
  inputBox.value = "";

  $('.nocertify15').hide();
  $('.clear-certify15').hide();
 if(courseData .length>0){
var stdwrap = $('.tquiz');
stdwrap.empty();
for(i=0;i<courseData.length;i++){
stdwrap.append(`<tr style="margin: 10px 0; box-shodow: 4px 2px 2px #ccc;">
 
<td>${courseData[i].Category0}</td>

<td>${courseData[i].Category}</td>

<td>${courseData[i].Section}</td>

<td>${courseData[i].Timer}</td>

<td>${courseData[i].Rounds}</td>

<td>${new Date(courseData[i].EffectiveDate).toLocaleDateString('en-GB')}</td>
<td>
<div style="display: flex;">

<div onclick="QuestionDetail(${courseData[i].ID})" style="padding:5px;"><img width="20"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/eye.svg"></div>

<div onclick="showpopup1('${courseData[i].ID}','${courseData[i].Category0}','${courseData[i].Category1}','${courseData[i].Section.length> 0 ? courseData[i].Section: `Null`}','${courseData[i].TimerDuration}','${courseData[i].Rounds}','${courseData[i].EffectiveDate}') "style="padding: 2px 8px;"><img width="18"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/edit.svg"> </div>
<div onclick="showpopup(${courseData[i].ID}) "style="padding:5px;"><img width="15"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/delete.svg"></div></div>

</td>

</tr>`)

}
}
 else{
   $('.nocertify15').show();
}
}

function QuestionDetail(id){
let data = courseData.filter(items => items.ID == id);
let content = ` <div class="c-container3"><div class="c-wrap">
<p> <b> COURSE</b> : ${data[0].Category0} </p>

<p> <b> CATEGORY</b> : ${data[0].Category} </p>

<p> <b> TOPIC </b> : ${data[0].Section} </p>

<p> <b> EVALUATION DURATION </b> : ${data[0].Timer} </p>

<p> <b> MAX RETAKE </b> : ${data[0].Rounds } </p>

<p> <b> EFFECTIVE DATE </b> : ${new Date(data[0].EffectiveDate).toLocaleDateString('en-GB')} </p>

</div>`;

$('#QuestionDetail .modal-title').html(`${data[0].Category0.replace(/<[^>]*>?/gm, '')}`);
$('#QuestionDetail .modal-body').html(content);
$('#QuestionDetail').modal('show')

}

function deleteRecordFromList(itemId) {
debugger;
var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
var listName = 'Course Evaluation Topic';
00

// Endpoint URL
var url = siteUrl + "/_api/web/lists/getByTitle('" + listName + "')/getItemById(" + itemId + ")";
// Refresh the Request Digest value
$.ajax({
url: siteUrl + "/_api/contextinfo",
method: "POST",
headers: { "Accept": "application/json;odata=verbose" },
success: function(data) {
var requestDigest = data.d.GetContextWebInformation.FormDigestValue;
// Make the AJAX POST request with the refreshed Request Digest value
$.ajax({
url: url,
type: "POST",
headers: {
"Accept": "application/json;odata=verbose",
"Content-Type": "application/json;odata=verbose",
"X-RequestDigest": requestDigest,
"X-HTTP-Method": "DELETE",
"If-Match": "*"
},

success: function(data) {
$('#sucess-message').css('display', 'block');

$(".popup").css('display','none');
courseData = [];
Couseget();
savesdet();
console.log("Item deleted successfully.");

setTimeout(function() {
        $('#sucess-message').css('display', 'none');
    }, 6000); // 6000 milliseconds = 6 seconds
},

error: function(error) {
console.log("Error deleting item: " + JSON.stringify(error));
// Handle error
}
});
},


error: function(error) {
console.log("Error refreshing Request Digest: " + JSON.stringify(error));
// Handle error
}
});
}

function showpopup(id){
debugger;
$(".popup").css('display','block');
window.confirmationparams ={
param1:id
}
}

function confirmdel(){
debugger;
var params = window.confirmationparams;
var param1 = params.param1;
deleteRecordFromList(param1);
}

function closepopup(){
debugger;
$('#delete-message').css('display', 'block');

$(".popup").css('display','none');

setTimeout(function() {
        $('#delete-message').css('display', 'none');
    }, 6000); // 6000 milliseconds = 6 seconds

}

function getFormDigest() {
return $.ajax({
url: "https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment/_api/contextinfo",
method: "POST",
headers: { "Accept": "application/json; odata=verbose" }
});
}

debugger;
function editrecord(id){
var itemID = id;
var newDescription = $('#newDescription').val();
var siteUrl = 'https://ssgconsulting.sharepoint.com/sites/RencataIntranetDevelopment';
var listName = 'Course Evaluation Topic';
var encodedListName = listName.replace(/ /g, '_x0020_');
var endpointUrl = siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items(" + itemID + ")";
getFormDigest().then(function (data) {
var formDigestValue = data.d.GetContextWebInformation.FormDigestValue;
var itemPayload = {
__metadata: { 'type': 'SP.Data.' + encodedListName + 'ListItem' },

Category0: $("#icategory").val(),

Category: $("#icourse").val(),

Section: $("#ititle").val(),

EffectiveDate: $("#ieffectivedate").val(),

Rounds: $("#iretake").val(),

NumberOfRounds: $("#iquestion").val(),

Weightage: $("#iweightage").val(),

Timer: $("#itimer").val()

};

// ... Your existing code to send the request to SharePoint ...
}
)
$.ajax({
url: endpointUrl,
type: 'POST',
contentType: 'application/json;odata=verbose',
data: JSON.stringify(itemPayload),
headers: {
'X-RequestDigest': formDigestValue,
'IF-MATCH': '*',
'X-HTTP-Method': 'MERGE'
},
success: function (data) {
$(".popupForm1").css('display','none');

Couseget();
savesdet();
alert('Item updated successfully!');
},
error: function (error) {
alert('Error updating item: ' + JSON.stringify(error));

}

});

};

function showpopup1(id,Category0,Category,Section,EffectiveDate,Rounds,NumberOfRounds,Weightage,Timer){
debugger;
$(".popupForm1").css('display','block');

 document.getElementById("icategory").value=Category0;

 document.getElementById("icourse").value=Category;

 document.getElementById("ititle").value=Section;

 document.getElementById("ieffectivedate").value=EffectiveDate;

 document.getElementById("iretake").value=Rounds;

 document.getElementById("iquestion").value=NumberOfRounds;

 document.getElementById("iweightage").value=Weightage;

 document.getElementById("itimer").value=Timer;


window.confirmationparams ={
param1:id

}

}

function closepopup2(){
debugger;
$(".popupForm1").css('display','none');
}

function confirmedit(){
debugger;
var params = window.confirmationparams;
var param1 = params.param1;
editrecord(param1);
}

 function searchData(inputValue) {
debugger;
const searchResults = courseData.filter(item => {
// Replace 'columnName' with the actual name of the column you want to search
return item.Category0.toLowerCase().includes(inputValue.toLowerCase());
});
return searchResults;
}

// Get a reference to the input element
const searchInput = document.getElementById("srch-term");
// Add the onchange event handler to the input element
searchInput.onchange = function() {
const inputValue = searchInput.value;

if(inputValue.length >0){
    $('.nocertify15').hide();
$('.clear-certify15').show() 
}

else{
    $('.nocertify15').hide();
$('.clear-certify15').hide()

};

var results = searchData(inputValue);
console.log(results);
let lmsWrap = $('.tquiz');
lmsWrap.empty()

//lmsData = lmsData.filter(list => list.field_Status.toLowerCase() == "open" || list.field_Status.toLowerCase() == "reopen")
if(results.length > 0){$('.car-container3').show()
results.map(items => lmsWrap.append(`
<tr style="margin: 10px 0; box-shodow: 4px 2px 2px #ccc;">
<td>${items.Category0}</td>

<td>${items.Category}</td>

<td>${items.Section}</td>

<td>${items.Timer}</td>

<td>${items.Rounds}</td>

<td>${new Date(items.EffectiveDate).toLocaleDateString('en-GB')}</td>
<td>

<div style="display: flex;">

<div onclick="QuestionDetail(${items.ID})" style="padding:5px;"><img width="20"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/eye.svg"></div>
<div onclick="showpopup1('${items.ID}','${items.Category0}','${items.Category}','${items.Section.length> 0 ? items.Section: `Null`}','${items.TimerDuration}','${items.Rounds}','${new Date(items.EffectiveDate).toLocaleDateString('en-GB')}') "style="padding: 2px 8px;"><img width="18"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/edit.svg"></div>

<div onclick="showpopup(${items.ID}) "style="padding:5px;"><img width="15"src="https://ssgconsulting.sharepoint.com/:u:/r/sites/RencataIntranetDevelopment/Style%20Library/icons/Icons/delete.svg"></div></div>

</td>

</tr>`)) //<div class="vl"></div>
}
else{
$('.nocertify15').show();

 }
// This will log an array of items that match the search criteria

};

// function closesearch(){
// $('#btn-ccl').hide();
// $('#srch-term').empty();
// }

// function call

savesdet();

 
