$(document).ready(function(){
var indHrs = 0, indMins = 0, pstHrs = 0, pstMins = 0;
var todayDate = new Date();
var pstDate, istDate;
var startSun = new Array();
var EndSun = new Array();
var daylightStarts, daylightEnds;
var getMarchTot, getNovTot;
getMarchTot = daysInMonth(3,todayDate.getFullYear()); //Get total days in a month
for(var i=1;i<=getMarchTot;i++){    //looping through days in month
    let newDate = new Date(todayDate.getFullYear(), 2,i)
    if(newDate.getDay()==0){   //if Sunday
      startSun.push(newDate);
    }
}
getNovTot = daysInMonth(11,todayDate.getFullYear()); //Get total days in a month
for(var i=1;i<=getMarchTot;i++){    //looping through days in month
    let newDate = new Date(todayDate.getFullYear(), 10,i)
    if(newDate.getDay()==0){   //if Sunday
      EndSun.push(newDate);
    }
}
daylightStarts = startSun[1].getTime() + 7200000;
daylightEnds = EndSun[0].getTime() + 7200000;


function daysInMonth(month,year) {
    return new Date(year, month, 0).getDate();
}


	
	if (todayDate.getTimezoneOffset() == 480){
    daylightStarts = startSun[1].getTime() + 7200000;
    daylightEnds = EndSun[0].getTime() + 7200000;
        if(daylightStarts < todayDate.getTime() && daylightEnds > todayDate.getTime()){
	indHrs = 12;
	indMins = 30
}else{
	indHrs = 13;
	indMins = 30
}

	} else if(todayDate.getTimezoneOffset() == -330){
    daylightStarts = startSun[1].getTime() + 52200000;
    daylightEnds = EndSun[0].getTime() + 52200000;
    if(daylightStarts < todayDate.getTime() && daylightEnds > todayDate.getTime()){
	pstHrs = 12;
	pstMins = 30
    } else{
  pstHrs = 13;
	pstMins = 30
  }
	}
	

		var audioElement = new Audio("");

		//clock plugin constructor
		$('#myclock').thooClock({
			timeCorrection: {
            operator:'-',
            hours: pstHrs,
            minutes: pstMins
            },
			//size:$(document).height()/1.4,
			sweepingMinutes:true,
			sweepingSeconds:true,
		    showNumerals:false,
			brandText:'California',
			onEverySecond:function(){
                todayDate = new Date();
				pstDate = todayDate.toLocaleString("en-US", {timeZone: "America/Los_Angeles"});
				pstDate = pstDate.split(",").shift().toString();
				$('#c1').html(pstDate)
			},
			brandText2:''
		});
				//clock plugin constructor
		$('#myclock2').thooClock({
		    timeCorrection: {
            operator:'+',
            hours: indHrs,
            minutes: indMins
            },

			//size:$(document).height()/1.4,
			sweepingMinutes:true,
			sweepingSeconds:true,
		    showNumerals:false,
			brandText:'India',
			brandText2:'',
			onEverySecond:function(){
        todayDate = new Date();
				istDate = todayDate.toLocaleString("en-US", {timeZone: "Asia/Kolkata"})
				istDate = istDate.split(",").shift().toString();
				$('#c2').html(istDate)
			},
			
		});
		
		$('.rencata-slides').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
      })
		
		
	});